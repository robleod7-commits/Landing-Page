const React = __vite__cjsImport0_react; const useState = __vite__cjsImport0_react["useState"]; const useEffect = __vite__cjsImport0_react["useEffect"]; const useRef = __vite__cjsImport0_react["useRef"];const _jsxDEV = __vite__cjsImport4_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport4_react_jsxDevRuntime["Fragment"];/**
* @license
* SPDX-License-Identifier: Apache-2.0
*/
import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=e650bf5f";
import { motion, AnimatePresence } from "/node_modules/.vite/deps/motion_react.js?v=674c00dd";
import { Sparkles, Phone, PhoneCall, MessageSquare, Copy, Check, Share2, Camera, RotateCcw, X, ExternalLink, Video, Image as ImageIcon, Palette, QrCode, CheckCircle2, AlertCircle, ChevronRight, Moon, Zap, ZapOff, User, Trash2, UploadCloud, Download, FileArchive, FileCode, Contact, Loader2 } from "/node_modules/.vite/deps/lucide-react.js?v=1e6a56d7";
import { downloadProjectZip, downloadStandaloneHtml, downloadVCard } from "/src/utils/downloader.ts";
var _jsxFileName = "/app/applet/src/App.tsx";
import __vite__cjsImport4_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=e650bf5f";
const PRESET_GRADIENTS = [
	{
		id: "cover-gradient-1",
		name: "Cyber Indigo",
		class: "cover-gradient-1"
	},
	{
		id: "cover-gradient-2",
		name: "Emerald Ocean",
		class: "cover-gradient-2"
	},
	{
		id: "cover-gradient-3",
		name: "Sunset Glow",
		class: "cover-gradient-3"
	},
	{
		id: "cover-gradient-4",
		name: "Dark Minimal",
		class: "cover-gradient-4"
	},
	{
		id: "cover-gradient-5",
		name: "Electric Purple",
		class: "cover-gradient-5"
	},
	{
		id: "cover-gradient-6",
		name: "Forest Emerald",
		class: "cover-gradient-6"
	}
];
// Preset Avatars for quick selection
const PRESET_AVATARS = [
	{
		name: "Cyber Neon",
		url: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=400&auto=format&fit=crop&q=80"
	},
	{
		name: "Modern Portrait",
		url: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&auto=format&fit=crop&q=80"
	},
	{
		name: "Aesthetic Minimal",
		url: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=400&auto=format&fit=crop&q=80"
	},
	{
		name: "Creative Urban",
		url: "https://images.unsplash.com/photo-1492562080023-ab3db95bfbce?w=400&auto=format&fit=crop&q=80"
	}
];
export default function App() {
	// Glow Colors State - persisted in localStorage
	const [glowEnabled, setGlowEnabled] = useState(() => {
		try {
			const saved = localStorage.getItem("albert_robledo_glow_enabled");
			return saved !== null ? JSON.parse(saved) : true;
		} catch {
			return true;
		}
	});
	// Profile Picture (Avatar) State - persisted in localStorage
	const [avatarUrl, setAvatarUrl] = useState(() => {
		try {
			return localStorage.getItem("albert_robledo_avatar_v1") || null;
		} catch {
			return null;
		}
	});
	// Cover Banner Configuration - persisted in localStorage
	const [coverConfig, setCoverConfig] = useState(() => {
		try {
			const saved = localStorage.getItem("albert_robledo_cover_v2");
			if (saved) return JSON.parse(saved);
		} catch (e) {
			console.warn("Could not parse saved cover config", e);
		}
		return {
			type: "gradient",
			value: "cover-gradient-1"
		};
	});
	// Modals & Inputs
	const [isCoverModalOpen, setIsCoverModalOpen] = useState(false);
	const [isAvatarModalOpen, setIsAvatarModalOpen] = useState(false);
	const [isQrModalOpen, setIsQrModalOpen] = useState(false);
	const [isDownloadModalOpen, setIsDownloadModalOpen] = useState(false);
	const [isDownloading, setIsDownloading] = useState(false);
	const [imageUrlInput, setImageUrlInput] = useState("");
	const [videoUrlInput, setVideoUrlInput] = useState("");
	const [avatarUrlInput, setAvatarUrlInput] = useState("");
	const [copiedNumber, setCopiedNumber] = useState(false);
	// Follow me on social notification toast (appears 5s after page load)
	const [showSocialToast, setShowSocialToast] = useState(false);
	// Toast Notification State
	const [toast, setToast] = useState(null);
	const toastTimerRef = useRef(null);
	const videoElementRef = useRef(null);
	// Show Toast Helper
	const showToast = (message, type = "success") => {
		if (toastTimerRef.current) clearTimeout(toastTimerRef.current);
		setToast({
			message,
			type
		});
		toastTimerRef.current = setTimeout(() => {
			setToast(null);
		}, 2800);
	};
	// Toggle Glow Colors feature
	const toggleGlow = () => {
		const nextState = !glowEnabled;
		setGlowEnabled(nextState);
		try {
			localStorage.setItem("albert_robledo_glow_enabled", JSON.stringify(nextState));
		} catch (err) {
			console.warn("LocalStorage error", err);
		}
		if (nextState) {
			showToast("Glowing colors activated! ✨", "success");
		} else {
			showToast("All glowing colors turned off (Stealth mode) 🌑", "info");
		}
	};
	// Profile Picture Helpers
	const updateAvatar = (url) => {
		setAvatarUrl(url);
		try {
			if (url) {
				localStorage.setItem("albert_robledo_avatar_v1", url);
			} else {
				localStorage.removeItem("albert_robledo_avatar_v1");
			}
		} catch (err) {
			console.warn("LocalStorage save failed for avatar:", err);
		}
	};
	const handleAvatarFileUpload = (e) => {
		const file = e.target.files?.[0];
		if (!file) return;
		if (!file.type.startsWith("image/")) {
			showToast("Please select a valid image file", "error");
			return;
		}
		const reader = new FileReader();
		reader.onload = (event) => {
			const result = event.target?.result;
			if (result) {
				updateAvatar(result);
				showToast("Profile picture updated!");
				setIsAvatarModalOpen(false);
			}
		};
		reader.readAsDataURL(file);
	};
	const handleApplyAvatarUrl = (e) => {
		if (e) e.preventDefault();
		const url = avatarUrlInput.trim();
		if (!url) {
			showToast("Please enter an image URL", "error");
			return;
		}
		updateAvatar(url);
		setAvatarUrlInput("");
		showToast("Profile picture updated from URL!");
		setIsAvatarModalOpen(false);
	};
	const handleResetAvatar = () => {
		updateAvatar(null);
		showToast("Profile picture reset to default (AR Initials)");
		setIsAvatarModalOpen(false);
	};
	// Save Cover Config Helper
	const updateCoverConfig = (config) => {
		setCoverConfig(config);
		try {
			localStorage.setItem("albert_robledo_cover_v2", JSON.stringify(config));
		} catch (err) {
			console.warn("LocalStorage write failed:", err);
		}
	};
	// Handle Preset Theme Click
	const handleSelectPreset = (gradientClass) => {
		updateCoverConfig({
			type: "gradient",
			value: gradientClass
		});
		showToast("Theme preset applied!");
		setIsCoverModalOpen(false);
	};
	// Handle Image URL
	const handleApplyImageUrl = (e) => {
		if (e) e.preventDefault();
		const url = imageUrlInput.trim();
		if (!url) {
			showToast("Please enter an image URL", "error");
			return;
		}
		updateCoverConfig({
			type: "image",
			value: url
		});
		setImageUrlInput("");
		showToast("Cover photo updated from URL!");
		setIsCoverModalOpen(false);
	};
	// Handle Video URL
	const handleApplyVideoUrl = (e) => {
		if (e) e.preventDefault();
		const url = videoUrlInput.trim();
		if (!url) {
			showToast("Please enter a video URL", "error");
			return;
		}
		updateCoverConfig({
			type: "video",
			value: url
		});
		setVideoUrlInput("");
		showToast("Cover video updated from URL!");
		setIsCoverModalOpen(false);
	};
	// Handle Image File Upload
	const handleImageFileUpload = (e) => {
		const file = e.target.files?.[0];
		if (!file) return;
		if (!file.type.startsWith("image/")) {
			showToast("Please upload a valid image file", "error");
			return;
		}
		const reader = new FileReader();
		reader.onload = (event) => {
			const result = event.target?.result;
			if (result) {
				updateCoverConfig({
					type: "image",
					value: result
				});
				showToast("Cover photo updated from file!");
				setIsCoverModalOpen(false);
			}
		};
		reader.readAsDataURL(file);
	};
	// Handle Video File Upload
	const handleVideoFileUpload = (e) => {
		const file = e.target.files?.[0];
		if (!file) return;
		if (!file.type.startsWith("video/")) {
			showToast("Please select a valid video file (MP4, WEBM)", "error");
			return;
		}
		const videoUrl = URL.createObjectURL(file);
		updateCoverConfig({
			type: "video",
			value: videoUrl
		});
		showToast("Cover video loaded from file!");
		setIsCoverModalOpen(false);
	};
	// Reset Default Cover
	const handleResetCover = () => {
		const defaultConfig = {
			type: "gradient",
			value: "cover-gradient-1"
		};
		updateCoverConfig(defaultConfig);
		showToast("Reset to default cover banner");
		setIsCoverModalOpen(false);
	};
	// Copy Phone Number
	const handleCopyPhoneNumber = (number) => {
		navigator.clipboard.writeText(number).then(() => {
			setCopiedNumber(true);
			showToast("Phone number 0966 024 8221 copied!");
			setTimeout(() => setCopiedNumber(false), 2e3);
		}).catch(() => {
			showToast("Failed to copy number", "error");
		});
	};
	// Share Profile
	const handleShareProfile = () => {
		if (navigator.share) {
			navigator.share({
				title: "Albert Robledo | Personal Profile",
				text: "Connect with Albert Robledo on social media or direct contact!",
				url: window.location.href
			}).catch(() => {});
		} else {
			navigator.clipboard.writeText(window.location.href);
			showToast("Profile link copied to clipboard!");
		}
	};
	// Download Handlers
	const handleDownloadZip = async () => {
		setIsDownloading(true);
		showToast("Packing project into ZIP file...", "info");
		try {
			await downloadProjectZip();
			showToast("Project ZIP downloaded! 📦", "success");
		} catch (err) {
			console.error(err);
			showToast("Failed to generate ZIP", "error");
		} finally {
			setIsDownloading(false);
		}
	};
	const handleDownloadHtml = () => {
		downloadStandaloneHtml(avatarUrl, glowEnabled);
		showToast("Single-file offline HTML downloaded! 📄", "success");
	};
	const handleDownloadContact = () => {
		downloadVCard();
		showToast("Contact card (.vcf) downloaded! 📱", "success");
	};
	// Manage Video autoplay
	useEffect(() => {
		if (coverConfig.type === "video" && videoElementRef.current) {
			videoElementRef.current.src = coverConfig.value;
			videoElementRef.current.play().catch((err) => {
				console.log("Video autoplay prevented or format issue", err);
			});
		}
	}, [coverConfig]);
	// Show "Follow me on social" notification toast 5 seconds after page load
	useEffect(() => {
		const timer = setTimeout(() => {
			setShowSocialToast(true);
		}, 5e3);
		return () => clearTimeout(timer);
	}, []);
	const currentYear = new Date().getFullYear();
	return /* @__PURE__ */ _jsxDEV("div", {
		className: `min-h-screen text-slate-100 flex flex-col justify-between items-center relative overflow-x-hidden font-sans selection:bg-purple-500 selection:text-white pb-12 transition-colors duration-500 bg-slate-950`,
		children: [
			/* @__PURE__ */ _jsxDEV("div", {
				className: "fixed inset-0 pointer-events-none z-0 overflow-hidden select-none",
				children: [
					/* @__PURE__ */ _jsxDEV("div", { className: `absolute -top-32 -left-32 w-96 h-96 rounded-full transition-opacity duration-700 ${glowEnabled ? "bg-orb-1 animate-float-slow opacity-100" : "opacity-0"}` }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 383,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: `absolute top-1/2 -right-32 w-96 h-96 rounded-full transition-opacity duration-700 ${glowEnabled ? "bg-orb-2 animate-float-slow opacity-100" : "opacity-0"}`,
						style: { animationDelay: "-2.5s" }
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 388,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: `absolute -bottom-32 left-1/3 w-96 h-96 rounded-full transition-opacity duration-700 ${glowEnabled ? "bg-orb-3 animate-float-slow opacity-100" : "opacity-0"}`,
						style: { animationDelay: "-4.5s" }
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 394,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("div", { className: "absolute inset-0 bg-[radial-gradient(#334155_1px,transparent_1px)] [background-size:24px_24px] opacity-20" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 402,
						columnNumber: 9
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 381,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("header", {
				className: "w-full max-w-lg px-4 pt-4 sm:pt-6 z-20 flex items-center justify-between gap-2",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center gap-2",
					children: /* @__PURE__ */ _jsxDEV("button", {
						onClick: toggleGlow,
						"aria-label": glowEnabled ? "Turn off glowing colors" : "Turn on glowing colors",
						className: `group relative flex items-center gap-2 px-3.5 py-1.5 rounded-full text-xs font-semibold backdrop-blur-xl border transition-all duration-300 shadow-lg cursor-pointer active:scale-95 ${glowEnabled ? "bg-purple-950/70 border-purple-500/40 text-purple-200 shadow-purple-900/40 hover:bg-purple-900/80 hover:border-purple-400" : "bg-slate-900/80 border-slate-700/60 text-slate-400 hover:text-slate-200 hover:bg-slate-800"}`,
						title: glowEnabled ? "Click to turn off all glowing colors" : "Click to turn on all glowing colors",
						children: glowEnabled ? /* @__PURE__ */ _jsxDEV(_Fragment, { children: [
							/* @__PURE__ */ _jsxDEV("span", {
								className: "relative flex h-2 w-2",
								children: [/* @__PURE__ */ _jsxDEV("span", { className: "animate-ping absolute inline-flex h-full w-full rounded-full bg-purple-400 opacity-75" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 422,
									columnNumber: 19
								}, this), /* @__PURE__ */ _jsxDEV("span", { className: "relative inline-flex rounded-full h-2 w-2 bg-purple-500" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 423,
									columnNumber: 19
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 421,
								columnNumber: 17
							}, this),
							/* @__PURE__ */ _jsxDEV(Sparkles, { className: "w-3.5 h-3.5 text-purple-300 group-hover:rotate-12 transition-transform" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 425,
								columnNumber: 17
							}, this),
							/* @__PURE__ */ _jsxDEV("span", {
								className: "tracking-wide",
								children: ["Glow: ", /* @__PURE__ */ _jsxDEV("strong", {
									className: "text-white",
									children: "ON"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 426,
									columnNumber: 55
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 426,
								columnNumber: 17
							}, this)
						] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 420,
							columnNumber: 15
						}, this) : /* @__PURE__ */ _jsxDEV(_Fragment, { children: [
							/* @__PURE__ */ _jsxDEV("span", { className: "inline-flex rounded-full h-2 w-2 bg-slate-600" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 430,
								columnNumber: 17
							}, this),
							/* @__PURE__ */ _jsxDEV(Moon, { className: "w-3.5 h-3.5 text-slate-400" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 431,
								columnNumber: 17
							}, this),
							/* @__PURE__ */ _jsxDEV("span", {
								className: "tracking-wide",
								children: ["Glow: ", /* @__PURE__ */ _jsxDEV("strong", {
									className: "text-slate-400",
									children: "OFF"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 432,
									columnNumber: 55
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 432,
								columnNumber: 17
							}, this)
						] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 429,
							columnNumber: 15
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 409,
						columnNumber: 11
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 407,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center gap-2",
					children: [
						/* @__PURE__ */ _jsxDEV("button", {
							onClick: () => setIsDownloadModalOpen(true),
							className: "px-2.5 py-1.5 rounded-full bg-emerald-950/60 hover:bg-emerald-900/80 border border-emerald-500/40 text-emerald-300 hover:text-white transition-all backdrop-blur-md shadow-md active:scale-95 cursor-pointer flex items-center gap-1.5 text-xs font-semibold",
							title: "Download Project Files (ZIP, HTML, VCF)",
							"aria-label": "Download Project",
							children: [/* @__PURE__ */ _jsxDEV(Download, { className: "w-3.5 h-3.5 text-emerald-400" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 446,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("span", {
								className: "hidden sm:inline",
								children: "Download"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 447,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 440,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("button", {
							onClick: () => setIsQrModalOpen(true),
							className: "p-2 rounded-full bg-slate-900/80 hover:bg-slate-800 border border-slate-700/60 text-slate-300 hover:text-white transition-all backdrop-blur-md shadow-md active:scale-95 cursor-pointer",
							title: "Show Profile QR Code",
							"aria-label": "QR Code",
							children: /* @__PURE__ */ _jsxDEV(QrCode, { className: "w-3.5 h-3.5" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 456,
								columnNumber: 13
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 450,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("button", {
							onClick: handleShareProfile,
							className: "p-2 rounded-full bg-slate-900/80 hover:bg-slate-800 border border-slate-700/60 text-slate-300 hover:text-white transition-all backdrop-blur-md shadow-md active:scale-95 cursor-pointer",
							title: "Share Profile",
							"aria-label": "Share",
							children: /* @__PURE__ */ _jsxDEV(Share2, { className: "w-3.5 h-3.5 text-blue-400" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 465,
								columnNumber: 13
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 459,
							columnNumber: 11
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 439,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 406,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("main", {
				className: "w-full max-w-lg px-4 sm:px-6 pt-3 z-10 flex flex-col items-center",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: `w-full glass-card rounded-3xl overflow-hidden shadow-2xl relative transition-all duration-500 border ${glowEnabled ? "border-slate-800/90 shadow-slate-950/80" : "border-slate-800 bg-slate-950/90 shadow-none"}`,
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: `relative w-full h-44 sm:h-52 bg-slate-900 bg-cover bg-center transition-all duration-500 overflow-hidden ${coverConfig.type === "gradient" ? coverConfig.value : ""}`,
						style: { backgroundImage: coverConfig.type === "image" ? `url("${coverConfig.value}")` : undefined },
						children: [
							coverConfig.type === "video" && /* @__PURE__ */ _jsxDEV("video", {
								ref: videoElementRef,
								className: "absolute inset-0 w-full h-full object-cover",
								autoPlay: true,
								muted: true,
								loop: true,
								playsInline: true
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 487,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("div", { className: "absolute inset-0 bg-gradient-to-b from-black/35 via-transparent to-slate-950/95 pointer-events-none z-10" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 498,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("button", {
								onClick: () => setIsCoverModalOpen(true),
								className: "absolute top-3.5 right-3.5 z-20 bg-slate-900/80 hover:bg-slate-900 text-white text-xs font-semibold px-3 py-1.5 sm:px-3.5 sm:py-2 rounded-xl backdrop-blur-md border border-white/15 shadow-lg flex items-center gap-2 transition-all hover:scale-105 active:scale-95 group cursor-pointer",
								title: "Change Cover Banner or Background Theme",
								children: [/* @__PURE__ */ _jsxDEV(Camera, { className: "w-3.5 h-3.5 text-blue-400 group-hover:rotate-12 transition-transform" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 506,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Edit Cover" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 507,
									columnNumber: 15
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 501,
								columnNumber: 13
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 477,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "px-5 sm:px-8 pb-8 -mt-16 sm:-mt-20 relative z-10 flex flex-col items-center text-center",
						children: [
							/* @__PURE__ */ _jsxDEV("div", {
								className: "relative mb-4 group",
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: `glow-ring transition-all duration-500 ${glowEnabled ? "glow-active" : "glow-disabled"}`,
									children: /* @__PURE__ */ _jsxDEV("div", {
										className: "relative z-10 w-28 h-28 sm:w-32 sm:h-32 rounded-full bg-slate-950 p-1 flex items-center justify-center",
										children: /* @__PURE__ */ _jsxDEV("div", {
											onClick: () => setIsAvatarModalOpen(true),
											className: `w-full h-full rounded-full flex items-center justify-center shadow-inner overflow-hidden border transition-all duration-300 relative cursor-pointer group-hover:ring-2 group-hover:ring-blue-500/50 ${glowEnabled ? "bg-gradient-to-tr from-slate-900 via-slate-800 to-slate-900 border-slate-700/60" : "bg-slate-900 border-slate-800"}`,
											title: "Click to Change Profile Picture",
											children: [avatarUrl ? /* @__PURE__ */ _jsxDEV("img", {
												src: avatarUrl,
												alt: "Albert Robledo",
												className: "w-full h-full object-cover rounded-full",
												onError: () => {
													showToast("Failed to load profile photo URL", "error");
													updateAvatar(null);
												}
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 528,
												columnNumber: 23
											}, this) : /* @__PURE__ */ _jsxDEV("span", {
												className: `text-3xl sm:text-4xl font-black tracking-wider select-none transition-all duration-500 ${glowEnabled ? "bg-gradient-to-r from-blue-400 via-indigo-300 to-purple-400 bg-clip-text text-transparent drop-shadow-sm" : "text-slate-200"}`,
												children: "AR"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 538,
												columnNumber: 23
											}, this), /* @__PURE__ */ _jsxDEV("div", {
												className: "absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex flex-col items-center justify-center gap-1 text-white",
												children: [/* @__PURE__ */ _jsxDEV(Camera, { className: "w-5 h-5 text-blue-400" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 549,
													columnNumber: 23
												}, this), /* @__PURE__ */ _jsxDEV("span", {
													className: "text-[10px] font-bold tracking-tight",
													children: "Edit Photo"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 550,
													columnNumber: 23
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 548,
												columnNumber: 21
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 518,
											columnNumber: 19
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 517,
										columnNumber: 17
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 516,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV("button", {
									onClick: () => setIsAvatarModalOpen(true),
									className: "absolute bottom-1 right-1 z-20 w-8 h-8 rounded-full bg-blue-600 hover:bg-blue-500 text-white border-2 border-slate-950 shadow-lg flex items-center justify-center transition-all duration-200 hover:scale-110 active:scale-95 cursor-pointer",
									title: "Change Profile Picture",
									"aria-label": "Change Profile Picture",
									children: /* @__PURE__ */ _jsxDEV(Camera, { className: "w-3.5 h-3.5" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 563,
										columnNumber: 17
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 557,
									columnNumber: 15
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 515,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("h1", {
								className: "text-2xl sm:text-3xl font-extrabold tracking-tight text-white mb-1.5 flex items-center justify-center gap-2",
								children: [/* @__PURE__ */ _jsxDEV("span", { children: "Albert Robledo" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 569,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV("span", {
									title: "Verified Profile",
									className: "inline-flex items-center text-blue-500",
									children: /* @__PURE__ */ _jsxDEV(CheckCircle2, { className: "w-5 h-5 fill-blue-500 text-slate-950" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 571,
										columnNumber: 17
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 570,
									columnNumber: 15
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 568,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center gap-2 mb-3",
								children: /* @__PURE__ */ _jsxDEV("span", {
									className: `inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-medium border transition-colors ${glowEnabled ? "bg-emerald-500/10 text-emerald-400 border-emerald-500/20" : "bg-slate-900 text-slate-300 border-slate-800"}`,
									children: [/* @__PURE__ */ _jsxDEV("span", { className: `w-2 h-2 rounded-full ${glowEnabled ? "bg-emerald-400 animate-pulse" : "bg-emerald-500"}` }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 582,
										columnNumber: 17
									}, this), "Available for Contact"]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 577,
									columnNumber: 15
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 576,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("p", {
								className: "text-xs sm:text-sm text-slate-300 max-w-sm leading-relaxed mb-6 font-light",
								children: "Welcome to my personal landing page. Connect with me on social media or reach out directly!"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 588,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "w-full bg-slate-900/80 rounded-2xl p-4 mb-6 border border-slate-800/90 shadow-inner",
								children: /* @__PURE__ */ _jsxDEV("div", {
									className: "flex items-center justify-between gap-3",
									children: [/* @__PURE__ */ _jsxDEV("div", {
										className: "flex items-center gap-3.5 overflow-hidden text-left",
										children: [/* @__PURE__ */ _jsxDEV("div", {
											className: `w-11 h-11 rounded-xl flex items-center justify-center shrink-0 border transition-all ${glowEnabled ? "bg-blue-500/15 border-blue-500/30 text-blue-400" : "bg-slate-800 border-slate-700 text-slate-300"}`,
											children: /* @__PURE__ */ _jsxDEV(PhoneCall, { className: "w-5 h-5" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 601,
												columnNumber: 21
											}, this)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 596,
											columnNumber: 19
										}, this), /* @__PURE__ */ _jsxDEV("div", {
											className: "truncate",
											children: [/* @__PURE__ */ _jsxDEV("p", {
												className: "text-[10px] uppercase font-bold tracking-wider text-slate-400",
												children: "Direct Contact"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 604,
												columnNumber: 21
											}, this), /* @__PURE__ */ _jsxDEV("p", {
												className: "text-sm sm:text-base font-bold text-slate-100 font-mono tracking-tight",
												children: "0966 024 8221"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 605,
												columnNumber: 21
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 603,
											columnNumber: 19
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 595,
										columnNumber: 17
									}, this), /* @__PURE__ */ _jsxDEV("div", {
										className: "flex items-center gap-2 shrink-0",
										children: [
											/* @__PURE__ */ _jsxDEV("a", {
												href: "tel:09660248221",
												className: `w-9 h-9 sm:w-10 sm:h-10 rounded-xl border flex items-center justify-center transition-all duration-200 active:scale-95 ${glowEnabled ? "bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-400 border-emerald-500/30" : "bg-slate-800 hover:bg-slate-700 text-slate-200 border-slate-700"}`,
												title: "Call Directly",
												"aria-label": "Call",
												children: /* @__PURE__ */ _jsxDEV(Phone, { className: "w-4 h-4" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 624,
													columnNumber: 21
												}, this)
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 614,
												columnNumber: 19
											}, this),
											/* @__PURE__ */ _jsxDEV("a", {
												href: "sms:09660248221",
												className: `w-9 h-9 sm:w-10 sm:h-10 rounded-xl border flex items-center justify-center transition-all duration-200 active:scale-95 ${glowEnabled ? "bg-indigo-500/20 hover:bg-indigo-500/30 text-indigo-400 border-indigo-500/30" : "bg-slate-800 hover:bg-slate-700 text-slate-200 border-slate-700"}`,
												title: "Send SMS Message",
												"aria-label": "Send Message",
												children: /* @__PURE__ */ _jsxDEV(MessageSquare, { className: "w-4 h-4" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 638,
													columnNumber: 21
												}, this)
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 628,
												columnNumber: 19
											}, this),
											/* @__PURE__ */ _jsxDEV("button", {
												onClick: () => handleCopyPhoneNumber("09660248221"),
												className: "w-9 h-9 sm:w-10 sm:h-10 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 flex items-center justify-center transition-all duration-200 active:scale-95 group cursor-pointer",
												title: "Copy Phone Number",
												"aria-label": "Copy Phone Number",
												children: copiedNumber ? /* @__PURE__ */ _jsxDEV(Check, { className: "w-4 h-4 text-emerald-400" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 649,
													columnNumber: 23
												}, this) : /* @__PURE__ */ _jsxDEV(Copy, { className: "w-4 h-4 group-hover:text-white" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 651,
													columnNumber: 23
												}, this)
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 642,
												columnNumber: 19
											}, this)
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 612,
										columnNumber: 17
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 594,
									columnNumber: 15
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 593,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								id: "social-links-section",
								className: "w-full flex flex-col gap-3.5 scroll-mt-20",
								children: [
									/* @__PURE__ */ _jsxDEV("a", {
										href: "https://www.facebook.com/profile.php?id=61594256549921",
										target: "_blank",
										rel: "noopener noreferrer",
										className: "glass-card glass-card-hover rounded-2xl p-4 flex items-center justify-between group text-left cursor-pointer",
										children: [/* @__PURE__ */ _jsxDEV("div", {
											className: "flex items-center gap-4",
											children: [/* @__PURE__ */ _jsxDEV("div", {
												className: "w-11 h-11 rounded-xl bg-[#1877F2]/15 border border-[#1877F2]/30 flex items-center justify-center text-[#1877F2] group-hover:scale-110 transition-transform duration-300",
												children: /* @__PURE__ */ _jsxDEV("i", { className: "fa-brands fa-facebook-f text-lg" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 670,
													columnNumber: 21
												}, this)
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 669,
												columnNumber: 19
											}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h2", {
												className: "text-sm font-bold text-white group-hover:text-blue-400 transition-colors flex items-center gap-1.5",
												children: ["Facebook", /* @__PURE__ */ _jsxDEV(ExternalLink, { className: "w-3 h-3 opacity-0 group-hover:opacity-100 transition-opacity" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 675,
													columnNumber: 23
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 673,
												columnNumber: 21
											}, this), /* @__PURE__ */ _jsxDEV("p", {
												className: "text-xs text-slate-400",
												children: "Albert Robledo"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 677,
												columnNumber: 21
											}, this)] }, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 672,
												columnNumber: 19
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 668,
											columnNumber: 17
										}, this), /* @__PURE__ */ _jsxDEV("div", {
											className: "w-8 h-8 rounded-full bg-slate-800/60 flex items-center justify-center text-slate-400 group-hover:text-white group-hover:translate-x-1 transition-all duration-300",
											children: /* @__PURE__ */ _jsxDEV(ChevronRight, { className: "w-4 h-4" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 681,
												columnNumber: 19
											}, this)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 680,
											columnNumber: 17
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 662,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ _jsxDEV("a", {
										href: "https://www.tiktok.com/@_kkwkwk?_r=1&_t=ZS-9AJkkE0m4W5",
										target: "_blank",
										rel: "noopener noreferrer",
										className: "glass-card glass-card-hover rounded-2xl p-4 flex items-center justify-between group text-left cursor-pointer",
										children: [/* @__PURE__ */ _jsxDEV("div", {
											className: "flex items-center gap-4",
											children: [/* @__PURE__ */ _jsxDEV("div", {
												className: "w-11 h-11 rounded-xl bg-slate-800 border border-slate-700 flex items-center justify-center text-white group-hover:scale-110 transition-transform duration-300 shadow-sm",
												children: /* @__PURE__ */ _jsxDEV("i", { className: "fa-brands fa-tiktok text-lg" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 694,
													columnNumber: 21
												}, this)
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 693,
												columnNumber: 19
											}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h2", {
												className: "text-sm font-bold text-white group-hover:text-pink-400 transition-colors flex items-center gap-1.5",
												children: ["TikTok", /* @__PURE__ */ _jsxDEV(ExternalLink, { className: "w-3 h-3 opacity-0 group-hover:opacity-100 transition-opacity" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 699,
													columnNumber: 23
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 697,
												columnNumber: 21
											}, this), /* @__PURE__ */ _jsxDEV("p", {
												className: "text-xs text-slate-400",
												children: "@_kkwkwk"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 701,
												columnNumber: 21
											}, this)] }, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 696,
												columnNumber: 19
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 692,
											columnNumber: 17
										}, this), /* @__PURE__ */ _jsxDEV("div", {
											className: "w-8 h-8 rounded-full bg-slate-800/60 flex items-center justify-center text-slate-400 group-hover:text-white group-hover:translate-x-1 transition-all duration-300",
											children: /* @__PURE__ */ _jsxDEV(ChevronRight, { className: "w-4 h-4" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 705,
												columnNumber: 19
											}, this)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 704,
											columnNumber: 17
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 686,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ _jsxDEV("a", {
										href: "https://www.instagram.com/_bluuuee00?stkn=cWMyc2o3bTBoeTJh",
										target: "_blank",
										rel: "noopener noreferrer",
										className: "glass-card glass-card-hover rounded-2xl p-4 flex items-center justify-between group text-left cursor-pointer",
										children: [/* @__PURE__ */ _jsxDEV("div", {
											className: "flex items-center gap-4",
											children: [/* @__PURE__ */ _jsxDEV("div", {
												className: "w-11 h-11 rounded-xl bg-gradient-to-tr from-[#f09433] via-[#dc2743] to-[#bc1888] p-[1px] group-hover:scale-110 transition-transform duration-300",
												children: /* @__PURE__ */ _jsxDEV("div", {
													className: "w-full h-full bg-slate-950 rounded-[11px] flex items-center justify-center text-[#E4405F]",
													children: /* @__PURE__ */ _jsxDEV("i", { className: "fa-brands fa-instagram text-lg" }, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 719,
														columnNumber: 23
													}, this)
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 718,
													columnNumber: 21
												}, this)
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 717,
												columnNumber: 19
											}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h2", {
												className: "text-sm font-bold text-white group-hover:text-pink-400 transition-colors flex items-center gap-1.5",
												children: ["Instagram", /* @__PURE__ */ _jsxDEV(ExternalLink, { className: "w-3 h-3 opacity-0 group-hover:opacity-100 transition-opacity" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 725,
													columnNumber: 23
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 723,
												columnNumber: 21
											}, this), /* @__PURE__ */ _jsxDEV("p", {
												className: "text-xs text-slate-400",
												children: "@_bluuuee00"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 727,
												columnNumber: 21
											}, this)] }, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 722,
												columnNumber: 19
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 716,
											columnNumber: 17
										}, this), /* @__PURE__ */ _jsxDEV("div", {
											className: "w-8 h-8 rounded-full bg-slate-800/60 flex items-center justify-center text-slate-400 group-hover:text-white group-hover:translate-x-1 transition-all duration-300",
											children: /* @__PURE__ */ _jsxDEV(ChevronRight, { className: "w-4 h-4" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 731,
												columnNumber: 19
											}, this)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 730,
											columnNumber: 17
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 710,
										columnNumber: 15
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 659,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "w-full mt-6 pt-5 border-t border-slate-800/80 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs",
								children: [/* @__PURE__ */ _jsxDEV("button", {
									onClick: () => setIsAvatarModalOpen(true),
									className: "w-full sm:w-auto px-3.5 py-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-300 hover:text-white border border-slate-800 flex items-center justify-center gap-2 transition-all cursor-pointer",
									children: [/* @__PURE__ */ _jsxDEV(Camera, { className: "w-3.5 h-3.5 text-blue-400" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 743,
										columnNumber: 17
									}, this), "Change Profile Picture"]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 739,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "flex items-center justify-between w-full sm:w-auto gap-2",
									children: [/* @__PURE__ */ _jsxDEV("span", {
										className: "text-slate-400 flex items-center gap-1.5 font-medium",
										children: [glowEnabled ? /* @__PURE__ */ _jsxDEV(Zap, { className: "w-3.5 h-3.5 text-purple-400" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 750,
											columnNumber: 21
										}, this) : /* @__PURE__ */ _jsxDEV(ZapOff, { className: "w-3.5 h-3.5 text-slate-500" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 752,
											columnNumber: 21
										}, this), "Glow Colors"]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 748,
										columnNumber: 17
									}, this), /* @__PURE__ */ _jsxDEV("button", {
										onClick: toggleGlow,
										className: `px-3 py-1 rounded-full text-xs font-semibold border transition-all cursor-pointer flex items-center gap-1.5 ${glowEnabled ? "bg-purple-900/40 text-purple-300 border-purple-500/40 hover:bg-purple-900/60" : "bg-slate-800 text-slate-300 border-slate-700 hover:bg-slate-700"}`,
										children: glowEnabled ? "Turn Off Glow" : "Turn On Glow"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 756,
										columnNumber: 17
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 747,
									columnNumber: 15
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 738,
								columnNumber: 13
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 512,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 472,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("footer", {
					className: "w-full flex flex-col items-center gap-4 mt-8",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "flex flex-wrap items-center justify-center gap-2.5",
						children: [/* @__PURE__ */ _jsxDEV("button", {
							onClick: handleShareProfile,
							className: "text-xs font-semibold text-slate-300 hover:text-white flex items-center gap-2 py-2.5 px-4 rounded-full bg-slate-900/80 hover:bg-slate-800 border border-slate-700/60 shadow-lg transition-all active:scale-95 cursor-pointer",
							children: [/* @__PURE__ */ _jsxDEV(Share2, { className: "w-3.5 h-3.5 text-blue-400" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 779,
								columnNumber: 15
							}, this), "Share Profile"]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 775,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("button", {
							onClick: () => setIsDownloadModalOpen(true),
							className: "text-xs font-semibold text-emerald-300 hover:text-white flex items-center gap-2 py-2.5 px-4 rounded-full bg-emerald-950/40 hover:bg-emerald-900/60 border border-emerald-500/40 shadow-lg transition-all active:scale-95 cursor-pointer",
							children: [/* @__PURE__ */ _jsxDEV(Download, { className: "w-3.5 h-3.5 text-emerald-400" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 787,
								columnNumber: 15
							}, this), "Download Project"]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 783,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 774,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("p", {
						className: "text-[11px] text-slate-500 font-medium",
						children: [
							"© ",
							currentYear,
							" Albert Robledo • Built for quick connection"
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 792,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 773,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 471,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV(AnimatePresence, { children: isAvatarModalOpen && /* @__PURE__ */ _jsxDEV(motion.div, {
				initial: { opacity: 0 },
				animate: { opacity: 1 },
				exit: { opacity: 0 },
				transition: {
					duration: .24,
					ease: "easeOut"
				},
				onClick: (e) => {
					if (e.target === e.currentTarget) setIsAvatarModalOpen(false);
				},
				className: "fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-md",
				children: /* @__PURE__ */ _jsxDEV(motion.div, {
					initial: {
						opacity: 0,
						y: 44,
						scale: .94
					},
					animate: {
						opacity: 1,
						y: 0,
						scale: 1
					},
					exit: {
						opacity: 0,
						y: 30,
						scale: .95
					},
					transition: {
						type: "spring",
						damping: 27,
						stiffness: 330,
						mass: .8
					},
					className: "bg-slate-900 border border-slate-800 rounded-3xl w-full max-w-md p-6 shadow-2xl relative max-h-[90vh] overflow-y-auto",
					children: [
						/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center justify-between pb-4 border-b border-slate-800 mb-5",
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center gap-2.5",
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "w-8 h-8 rounded-lg bg-blue-500/10 border border-blue-500/20 flex items-center justify-center text-blue-400",
									children: /* @__PURE__ */ _jsxDEV(User, { className: "w-4 h-4" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 823,
										columnNumber: 21
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 822,
									columnNumber: 19
								}, this), /* @__PURE__ */ _jsxDEV("h3", {
									className: "text-base font-bold text-white",
									children: "Change Profile Picture"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 825,
									columnNumber: 19
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 821,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("button", {
								onClick: () => setIsAvatarModalOpen(false),
								className: "w-8 h-8 rounded-full bg-slate-800 text-slate-400 hover:text-white flex items-center justify-center transition-colors cursor-pointer",
								"aria-label": "Close Modal",
								children: /* @__PURE__ */ _jsxDEV(X, { className: "w-4 h-4" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 832,
									columnNumber: 19
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 827,
								columnNumber: 17
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 820,
							columnNumber: 15
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "flex flex-col items-center mb-6 p-4 bg-slate-950/60 rounded-2xl border border-slate-800/80",
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: `glow-ring mb-3 transition-all duration-300 ${glowEnabled ? "glow-active" : "glow-disabled"}`,
								children: /* @__PURE__ */ _jsxDEV("div", {
									className: "relative z-10 w-24 h-24 rounded-full bg-slate-950 p-1 flex items-center justify-center",
									children: /* @__PURE__ */ _jsxDEV("div", {
										className: `w-full h-full rounded-full flex items-center justify-center shadow-inner overflow-hidden border ${glowEnabled ? "bg-gradient-to-tr from-slate-900 via-slate-800 to-slate-900 border-slate-700/60" : "bg-slate-900 border-slate-800"}`,
										children: avatarUrl ? /* @__PURE__ */ _jsxDEV("img", {
											src: avatarUrl,
											alt: "Preview",
											className: "w-full h-full object-cover rounded-full"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 846,
											columnNumber: 25
										}, this) : /* @__PURE__ */ _jsxDEV("span", {
											className: `text-2xl font-black ${glowEnabled ? "bg-gradient-to-r from-blue-400 via-indigo-300 to-purple-400 bg-clip-text text-transparent" : "text-slate-200"}`,
											children: "AR"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 848,
											columnNumber: 25
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 840,
										columnNumber: 21
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 839,
									columnNumber: 19
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 838,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("span", {
								className: "text-xs text-slate-400 font-medium",
								children: avatarUrl ? "Current Custom Photo" : "Default Initials (AR)"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 857,
								columnNumber: 17
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 837,
							columnNumber: 15
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "space-y-5",
							children: [
								/* @__PURE__ */ _jsxDEV("div", {
									className: "p-3.5 bg-slate-950/60 rounded-2xl border border-slate-800",
									children: [/* @__PURE__ */ _jsxDEV("label", {
										className: "block text-xs font-bold uppercase tracking-wider text-blue-400 mb-2.5 flex items-center gap-1.5",
										children: [/* @__PURE__ */ _jsxDEV(UploadCloud, { className: "w-3.5 h-3.5" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 866,
											columnNumber: 21
										}, this), " Upload from Device"]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 865,
										columnNumber: 19
									}, this), /* @__PURE__ */ _jsxDEV("label", {
										className: "flex flex-col items-center justify-center w-full h-20 border-2 border-dashed border-slate-700 hover:border-blue-500 rounded-xl cursor-pointer bg-slate-900/50 hover:bg-slate-800/40 transition-all group",
										children: [/* @__PURE__ */ _jsxDEV("div", {
											className: "flex flex-col items-center justify-center pt-2 pb-2",
											children: [
												/* @__PURE__ */ _jsxDEV(Camera, { className: "w-5 h-5 text-slate-400 group-hover:text-blue-400 mb-1 transition-colors" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 870,
													columnNumber: 23
												}, this),
												/* @__PURE__ */ _jsxDEV("p", {
													className: "text-xs text-slate-300 font-medium",
													children: "Choose a photo file"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 871,
													columnNumber: 23
												}, this),
												/* @__PURE__ */ _jsxDEV("p", {
													className: "text-[10px] text-slate-500",
													children: "PNG, JPG, WEBP, GIF supported"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 872,
													columnNumber: 23
												}, this)
											]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 869,
											columnNumber: 21
										}, this), /* @__PURE__ */ _jsxDEV("input", {
											type: "file",
											accept: "image/*",
											className: "hidden",
											onChange: handleAvatarFileUpload
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 874,
											columnNumber: 21
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 868,
										columnNumber: 19
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 864,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "p-3.5 bg-slate-950/60 rounded-2xl border border-slate-800",
									children: [/* @__PURE__ */ _jsxDEV("label", {
										className: "block text-xs font-bold uppercase tracking-wider text-indigo-400 mb-2.5 flex items-center gap-1.5",
										children: [/* @__PURE__ */ _jsxDEV(ImageIcon, { className: "w-3.5 h-3.5" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 886,
											columnNumber: 21
										}, this), " Photo Web Link (URL)"]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 885,
										columnNumber: 19
									}, this), /* @__PURE__ */ _jsxDEV("form", {
										onSubmit: handleApplyAvatarUrl,
										className: "flex gap-2",
										children: [/* @__PURE__ */ _jsxDEV("input", {
											type: "url",
											value: avatarUrlInput,
											onChange: (e) => setAvatarUrlInput(e.target.value),
											placeholder: "https://example.com/photo.jpg",
											className: "flex-1 bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500 transition-colors"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 889,
											columnNumber: 21
										}, this), /* @__PURE__ */ _jsxDEV("button", {
											type: "submit",
											className: "bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold px-3.5 py-2 rounded-xl transition-colors shrink-0 cursor-pointer",
											children: "Apply URL"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 896,
											columnNumber: 21
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 888,
										columnNumber: 19
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 884,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
									className: "block text-xs font-bold uppercase tracking-wider text-slate-400 mb-2",
									children: "Preset Avatars"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 907,
									columnNumber: 19
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "grid grid-cols-4 gap-2.5",
									children: PRESET_AVATARS.map((preset, index) => /* @__PURE__ */ _jsxDEV("button", {
										onClick: () => {
											updateAvatar(preset.url);
											showToast(`Selected ${preset.name} avatar!`);
											setIsAvatarModalOpen(false);
										},
										className: "group flex flex-col items-center gap-1.5 p-2 rounded-xl bg-slate-950/60 hover:bg-slate-800 border border-slate-800 hover:border-blue-500/60 transition-all cursor-pointer",
										title: preset.name,
										children: [/* @__PURE__ */ _jsxDEV("img", {
											src: preset.url,
											alt: preset.name,
											className: "w-11 h-11 rounded-full object-cover border border-slate-700 group-hover:scale-105 transition-transform"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 922,
											columnNumber: 25
										}, this), /* @__PURE__ */ _jsxDEV("span", {
											className: "text-[10px] text-slate-400 group-hover:text-white truncate max-w-full",
											children: preset.name
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 927,
											columnNumber: 25
										}, this)]
									}, index, true, {
										fileName: _jsxFileName,
										lineNumber: 912,
										columnNumber: 23
									}, this))
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 910,
									columnNumber: 19
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 906,
									columnNumber: 17
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 862,
							columnNumber: 15
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "mt-6 pt-4 border-t border-slate-800 flex justify-between items-center",
							children: [/* @__PURE__ */ _jsxDEV("button", {
								onClick: handleResetAvatar,
								className: "text-xs font-semibold text-rose-400 hover:text-rose-300 flex items-center gap-1.5 cursor-pointer",
								children: [/* @__PURE__ */ _jsxDEV(Trash2, { className: "w-3.5 h-3.5" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 942,
									columnNumber: 19
								}, this), "Reset to Initials (AR)"]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 938,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("button", {
								onClick: () => setIsAvatarModalOpen(false),
								className: "bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold px-4 py-2 rounded-xl transition-colors cursor-pointer",
								children: "Done"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 945,
								columnNumber: 17
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 937,
							columnNumber: 15
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 811,
					columnNumber: 13
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 801,
				columnNumber: 11
			}, this) }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 799,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV(AnimatePresence, { children: isCoverModalOpen && /* @__PURE__ */ _jsxDEV(motion.div, {
				initial: { opacity: 0 },
				animate: { opacity: 1 },
				exit: { opacity: 0 },
				transition: {
					duration: .24,
					ease: "easeOut"
				},
				onClick: (e) => {
					if (e.target === e.currentTarget) setIsCoverModalOpen(false);
				},
				className: "fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-md",
				children: /* @__PURE__ */ _jsxDEV(motion.div, {
					initial: {
						opacity: 0,
						y: 44,
						scale: .94
					},
					animate: {
						opacity: 1,
						y: 0,
						scale: 1
					},
					exit: {
						opacity: 0,
						y: 30,
						scale: .95
					},
					transition: {
						type: "spring",
						damping: 27,
						stiffness: 330,
						mass: .8
					},
					className: "bg-slate-900 border border-slate-800 rounded-3xl w-full max-w-md p-6 shadow-2xl relative max-h-[90vh] overflow-y-auto",
					children: [
						/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center justify-between pb-4 border-b border-slate-800 mb-5",
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center gap-2.5",
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "w-8 h-8 rounded-lg bg-blue-500/10 border border-blue-500/20 flex items-center justify-center text-blue-400",
									children: /* @__PURE__ */ _jsxDEV(Palette, { className: "w-4 h-4" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 983,
										columnNumber: 21
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 982,
									columnNumber: 19
								}, this), /* @__PURE__ */ _jsxDEV("h3", {
									className: "text-base font-bold text-white",
									children: "Customize Cover & Appearance"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 985,
									columnNumber: 19
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 981,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("button", {
								onClick: () => setIsCoverModalOpen(false),
								className: "w-8 h-8 rounded-full bg-slate-800 text-slate-400 hover:text-white flex items-center justify-center transition-colors cursor-pointer",
								"aria-label": "Close Modal",
								children: /* @__PURE__ */ _jsxDEV(X, { className: "w-4 h-4" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 992,
									columnNumber: 19
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 987,
								columnNumber: 17
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 980,
							columnNumber: 15
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "mb-5 p-3.5 bg-slate-950/70 rounded-2xl border border-slate-800 flex items-center justify-between",
							children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("p", {
								className: "text-xs font-bold text-white flex items-center gap-1.5",
								children: [/* @__PURE__ */ _jsxDEV(User, { className: "w-3.5 h-3.5 text-blue-400" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1e3,
									columnNumber: 21
								}, this), "Profile Picture"]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 999,
								columnNumber: 19
							}, this), /* @__PURE__ */ _jsxDEV("p", {
								className: "text-[11px] text-slate-400",
								children: avatarUrl ? "Custom photo active" : "Default \"AR\" initials"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1003,
								columnNumber: 19
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 998,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("button", {
								onClick: () => {
									setIsCoverModalOpen(false);
									setIsAvatarModalOpen(true);
								},
								className: "px-3 py-1.5 rounded-xl text-xs font-semibold bg-blue-600/20 hover:bg-blue-600/30 text-blue-300 border border-blue-500/30 transition-all cursor-pointer flex items-center gap-1",
								children: [/* @__PURE__ */ _jsxDEV(Camera, { className: "w-3 h-3" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1014,
									columnNumber: 19
								}, this), "Change Photo"]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1007,
								columnNumber: 17
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 997,
							columnNumber: 15
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "mb-5 p-3.5 bg-slate-950/70 rounded-2xl border border-slate-800 flex items-center justify-between",
							children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("p", {
								className: "text-xs font-bold text-white flex items-center gap-1.5",
								children: [/* @__PURE__ */ _jsxDEV(Sparkles, { className: "w-3.5 h-3.5 text-purple-400" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1023,
									columnNumber: 21
								}, this), "Glowing Color Effects"]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1022,
								columnNumber: 19
							}, this), /* @__PURE__ */ _jsxDEV("p", {
								className: "text-[11px] text-slate-400",
								children: glowEnabled ? "Neon glowing halo and floating orbs are active" : "Glowing effects are disabled for a clean look"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1026,
								columnNumber: 19
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1021,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("button", {
								onClick: toggleGlow,
								className: `px-3 py-1.5 rounded-xl text-xs font-bold border transition-all cursor-pointer ${glowEnabled ? "bg-purple-600 text-white border-purple-500 hover:bg-purple-500" : "bg-slate-800 text-slate-300 border-slate-700 hover:bg-slate-700"}`,
								children: glowEnabled ? "Glow: ON" : "Glow: OFF"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1030,
								columnNumber: 17
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 1020,
							columnNumber: 15
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "space-y-5",
							children: [
								/* @__PURE__ */ _jsxDEV("div", {
									className: "p-3.5 bg-slate-950/60 rounded-2xl border border-slate-800",
									children: [/* @__PURE__ */ _jsxDEV("label", {
										className: "block text-xs font-bold uppercase tracking-wider text-indigo-400 mb-2.5 flex items-center gap-1.5",
										children: [/* @__PURE__ */ _jsxDEV(Video, { className: "w-3.5 h-3.5" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1048,
											columnNumber: 21
										}, this), " Cover Video Option"]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1047,
										columnNumber: 19
									}, this), /* @__PURE__ */ _jsxDEV("div", {
										className: "space-y-3",
										children: [/* @__PURE__ */ _jsxDEV("label", {
											className: "flex flex-col items-center justify-center w-full h-20 border-2 border-dashed border-slate-700 hover:border-indigo-500 rounded-xl cursor-pointer bg-slate-900/50 hover:bg-slate-800/40 transition-all group",
											children: [/* @__PURE__ */ _jsxDEV("div", {
												className: "flex flex-col items-center justify-center pt-2 pb-2",
												children: [
													/* @__PURE__ */ _jsxDEV(Video, { className: "w-5 h-5 text-slate-400 group-hover:text-indigo-400 mb-1 transition-colors" }, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 1054,
														columnNumber: 25
													}, this),
													/* @__PURE__ */ _jsxDEV("p", {
														className: "text-xs text-slate-300 font-medium",
														children: "Upload Video File"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 1055,
														columnNumber: 25
													}, this),
													/* @__PURE__ */ _jsxDEV("p", {
														className: "text-[10px] text-slate-500",
														children: "MP4, WEBM supported"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 1056,
														columnNumber: 25
													}, this)
												]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 1053,
												columnNumber: 23
											}, this), /* @__PURE__ */ _jsxDEV("input", {
												type: "file",
												accept: "video/mp4,video/webm,video/ogg",
												className: "hidden",
												onChange: handleVideoFileUpload
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1058,
												columnNumber: 23
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1052,
											columnNumber: 21
										}, this), /* @__PURE__ */ _jsxDEV("form", {
											onSubmit: handleApplyVideoUrl,
											className: "flex gap-2",
											children: [/* @__PURE__ */ _jsxDEV("input", {
												type: "url",
												value: videoUrlInput,
												onChange: (e) => setVideoUrlInput(e.target.value),
												placeholder: "https://example.com/video.mp4",
												className: "flex-1 bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500 transition-colors"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1068,
												columnNumber: 23
											}, this), /* @__PURE__ */ _jsxDEV("button", {
												type: "submit",
												className: "bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold px-3.5 py-2 rounded-xl transition-colors shrink-0 cursor-pointer",
												children: "Apply Video"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1075,
												columnNumber: 23
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1067,
											columnNumber: 21
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1050,
										columnNumber: 19
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1046,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "p-3.5 bg-slate-950/60 rounded-2xl border border-slate-800",
									children: [/* @__PURE__ */ _jsxDEV("label", {
										className: "block text-xs font-bold uppercase tracking-wider text-blue-400 mb-2.5 flex items-center gap-1.5",
										children: [/* @__PURE__ */ _jsxDEV(ImageIcon, { className: "w-3.5 h-3.5" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1088,
											columnNumber: 21
										}, this), " Cover Image Option"]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1087,
										columnNumber: 19
									}, this), /* @__PURE__ */ _jsxDEV("div", {
										className: "space-y-3",
										children: [/* @__PURE__ */ _jsxDEV("label", {
											className: "flex flex-col items-center justify-center w-full h-20 border-2 border-dashed border-slate-700 hover:border-blue-500 rounded-xl cursor-pointer bg-slate-900/50 hover:bg-slate-800/40 transition-all group",
											children: [/* @__PURE__ */ _jsxDEV("div", {
												className: "flex flex-col items-center justify-center pt-2 pb-2",
												children: [
													/* @__PURE__ */ _jsxDEV(Camera, { className: "w-5 h-5 text-slate-400 group-hover:text-blue-400 mb-1 transition-colors" }, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 1094,
														columnNumber: 25
													}, this),
													/* @__PURE__ */ _jsxDEV("p", {
														className: "text-xs text-slate-300 font-medium",
														children: "Upload Image File"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 1095,
														columnNumber: 25
													}, this),
													/* @__PURE__ */ _jsxDEV("p", {
														className: "text-[10px] text-slate-500",
														children: "PNG, JPG, WEBP supported"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 1096,
														columnNumber: 25
													}, this)
												]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 1093,
												columnNumber: 23
											}, this), /* @__PURE__ */ _jsxDEV("input", {
												type: "file",
												accept: "image/*",
												className: "hidden",
												onChange: handleImageFileUpload
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1098,
												columnNumber: 23
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1092,
											columnNumber: 21
										}, this), /* @__PURE__ */ _jsxDEV("form", {
											onSubmit: handleApplyImageUrl,
											className: "flex gap-2",
											children: [/* @__PURE__ */ _jsxDEV("input", {
												type: "url",
												value: imageUrlInput,
												onChange: (e) => setImageUrlInput(e.target.value),
												placeholder: "https://example.com/image.jpg",
												className: "flex-1 bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-blue-500 transition-colors"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1108,
												columnNumber: 23
											}, this), /* @__PURE__ */ _jsxDEV("button", {
												type: "submit",
												className: "bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold px-3.5 py-2 rounded-xl transition-colors shrink-0 cursor-pointer",
												children: "Apply Image"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1115,
												columnNumber: 23
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1107,
											columnNumber: 21
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1090,
										columnNumber: 19
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1086,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
									className: "block text-xs font-bold uppercase tracking-wider text-slate-400 mb-2",
									children: "Preset Themes"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1127,
									columnNumber: 19
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "grid grid-cols-3 gap-2.5",
									children: PRESET_GRADIENTS.map((preset) => /* @__PURE__ */ _jsxDEV("button", {
										onClick: () => handleSelectPreset(preset.class),
										className: `h-12 rounded-xl ${preset.class} border-2 transition-all shadow-sm flex items-end p-1.5 cursor-pointer text-left ${coverConfig.type === "gradient" && coverConfig.value === preset.class ? "border-white ring-2 ring-blue-500/50" : "border-transparent hover:border-slate-400"}`,
										title: preset.name,
										children: /* @__PURE__ */ _jsxDEV("span", {
											className: "text-[9px] font-bold text-white/90 drop-shadow-sm truncate",
											children: preset.name
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1142,
											columnNumber: 25
										}, this)
									}, preset.id, false, {
										fileName: _jsxFileName,
										lineNumber: 1132,
										columnNumber: 23
									}, this))
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1130,
									columnNumber: 19
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1126,
									columnNumber: 17
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 1043,
							columnNumber: 15
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "mt-6 pt-4 border-t border-slate-800 flex justify-between items-center",
							children: [/* @__PURE__ */ _jsxDEV("button", {
								onClick: handleResetCover,
								className: "text-xs font-semibold text-rose-400 hover:text-rose-300 flex items-center gap-1.5 cursor-pointer",
								children: [/* @__PURE__ */ _jsxDEV(RotateCcw, { className: "w-3.5 h-3.5" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1158,
									columnNumber: 19
								}, this), "Reset Default"]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1154,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("button", {
								onClick: () => setIsCoverModalOpen(false),
								className: "bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold px-4 py-2 rounded-xl transition-colors cursor-pointer",
								children: "Done"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1161,
								columnNumber: 17
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 1153,
							columnNumber: 15
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 971,
					columnNumber: 13
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 961,
				columnNumber: 11
			}, this) }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 959,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV(AnimatePresence, { children: isQrModalOpen && /* @__PURE__ */ _jsxDEV(motion.div, {
				initial: { opacity: 0 },
				animate: { opacity: 1 },
				exit: { opacity: 0 },
				transition: {
					duration: .24,
					ease: "easeOut"
				},
				onClick: (e) => {
					if (e.target === e.currentTarget) setIsQrModalOpen(false);
				},
				className: "fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-md",
				children: /* @__PURE__ */ _jsxDEV(motion.div, {
					initial: {
						opacity: 0,
						y: 44,
						scale: .94
					},
					animate: {
						opacity: 1,
						y: 0,
						scale: 1
					},
					exit: {
						opacity: 0,
						y: 30,
						scale: .95
					},
					transition: {
						type: "spring",
						damping: 27,
						stiffness: 330,
						mass: .8
					},
					className: "bg-slate-900 border border-slate-800 rounded-3xl w-full max-w-sm p-6 shadow-2xl relative text-center",
					children: [
						/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center justify-between pb-3 border-b border-slate-800 mb-4",
							children: [/* @__PURE__ */ _jsxDEV("h3", {
								className: "text-sm font-bold text-white flex items-center gap-2",
								children: [/* @__PURE__ */ _jsxDEV(QrCode, { className: "w-4 h-4 text-blue-400" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1196,
									columnNumber: 19
								}, this), "Profile QR Code"]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1195,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("button", {
								onClick: () => setIsQrModalOpen(false),
								className: "w-7 h-7 rounded-full bg-slate-800 text-slate-400 hover:text-white flex items-center justify-center cursor-pointer",
								children: /* @__PURE__ */ _jsxDEV(X, { className: "w-3.5 h-3.5" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1203,
									columnNumber: 19
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1199,
								columnNumber: 17
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 1194,
							columnNumber: 15
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "bg-white p-4 rounded-2xl inline-block mb-3 shadow-lg",
							children: /* @__PURE__ */ _jsxDEV("img", {
								src: `https://api.qrserver.com/v1/create-qr-code/?size=180x180&data=${encodeURIComponent(typeof window !== "undefined" ? window.location.href : "https://albertrobledo.com")}`,
								alt: "Albert Robledo Profile QR Code",
								className: "w-44 h-44 object-contain",
								onError: (e) => {
									e.target.style.display = "none";
								}
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1209,
								columnNumber: 17
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 1208,
							columnNumber: 15
						}, this),
						/* @__PURE__ */ _jsxDEV("p", {
							className: "text-xs font-bold text-white mb-0.5",
							children: "Scan to connect with Albert"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 1221,
							columnNumber: 15
						}, this),
						/* @__PURE__ */ _jsxDEV("p", {
							className: "text-[11px] text-slate-400 mb-4",
							children: "Opens direct link to profile & social contacts"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 1222,
							columnNumber: 15
						}, this),
						/* @__PURE__ */ _jsxDEV("button", {
							onClick: () => {
								handleShareProfile();
								setIsQrModalOpen(false);
							},
							className: "w-full py-2 px-4 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold transition-all cursor-pointer",
							children: "Copy / Share Link Instead"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 1224,
							columnNumber: 15
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 1187,
					columnNumber: 13
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 1177,
				columnNumber: 11
			}, this) }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 1175,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV(AnimatePresence, { children: isDownloadModalOpen && /* @__PURE__ */ _jsxDEV(motion.div, {
				initial: { opacity: 0 },
				animate: { opacity: 1 },
				exit: { opacity: 0 },
				transition: {
					duration: .24,
					ease: "easeOut"
				},
				onClick: (e) => {
					if (e.target === e.currentTarget) setIsDownloadModalOpen(false);
				},
				className: "fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-md",
				children: /* @__PURE__ */ _jsxDEV(motion.div, {
					initial: {
						opacity: 0,
						y: 44,
						scale: .94
					},
					animate: {
						opacity: 1,
						y: 0,
						scale: 1
					},
					exit: {
						opacity: 0,
						y: 30,
						scale: .95
					},
					transition: {
						type: "spring",
						damping: 27,
						stiffness: 330,
						mass: .8
					},
					className: "bg-slate-900 border border-slate-800 rounded-3xl w-full max-w-md p-6 shadow-2xl relative max-h-[90vh] overflow-y-auto",
					children: [
						/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center justify-between pb-3.5 border-b border-slate-800 mb-5",
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center gap-2.5",
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "w-8 h-8 rounded-lg bg-emerald-500/15 border border-emerald-500/30 flex items-center justify-center text-emerald-400",
									children: /* @__PURE__ */ _jsxDEV(Download, { className: "w-4 h-4" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1261,
										columnNumber: 21
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1260,
									columnNumber: 19
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "text-left",
									children: [/* @__PURE__ */ _jsxDEV("h3", {
										className: "text-base font-bold text-white",
										children: "Download Project Files"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1264,
										columnNumber: 21
									}, this), /* @__PURE__ */ _jsxDEV("p", {
										className: "text-[11px] text-slate-400",
										children: "Choose your preferred download format"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1265,
										columnNumber: 21
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1263,
									columnNumber: 19
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1259,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("button", {
								onClick: () => setIsDownloadModalOpen(false),
								className: "w-8 h-8 rounded-full bg-slate-800 text-slate-400 hover:text-white flex items-center justify-center transition-colors cursor-pointer",
								"aria-label": "Close Modal",
								children: /* @__PURE__ */ _jsxDEV(X, { className: "w-4 h-4" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1273,
									columnNumber: 19
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1268,
								columnNumber: 17
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 1258,
							columnNumber: 15
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "space-y-3.5 text-left",
							children: [
								/* @__PURE__ */ _jsxDEV("div", {
									className: "p-4 rounded-2xl bg-slate-950/70 border border-slate-800 hover:border-emerald-500/40 transition-all flex flex-col gap-3 group",
									children: [/* @__PURE__ */ _jsxDEV("div", {
										className: "flex items-start gap-3.5",
										children: [/* @__PURE__ */ _jsxDEV("div", {
											className: "w-10 h-10 rounded-xl bg-emerald-500/15 border border-emerald-500/30 flex items-center justify-center text-emerald-400 shrink-0",
											children: /* @__PURE__ */ _jsxDEV(FileArchive, { className: "w-5 h-5" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1282,
												columnNumber: 23
											}, this)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1281,
											columnNumber: 21
										}, this), /* @__PURE__ */ _jsxDEV("div", {
											className: "flex-1 min-w-0",
											children: [/* @__PURE__ */ _jsxDEV("div", {
												className: "flex items-center gap-2 mb-0.5",
												children: [/* @__PURE__ */ _jsxDEV("h4", {
													className: "text-sm font-bold text-white group-hover:text-emerald-300 transition-colors",
													children: "Complete Project (.ZIP)"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1286,
													columnNumber: 25
												}, this), /* @__PURE__ */ _jsxDEV("span", {
													className: "text-[9px] uppercase tracking-wider font-extrabold px-1.5 py-0.5 rounded bg-emerald-500/20 text-emerald-400 border border-emerald-500/30",
													children: "Recommended"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1289,
													columnNumber: 25
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 1285,
												columnNumber: 23
											}, this), /* @__PURE__ */ _jsxDEV("p", {
												className: "text-xs text-slate-400 leading-relaxed",
												children: [
													"Full React 19 + Vite + Tailwind source code with ",
													/* @__PURE__ */ _jsxDEV("code", {
														className: "text-emerald-400",
														children: "package.json"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 1294,
														columnNumber: 74
													}, this),
													" and instructions to run locally or deploy anywhere."
												]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 1293,
												columnNumber: 23
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1284,
											columnNumber: 21
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1280,
										columnNumber: 19
									}, this), /* @__PURE__ */ _jsxDEV("button", {
										onClick: handleDownloadZip,
										disabled: isDownloading,
										className: "w-full py-2.5 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold transition-all flex items-center justify-center gap-2 shadow-lg shadow-emerald-950/50 cursor-pointer disabled:opacity-50",
										children: isDownloading ? /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV(Loader2, { className: "w-4 h-4 animate-spin" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1306,
											columnNumber: 25
										}, this), "Generating ZIP Bundle..."] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1305,
											columnNumber: 23
										}, this) : /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV(Download, { className: "w-4 h-4" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1311,
											columnNumber: 25
										}, this), "Download Full Project (.ZIP)"] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1310,
											columnNumber: 23
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1299,
										columnNumber: 19
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1279,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "p-4 rounded-2xl bg-slate-950/70 border border-slate-800 hover:border-blue-500/40 transition-all flex flex-col gap-3 group",
									children: [/* @__PURE__ */ _jsxDEV("div", {
										className: "flex items-start gap-3.5",
										children: [/* @__PURE__ */ _jsxDEV("div", {
											className: "w-10 h-10 rounded-xl bg-blue-500/15 border border-blue-500/30 flex items-center justify-center text-blue-400 shrink-0",
											children: /* @__PURE__ */ _jsxDEV(FileCode, { className: "w-5 h-5" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1322,
												columnNumber: 23
											}, this)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1321,
											columnNumber: 21
										}, this), /* @__PURE__ */ _jsxDEV("div", {
											className: "flex-1 min-w-0",
											children: [/* @__PURE__ */ _jsxDEV("h4", {
												className: "text-sm font-bold text-white group-hover:text-blue-300 transition-colors mb-0.5",
												children: "Standalone Webpage (.HTML)"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1325,
												columnNumber: 23
											}, this), /* @__PURE__ */ _jsxDEV("p", {
												className: "text-xs text-slate-400 leading-relaxed",
												children: "A single self-contained HTML file. Just double-click it to open offline in any browser anywhere without installing anything."
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1328,
												columnNumber: 23
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1324,
											columnNumber: 21
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1320,
										columnNumber: 19
									}, this), /* @__PURE__ */ _jsxDEV("button", {
										onClick: handleDownloadHtml,
										className: "w-full py-2.5 px-4 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold transition-all flex items-center justify-center gap-2 shadow-lg shadow-blue-950/50 cursor-pointer",
										children: [/* @__PURE__ */ _jsxDEV(Download, { className: "w-4 h-4" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1338,
											columnNumber: 21
										}, this), "Download Standalone (.HTML)"]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1334,
										columnNumber: 19
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1319,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "p-4 rounded-2xl bg-slate-950/70 border border-slate-800 hover:border-purple-500/40 transition-all flex flex-col gap-3 group",
									children: [/* @__PURE__ */ _jsxDEV("div", {
										className: "flex items-start gap-3.5",
										children: [/* @__PURE__ */ _jsxDEV("div", {
											className: "w-10 h-10 rounded-xl bg-purple-500/15 border border-purple-500/30 flex items-center justify-center text-purple-400 shrink-0",
											children: /* @__PURE__ */ _jsxDEV(Contact, { className: "w-5 h-5" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1347,
												columnNumber: 23
											}, this)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1346,
											columnNumber: 21
										}, this), /* @__PURE__ */ _jsxDEV("div", {
											className: "flex-1 min-w-0",
											children: [/* @__PURE__ */ _jsxDEV("h4", {
												className: "text-sm font-bold text-white group-hover:text-purple-300 transition-colors mb-0.5",
												children: "Contact Card (.VCF)"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1350,
												columnNumber: 23
											}, this), /* @__PURE__ */ _jsxDEV("p", {
												className: "text-xs text-slate-400 leading-relaxed",
												children: "Direct contact card file. Opens immediately on phone address books to save Albert Robledo's contact."
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1353,
												columnNumber: 23
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1349,
											columnNumber: 21
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1345,
										columnNumber: 19
									}, this), /* @__PURE__ */ _jsxDEV("button", {
										onClick: handleDownloadContact,
										className: "w-full py-2.5 px-4 rounded-xl bg-purple-600 hover:bg-purple-500 text-white text-xs font-bold transition-all flex items-center justify-center gap-2 shadow-lg shadow-purple-950/50 cursor-pointer",
										children: [/* @__PURE__ */ _jsxDEV(Download, { className: "w-4 h-4" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1363,
											columnNumber: 21
										}, this), "Download Contact (.VCF)"]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1359,
										columnNumber: 19
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1344,
									columnNumber: 17
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 1277,
							columnNumber: 15
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "mt-5 pt-3.5 border-t border-slate-800 flex justify-end",
							children: /* @__PURE__ */ _jsxDEV("button", {
								onClick: () => setIsDownloadModalOpen(false),
								className: "bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold px-4 py-2 rounded-xl transition-colors cursor-pointer",
								children: "Close"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1370,
								columnNumber: 17
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 1369,
							columnNumber: 15
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 1251,
					columnNumber: 13
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 1241,
				columnNumber: 11
			}, this) }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 1239,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV(AnimatePresence, { children: toast && /* @__PURE__ */ _jsxDEV(motion.div, {
				initial: {
					opacity: 0,
					y: 24,
					scale: .95
				},
				animate: {
					opacity: 1,
					y: 0,
					scale: 1
				},
				exit: {
					opacity: 0,
					y: 16,
					scale: .96
				},
				transition: {
					type: "spring",
					damping: 25,
					stiffness: 350
				},
				className: "fixed bottom-6 left-1/2 -translate-x-1/2 bg-slate-900 border border-slate-700 text-white text-xs font-medium px-4 py-2.5 rounded-2xl shadow-2xl backdrop-blur-md flex items-center gap-2.5 z-50",
				children: [toast.type === "error" ? /* @__PURE__ */ _jsxDEV(AlertCircle, { className: "w-4 h-4 text-rose-400 shrink-0" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 1393,
					columnNumber: 15
				}, this) : toast.type === "info" ? /* @__PURE__ */ _jsxDEV(Sparkles, { className: "w-4 h-4 text-purple-400 shrink-0" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 1395,
					columnNumber: 15
				}, this) : /* @__PURE__ */ _jsxDEV(CheckCircle2, { className: "w-4 h-4 text-emerald-400 shrink-0" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 1397,
					columnNumber: 15
				}, this), /* @__PURE__ */ _jsxDEV("span", { children: toast.message }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 1399,
					columnNumber: 13
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 1385,
				columnNumber: 11
			}, this) }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 1383,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV(AnimatePresence, { children: showSocialToast && /* @__PURE__ */ _jsxDEV(motion.div, {
				initial: {
					opacity: 0,
					y: 44,
					scale: .94
				},
				animate: {
					opacity: 1,
					y: 0,
					scale: 1
				},
				exit: {
					opacity: 0,
					y: 28,
					scale: .95
				},
				transition: {
					type: "spring",
					damping: 26,
					stiffness: 320,
					mass: .8
				},
				className: `fixed bottom-5 sm:bottom-6 right-3 sm:right-6 left-3 sm:left-auto sm:w-96 z-40 p-4 rounded-2xl glass-card backdrop-blur-xl border shadow-2xl transition-all ${glowEnabled ? "border-purple-500/30 ring-1 ring-purple-500/20 shadow-purple-950/50" : "border-slate-800 bg-slate-900/95 shadow-black/60"}`,
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-start justify-between gap-3 mb-2.5",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-center gap-2.5",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "relative",
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "w-9 h-9 rounded-full bg-gradient-to-tr from-purple-600 via-pink-600 to-blue-500 p-0.5 flex items-center justify-center",
								children: /* @__PURE__ */ _jsxDEV("div", {
									className: "w-full h-full rounded-full bg-slate-950 flex items-center justify-center overflow-hidden",
									children: avatarUrl ? /* @__PURE__ */ _jsxDEV("img", {
										src: avatarUrl,
										alt: "Albert",
										className: "w-full h-full object-cover"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1424,
										columnNumber: 25
									}, this) : /* @__PURE__ */ _jsxDEV("span", {
										className: "text-[11px] font-black text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-purple-400",
										children: "AR"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1426,
										columnNumber: 25
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1422,
									columnNumber: 21
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1421,
								columnNumber: 19
							}, this), /* @__PURE__ */ _jsxDEV("span", { className: "absolute -top-0.5 -right-0.5 w-2.5 h-2.5 bg-emerald-400 border-2 border-slate-950 rounded-full animate-pulse" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1432,
								columnNumber: 19
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 1420,
							columnNumber: 17
						}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h4", {
							className: "text-xs font-bold text-white flex items-center gap-1.5",
							children: ["Follow me on social!", /* @__PURE__ */ _jsxDEV(Sparkles, { className: "w-3 h-3 text-purple-400" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1437,
								columnNumber: 21
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 1435,
							columnNumber: 19
						}, this), /* @__PURE__ */ _jsxDEV("p", {
							className: "text-[11px] text-slate-400",
							children: "Stay updated with Albert on social media"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 1439,
							columnNumber: 19
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 1434,
							columnNumber: 17
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 1419,
						columnNumber: 15
					}, this), /* @__PURE__ */ _jsxDEV("button", {
						onClick: () => setShowSocialToast(false),
						className: "p-1 rounded-full text-slate-400 hover:text-white hover:bg-slate-800/80 transition-colors cursor-pointer",
						"aria-label": "Dismiss Notification",
						children: /* @__PURE__ */ _jsxDEV(X, { className: "w-3.5 h-3.5" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 1450,
							columnNumber: 17
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 1445,
						columnNumber: 15
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 1418,
					columnNumber: 13
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center gap-2 pt-2 border-t border-slate-800/80",
					children: [
						/* @__PURE__ */ _jsxDEV("a", {
							href: "https://www.facebook.com/profile.php?id=61594256549921",
							target: "_blank",
							rel: "noopener noreferrer",
							onClick: () => setShowSocialToast(false),
							className: "flex-1 py-1.5 px-2 rounded-xl bg-[#1877F2]/15 hover:bg-[#1877F2]/25 text-[#1877F2] border border-[#1877F2]/30 text-[11px] font-semibold flex items-center justify-center gap-1.5 transition-all",
							children: [/* @__PURE__ */ _jsxDEV("i", { className: "fa-brands fa-facebook-f text-xs" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1463,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Facebook" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1464,
								columnNumber: 17
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 1456,
							columnNumber: 15
						}, this),
						/* @__PURE__ */ _jsxDEV("a", {
							href: "https://www.tiktok.com/@_kkwkwk?_r=1&_t=ZS-9AJkkE0m4W5",
							target: "_blank",
							rel: "noopener noreferrer",
							onClick: () => setShowSocialToast(false),
							className: "flex-1 py-1.5 px-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-white border border-slate-700 text-[11px] font-semibold flex items-center justify-center gap-1.5 transition-all",
							children: [/* @__PURE__ */ _jsxDEV("i", { className: "fa-brands fa-tiktok text-xs" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1474,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("span", { children: "TikTok" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1475,
								columnNumber: 17
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 1467,
							columnNumber: 15
						}, this),
						/* @__PURE__ */ _jsxDEV("a", {
							href: "https://www.instagram.com/_bluuuee00?stkn=cWMyc2o3bTBoeTJh",
							target: "_blank",
							rel: "noopener noreferrer",
							onClick: () => setShowSocialToast(false),
							className: "flex-1 py-1.5 px-2 rounded-xl bg-pink-500/15 hover:bg-pink-500/25 text-pink-400 border border-pink-500/30 text-[11px] font-semibold flex items-center justify-center gap-1.5 transition-all",
							children: [/* @__PURE__ */ _jsxDEV("i", { className: "fa-brands fa-instagram text-xs" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1485,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Instagram" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1486,
								columnNumber: 17
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 1478,
							columnNumber: 15
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 1455,
					columnNumber: 13
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 1407,
				columnNumber: 11
			}, this) }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 1405,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 378,
		columnNumber: 5
	}, this);
}

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6Ijs7OztBQUtBLE9BQU8sU0FBUyxVQUFVLFdBQVcsY0FBYztBQUNuRCxTQUFTLFFBQVEsdUJBQXVCO0FBQ3hDLFNBQ0UsVUFDQSxPQUNBLFdBQ0EsZUFDQSxNQUNBLE9BQ0EsUUFDQSxRQUNBLFdBQ0EsR0FDQSxjQUNBLE9BQ0EsU0FBUyxXQUNULFNBQ0EsUUFDQSxjQUNBLGFBQ0EsY0FDQSxNQUNBLEtBQ0EsUUFDQSxNQUNBLFFBQ0EsYUFDQSxVQUNBLGFBQ0EsVUFDQSxTQUNBLGVBQ0s7QUFDUCxTQUNFLG9CQUNBLHdCQUNBLHFCQUNLOzs7QUFZUCxNQUFNLG1CQUFtQjtDQUN2QjtFQUFFLElBQUk7RUFBb0IsTUFBTTtFQUFnQixPQUFPO0NBQW1CO0NBQzFFO0VBQUUsSUFBSTtFQUFvQixNQUFNO0VBQWlCLE9BQU87Q0FBbUI7Q0FDM0U7RUFBRSxJQUFJO0VBQW9CLE1BQU07RUFBZSxPQUFPO0NBQW1CO0NBQ3pFO0VBQUUsSUFBSTtFQUFvQixNQUFNO0VBQWdCLE9BQU87Q0FBbUI7Q0FDMUU7RUFBRSxJQUFJO0VBQW9CLE1BQU07RUFBbUIsT0FBTztDQUFtQjtDQUM3RTtFQUFFLElBQUk7RUFBb0IsTUFBTTtFQUFrQixPQUFPO0NBQW1CO0FBQzlFOztBQUdBLE1BQU0saUJBQWlCO0NBQ3JCO0VBQ0UsTUFBTTtFQUNOLEtBQUs7Q0FDUDtDQUNBO0VBQ0UsTUFBTTtFQUNOLEtBQUs7Q0FDUDtDQUNBO0VBQ0UsTUFBTTtFQUNOLEtBQUs7Q0FDUDtDQUNBO0VBQ0UsTUFBTTtFQUNOLEtBQUs7Q0FDUDtBQUNGO0FBRUEsZUFBZSxTQUFTLE1BQU07O0NBRTVCLE1BQU0sQ0FBQyxhQUFhLGtCQUFrQixlQUF3QjtFQUM1RCxJQUFJO0dBQ0YsTUFBTSxRQUFRLGFBQWEsUUFBUSw2QkFBNkI7R0FDaEUsT0FBTyxVQUFVLE9BQU8sS0FBSyxNQUFNLEtBQUssSUFBSTtFQUM5QyxRQUFRO0dBQ04sT0FBTztFQUNUO0NBQ0YsQ0FBQzs7Q0FHRCxNQUFNLENBQUMsV0FBVyxnQkFBZ0IsZUFBOEI7RUFDOUQsSUFBSTtHQUNGLE9BQU8sYUFBYSxRQUFRLDBCQUEwQixLQUFLO0VBQzdELFFBQVE7R0FDTixPQUFPO0VBQ1Q7Q0FDRixDQUFDOztDQUdELE1BQU0sQ0FBQyxhQUFhLGtCQUFrQixlQUE0QjtFQUNoRSxJQUFJO0dBQ0YsTUFBTSxRQUFRLGFBQWEsUUFBUSx5QkFBeUI7R0FDNUQsSUFBSSxPQUFPLE9BQU8sS0FBSyxNQUFNLEtBQUs7RUFDcEMsU0FBUyxHQUFHO0dBQ1YsUUFBUSxLQUFLLHNDQUFzQyxDQUFDO0VBQ3REO0VBQ0EsT0FBTztHQUFFLE1BQU07R0FBWSxPQUFPO0VBQW1CO0NBQ3ZELENBQUM7O0NBR0QsTUFBTSxDQUFDLGtCQUFrQix1QkFBdUIsU0FBUyxLQUFLO0NBQzlELE1BQU0sQ0FBQyxtQkFBbUIsd0JBQXdCLFNBQVMsS0FBSztDQUNoRSxNQUFNLENBQUMsZUFBZSxvQkFBb0IsU0FBUyxLQUFLO0NBQ3hELE1BQU0sQ0FBQyxxQkFBcUIsMEJBQTBCLFNBQVMsS0FBSztDQUNwRSxNQUFNLENBQUMsZUFBZSxvQkFBb0IsU0FBUyxLQUFLO0NBRXhELE1BQU0sQ0FBQyxlQUFlLG9CQUFvQixTQUFTLEVBQUU7Q0FDckQsTUFBTSxDQUFDLGVBQWUsb0JBQW9CLFNBQVMsRUFBRTtDQUNyRCxNQUFNLENBQUMsZ0JBQWdCLHFCQUFxQixTQUFTLEVBQUU7Q0FDdkQsTUFBTSxDQUFDLGNBQWMsbUJBQW1CLFNBQVMsS0FBSzs7Q0FHdEQsTUFBTSxDQUFDLGlCQUFpQixzQkFBc0IsU0FBUyxLQUFLOztDQUc1RCxNQUFNLENBQUMsT0FBTyxZQUFZLFNBQTJCLElBQUk7Q0FDekQsTUFBTSxnQkFBZ0IsT0FBOEIsSUFBSTtDQUV4RCxNQUFNLGtCQUFrQixPQUFnQyxJQUFJOztDQUc1RCxNQUFNLGFBQWEsU0FBaUIsT0FBcUMsY0FBYztFQUNyRixJQUFJLGNBQWMsU0FBUyxhQUFhLGNBQWMsT0FBTztFQUM3RCxTQUFTO0dBQUU7R0FBUztFQUFLLENBQUM7RUFDMUIsY0FBYyxVQUFVLGlCQUFpQjtHQUN2QyxTQUFTLElBQUk7RUFDZixHQUFHLElBQUk7Q0FDVDs7Q0FHQSxNQUFNLG1CQUFtQjtFQUN2QixNQUFNLFlBQVksQ0FBQztFQUNuQixlQUFlLFNBQVM7RUFDeEIsSUFBSTtHQUNGLGFBQWEsUUFBUSwrQkFBK0IsS0FBSyxVQUFVLFNBQVMsQ0FBQztFQUMvRSxTQUFTLEtBQUs7R0FDWixRQUFRLEtBQUssc0JBQXNCLEdBQUc7RUFDeEM7RUFDQSxJQUFJLFdBQVc7R0FDYixVQUFVLCtCQUErQixTQUFTO0VBQ3BELE9BQU87R0FDTCxVQUFVLG1EQUFtRCxNQUFNO0VBQ3JFO0NBQ0Y7O0NBR0EsTUFBTSxnQkFBZ0IsUUFBdUI7RUFDM0MsYUFBYSxHQUFHO0VBQ2hCLElBQUk7R0FDRixJQUFJLEtBQUs7SUFDUCxhQUFhLFFBQVEsNEJBQTRCLEdBQUc7R0FDdEQsT0FBTztJQUNMLGFBQWEsV0FBVywwQkFBMEI7R0FDcEQ7RUFDRixTQUFTLEtBQUs7R0FDWixRQUFRLEtBQUssd0NBQXdDLEdBQUc7RUFDMUQ7Q0FDRjtDQUVBLE1BQU0sMEJBQTBCLE1BQTJDO0VBQ3pFLE1BQU0sT0FBTyxFQUFFLE9BQU8sUUFBUTtFQUM5QixJQUFJLENBQUMsTUFBTTtFQUVYLElBQUksQ0FBQyxLQUFLLEtBQUssV0FBVyxRQUFRLEdBQUc7R0FDbkMsVUFBVSxvQ0FBb0MsT0FBTztHQUNyRDtFQUNGO0VBRUEsTUFBTSxTQUFTLElBQUksV0FBVztFQUM5QixPQUFPLFVBQVUsVUFBVTtHQUN6QixNQUFNLFNBQVMsTUFBTSxRQUFRO0dBQzdCLElBQUksUUFBUTtJQUNWLGFBQWEsTUFBTTtJQUNuQixVQUFVLDBCQUEwQjtJQUNwQyxxQkFBcUIsS0FBSztHQUM1QjtFQUNGO0VBQ0EsT0FBTyxjQUFjLElBQUk7Q0FDM0I7Q0FFQSxNQUFNLHdCQUF3QixNQUF3QjtFQUNwRCxJQUFJLEdBQUcsRUFBRSxlQUFlO0VBQ3hCLE1BQU0sTUFBTSxlQUFlLEtBQUs7RUFDaEMsSUFBSSxDQUFDLEtBQUs7R0FDUixVQUFVLDZCQUE2QixPQUFPO0dBQzlDO0VBQ0Y7RUFDQSxhQUFhLEdBQUc7RUFDaEIsa0JBQWtCLEVBQUU7RUFDcEIsVUFBVSxtQ0FBbUM7RUFDN0MscUJBQXFCLEtBQUs7Q0FDNUI7Q0FFQSxNQUFNLDBCQUEwQjtFQUM5QixhQUFhLElBQUk7RUFDakIsVUFBVSxnREFBZ0Q7RUFDMUQscUJBQXFCLEtBQUs7Q0FDNUI7O0NBR0EsTUFBTSxxQkFBcUIsV0FBd0I7RUFDakQsZUFBZSxNQUFNO0VBQ3JCLElBQUk7R0FDRixhQUFhLFFBQVEsMkJBQTJCLEtBQUssVUFBVSxNQUFNLENBQUM7RUFDeEUsU0FBUyxLQUFLO0dBQ1osUUFBUSxLQUFLLDhCQUE4QixHQUFHO0VBQ2hEO0NBQ0Y7O0NBR0EsTUFBTSxzQkFBc0Isa0JBQTBCO0VBQ3BELGtCQUFrQjtHQUFFLE1BQU07R0FBWSxPQUFPO0VBQWMsQ0FBQztFQUM1RCxVQUFVLHVCQUF1QjtFQUNqQyxvQkFBb0IsS0FBSztDQUMzQjs7Q0FHQSxNQUFNLHVCQUF1QixNQUF3QjtFQUNuRCxJQUFJLEdBQUcsRUFBRSxlQUFlO0VBQ3hCLE1BQU0sTUFBTSxjQUFjLEtBQUs7RUFDL0IsSUFBSSxDQUFDLEtBQUs7R0FDUixVQUFVLDZCQUE2QixPQUFPO0dBQzlDO0VBQ0Y7RUFDQSxrQkFBa0I7R0FBRSxNQUFNO0dBQVMsT0FBTztFQUFJLENBQUM7RUFDL0MsaUJBQWlCLEVBQUU7RUFDbkIsVUFBVSwrQkFBK0I7RUFDekMsb0JBQW9CLEtBQUs7Q0FDM0I7O0NBR0EsTUFBTSx1QkFBdUIsTUFBd0I7RUFDbkQsSUFBSSxHQUFHLEVBQUUsZUFBZTtFQUN4QixNQUFNLE1BQU0sY0FBYyxLQUFLO0VBQy9CLElBQUksQ0FBQyxLQUFLO0dBQ1IsVUFBVSw0QkFBNEIsT0FBTztHQUM3QztFQUNGO0VBQ0Esa0JBQWtCO0dBQUUsTUFBTTtHQUFTLE9BQU87RUFBSSxDQUFDO0VBQy9DLGlCQUFpQixFQUFFO0VBQ25CLFVBQVUsK0JBQStCO0VBQ3pDLG9CQUFvQixLQUFLO0NBQzNCOztDQUdBLE1BQU0seUJBQXlCLE1BQTJDO0VBQ3hFLE1BQU0sT0FBTyxFQUFFLE9BQU8sUUFBUTtFQUM5QixJQUFJLENBQUMsTUFBTTtFQUVYLElBQUksQ0FBQyxLQUFLLEtBQUssV0FBVyxRQUFRLEdBQUc7R0FDbkMsVUFBVSxvQ0FBb0MsT0FBTztHQUNyRDtFQUNGO0VBRUEsTUFBTSxTQUFTLElBQUksV0FBVztFQUM5QixPQUFPLFVBQVUsVUFBVTtHQUN6QixNQUFNLFNBQVMsTUFBTSxRQUFRO0dBQzdCLElBQUksUUFBUTtJQUNWLGtCQUFrQjtLQUFFLE1BQU07S0FBUyxPQUFPO0lBQU8sQ0FBQztJQUNsRCxVQUFVLGdDQUFnQztJQUMxQyxvQkFBb0IsS0FBSztHQUMzQjtFQUNGO0VBQ0EsT0FBTyxjQUFjLElBQUk7Q0FDM0I7O0NBR0EsTUFBTSx5QkFBeUIsTUFBMkM7RUFDeEUsTUFBTSxPQUFPLEVBQUUsT0FBTyxRQUFRO0VBQzlCLElBQUksQ0FBQyxNQUFNO0VBRVgsSUFBSSxDQUFDLEtBQUssS0FBSyxXQUFXLFFBQVEsR0FBRztHQUNuQyxVQUFVLGdEQUFnRCxPQUFPO0dBQ2pFO0VBQ0Y7RUFFQSxNQUFNLFdBQVcsSUFBSSxnQkFBZ0IsSUFBSTtFQUN6QyxrQkFBa0I7R0FBRSxNQUFNO0dBQVMsT0FBTztFQUFTLENBQUM7RUFDcEQsVUFBVSwrQkFBK0I7RUFDekMsb0JBQW9CLEtBQUs7Q0FDM0I7O0NBR0EsTUFBTSx5QkFBeUI7RUFDN0IsTUFBTSxnQkFBNkI7R0FBRSxNQUFNO0dBQVksT0FBTztFQUFtQjtFQUNqRixrQkFBa0IsYUFBYTtFQUMvQixVQUFVLCtCQUErQjtFQUN6QyxvQkFBb0IsS0FBSztDQUMzQjs7Q0FHQSxNQUFNLHlCQUF5QixXQUFtQjtFQUNoRCxVQUFVLFVBQVUsVUFBVSxNQUFNLENBQUMsQ0FBQyxXQUFXO0dBQy9DLGdCQUFnQixJQUFJO0dBQ3BCLFVBQVUsb0NBQW9DO0dBQzlDLGlCQUFpQixnQkFBZ0IsS0FBSyxHQUFHLEdBQUk7RUFDL0MsQ0FBQyxDQUFDLENBQUMsWUFBWTtHQUNiLFVBQVUseUJBQXlCLE9BQU87RUFDNUMsQ0FBQztDQUNIOztDQUdBLE1BQU0sMkJBQTJCO0VBQy9CLElBQUksVUFBVSxPQUFPO0dBQ25CLFVBQVUsTUFBTTtJQUNkLE9BQU87SUFDUCxNQUFNO0lBQ04sS0FBSyxPQUFPLFNBQVM7R0FDdkIsQ0FBQyxDQUFDLENBQUMsWUFBWSxDQUFDLENBQUM7RUFDbkIsT0FBTztHQUNMLFVBQVUsVUFBVSxVQUFVLE9BQU8sU0FBUyxJQUFJO0dBQ2xELFVBQVUsbUNBQW1DO0VBQy9DO0NBQ0Y7O0NBR0EsTUFBTSxvQkFBb0IsWUFBWTtFQUNwQyxpQkFBaUIsSUFBSTtFQUNyQixVQUFVLG9DQUFvQyxNQUFNO0VBQ3BELElBQUk7R0FDRixNQUFNLG1CQUFtQjtHQUN6QixVQUFVLDhCQUE4QixTQUFTO0VBQ25ELFNBQVMsS0FBSztHQUNaLFFBQVEsTUFBTSxHQUFHO0dBQ2pCLFVBQVUsMEJBQTBCLE9BQU87RUFDN0MsVUFBVTtHQUNSLGlCQUFpQixLQUFLO0VBQ3hCO0NBQ0Y7Q0FFQSxNQUFNLDJCQUEyQjtFQUMvQix1QkFBdUIsV0FBVyxXQUFXO0VBQzdDLFVBQVUsMkNBQTJDLFNBQVM7Q0FDaEU7Q0FFQSxNQUFNLDhCQUE4QjtFQUNsQyxjQUFjO0VBQ2QsVUFBVSxzQ0FBc0MsU0FBUztDQUMzRDs7Q0FHQSxnQkFBZ0I7RUFDZCxJQUFJLFlBQVksU0FBUyxXQUFXLGdCQUFnQixTQUFTO0dBQzNELGdCQUFnQixRQUFRLE1BQU0sWUFBWTtHQUMxQyxnQkFBZ0IsUUFBUSxLQUFLLENBQUMsQ0FBQyxPQUFPLFFBQVE7SUFDNUMsUUFBUSxJQUFJLDRDQUE0QyxHQUFHO0dBQzdELENBQUM7RUFDSDtDQUNGLEdBQUcsQ0FBQyxXQUFXLENBQUM7O0NBR2hCLGdCQUFnQjtFQUNkLE1BQU0sUUFBUSxpQkFBaUI7R0FDN0IsbUJBQW1CLElBQUk7RUFDekIsR0FBRyxHQUFJO0VBRVAsYUFBYSxhQUFhLEtBQUs7Q0FDakMsR0FBRyxDQUFDLENBQUM7Q0FFTCxNQUFNLGNBQWMsSUFBSSxLQUFLLENBQUMsQ0FBQyxZQUFZO0NBRTNDLE9BQ0Usd0JBQUMsT0FBRDtFQUFLLFdBQVc7WUFBaEI7R0FHRSx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmO0tBRUUsd0JBQUMsT0FBRCxFQUNFLFdBQVcsb0ZBQ1QsY0FBYyw0Q0FBNEMsY0FFN0Q7Ozs7O0tBQ0Qsd0JBQUMsT0FBRDtNQUNFLFdBQVcscUZBQ1QsY0FBYyw0Q0FBNEM7TUFFNUQsT0FBTyxFQUFFLGdCQUFnQixRQUFRO0tBQ2xDOzs7OztLQUNELHdCQUFDLE9BQUQ7TUFDRSxXQUFXLHVGQUNULGNBQWMsNENBQTRDO01BRTVELE9BQU8sRUFBRSxnQkFBZ0IsUUFBUTtLQUNsQzs7Ozs7S0FHRCx3QkFBQyxPQUFELEVBQUssV0FBVSw0R0FBNkc7Ozs7O0lBQ3pIOzs7Ozs7R0FHTCx3QkFBQyxVQUFEO0lBQVEsV0FBVTtjQUFsQixDQUNFLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBRWIsd0JBQUMsVUFBRDtNQUNFLFNBQVM7TUFDVCxjQUFZLGNBQWMsNEJBQTRCO01BQ3RELFdBQVcsd0xBQ1QsY0FDSSw4SEFDQTtNQUVOLE9BQU8sY0FBYyx5Q0FBeUM7Z0JBRTdELGNBQ0M7T0FDRSx3QkFBQyxRQUFEO1FBQU0sV0FBVTtrQkFBaEIsQ0FDRSx3QkFBQyxRQUFELEVBQU0sV0FBVSx3RkFBOEY7Ozs7a0JBQzlHLHdCQUFDLFFBQUQsRUFBTSxXQUFVLDBEQUFnRTs7OztnQkFDNUU7Ozs7OztPQUNOLHdCQUFDLFVBQUQsRUFBVSxXQUFVLHlFQUEwRTs7Ozs7T0FDOUYsd0JBQUMsUUFBRDtRQUFNLFdBQVU7a0JBQWhCLENBQWdDLFVBQU0sd0JBQUMsVUFBRDtTQUFRLFdBQVU7bUJBQWE7UUFBVTs7OztnQkFBTzs7Ozs7O01BQ3RGOzs7O2lCQUVGO09BQ0Usd0JBQUMsUUFBRCxFQUFNLFdBQVUsZ0RBQXNEOzs7OztPQUN0RSx3QkFBQyxNQUFELEVBQU0sV0FBVSw2QkFBOEI7Ozs7O09BQzlDLHdCQUFDLFFBQUQ7UUFBTSxXQUFVO2tCQUFoQixDQUFnQyxVQUFNLHdCQUFDLFVBQUQ7U0FBUSxXQUFVO21CQUFpQjtRQUFXOzs7O2dCQUFPOzs7Ozs7TUFDM0Y7Ozs7O0tBRUU7Ozs7O0lBQ0w7Ozs7Y0FHTCx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmO01BQ0Usd0JBQUMsVUFBRDtPQUNFLGVBQWUsdUJBQXVCLElBQUk7T0FDMUMsV0FBVTtPQUNWLE9BQU07T0FDTixjQUFXO2lCQUpiLENBTUUsd0JBQUMsVUFBRCxFQUFVLFdBQVUsK0JBQWdDOzs7O2lCQUNwRCx3QkFBQyxRQUFEO1FBQU0sV0FBVTtrQkFBbUI7T0FBYzs7OztlQUMzQzs7Ozs7O01BRVIsd0JBQUMsVUFBRDtPQUNFLGVBQWUsaUJBQWlCLElBQUk7T0FDcEMsV0FBVTtPQUNWLE9BQU07T0FDTixjQUFXO2lCQUVYLHdCQUFDLFFBQUQsRUFBUSxXQUFVLGNBQWU7Ozs7O01BQzNCOzs7OztNQUVSLHdCQUFDLFVBQUQ7T0FDRSxTQUFTO09BQ1QsV0FBVTtPQUNWLE9BQU07T0FDTixjQUFXO2lCQUVYLHdCQUFDLFFBQUQsRUFBUSxXQUFVLDRCQUE2Qjs7Ozs7TUFDekM7Ozs7O0tBQ0w7Ozs7O1lBQ0M7Ozs7OztHQUdSLHdCQUFDLFFBQUQ7SUFBTSxXQUFVO2NBQWhCLENBQ0Usd0JBQUMsT0FBRDtLQUFLLFdBQVcsd0dBQ2QsY0FBYyw0Q0FBNEM7ZUFENUQsQ0FLRSx3QkFBQyxPQUFEO01BQ0UsV0FBVyw0R0FDVCxZQUFZLFNBQVMsYUFBYSxZQUFZLFFBQVE7TUFFeEQsT0FBTyxFQUNMLGlCQUFpQixZQUFZLFNBQVMsVUFBVSxRQUFRLFlBQVksTUFBTSxNQUFNLFVBQ2xGO2dCQU5GO09BU0csWUFBWSxTQUFTLFdBQ3BCLHdCQUFDLFNBQUQ7UUFDRSxLQUFLO1FBQ0wsV0FBVTtRQUNWO1FBQ0E7UUFDQTtRQUNBO09BQ0Q7Ozs7O09BSUgsd0JBQUMsT0FBRCxFQUFLLFdBQVUsMkdBQTRHOzs7OztPQUczSCx3QkFBQyxVQUFEO1FBQ0UsZUFBZSxvQkFBb0IsSUFBSTtRQUN2QyxXQUFVO1FBQ1YsT0FBTTtrQkFIUixDQUtFLHdCQUFDLFFBQUQsRUFBUSxXQUFVLHVFQUF3RTs7OztrQkFDMUYsd0JBQUMsUUFBRCxZQUFNLGFBQWdCOzs7O2dCQUNoQjs7Ozs7O01BQ0w7Ozs7O2VBR0wsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWY7T0FHRSx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUNFLHdCQUFDLE9BQUQ7U0FBSyxXQUFXLHlDQUF5QyxjQUFjLGdCQUFnQjttQkFDckYsd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQ2Isd0JBQUMsT0FBRDtXQUNFLGVBQWUscUJBQXFCLElBQUk7V0FDeEMsV0FBVyx1TUFDVCxjQUNJLG9GQUNBO1dBRU4sT0FBTTtxQkFQUixDQVNHLFlBQ0Msd0JBQUMsT0FBRDtZQUNFLEtBQUs7WUFDTCxLQUFJO1lBQ0osV0FBVTtZQUNWLGVBQWU7YUFDYixVQUFVLG9DQUFvQyxPQUFPO2FBQ3JELGFBQWEsSUFBSTtZQUNuQjtXQUNEOzs7O3NCQUVELHdCQUFDLFFBQUQ7WUFBTSxXQUFXLDBGQUNmLGNBQ0ksNkdBQ0E7c0JBQ0Y7V0FFRTs7OztxQkFJUix3QkFBQyxPQUFEO1lBQUssV0FBVTtzQkFBZixDQUNFLHdCQUFDLFFBQUQsRUFBUSxXQUFVLHdCQUF5Qjs7OztzQkFDM0Msd0JBQUMsUUFBRDthQUFNLFdBQVU7dUJBQXVDO1lBQWdCOzs7O29CQUNwRTs7Ozs7bUJBQ0Y7Ozs7OztTQUNGOzs7OztRQUNGOzs7O2tCQUdMLHdCQUFDLFVBQUQ7U0FDRSxlQUFlLHFCQUFxQixJQUFJO1NBQ3hDLFdBQVU7U0FDVixPQUFNO1NBQ04sY0FBVzttQkFFWCx3QkFBQyxRQUFELEVBQVEsV0FBVSxjQUFlOzs7OztRQUMzQjs7OztnQkFDTDs7Ozs7O09BR0wsd0JBQUMsTUFBRDtRQUFJLFdBQVU7a0JBQWQsQ0FDRSx3QkFBQyxRQUFELFlBQU0saUJBQW9COzs7O2tCQUMxQix3QkFBQyxRQUFEO1NBQU0sT0FBTTtTQUFtQixXQUFVO21CQUN2Qyx3QkFBQyxjQUFELEVBQWMsV0FBVSx1Q0FBd0M7Ozs7O1FBQzVEOzs7O2dCQUNKOzs7Ozs7T0FHSix3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFDYix3QkFBQyxRQUFEO1NBQU0sV0FBVyx3R0FDZixjQUNJLDZEQUNBO21CQUhOLENBS0Usd0JBQUMsUUFBRCxFQUFNLFdBQVcsd0JBQXdCLGNBQWMsaUNBQWlDLG1CQUFxQjs7OzttQkFBQyx1QkFFMUc7Ozs7OztPQUNIOzs7OztPQUdMLHdCQUFDLEtBQUQ7UUFBRyxXQUFVO2tCQUE2RTtPQUV2Rjs7Ozs7T0FHSCx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFDYix3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZixDQUNFLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUFmLENBQ0Usd0JBQUMsT0FBRDtXQUFLLFdBQVcsd0ZBQ2QsY0FDSSxvREFDQTtxQkFFSix3QkFBQyxXQUFELEVBQVcsV0FBVSxVQUFXOzs7OztVQUM3Qjs7OztvQkFDTCx3QkFBQyxPQUFEO1dBQUssV0FBVTtxQkFBZixDQUNFLHdCQUFDLEtBQUQ7WUFBRyxXQUFVO3NCQUFnRTtXQUFpQjs7OztxQkFDOUYsd0JBQUMsS0FBRDtZQUFHLFdBQVU7c0JBQXlFO1dBRW5GOzs7O21CQUNBOzs7OztrQkFDRjs7Ozs7bUJBR0wsd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQWY7V0FFRSx3QkFBQyxLQUFEO1lBQ0UsTUFBSztZQUNMLFdBQVcsMEhBQ1QsY0FDSSxxRkFDQTtZQUVOLE9BQU07WUFDTixjQUFXO3NCQUVYLHdCQUFDLE9BQUQsRUFBTyxXQUFVLFVBQVc7Ozs7O1dBQzNCOzs7OztXQUdILHdCQUFDLEtBQUQ7WUFDRSxNQUFLO1lBQ0wsV0FBVywwSEFDVCxjQUNJLGlGQUNBO1lBRU4sT0FBTTtZQUNOLGNBQVc7c0JBRVgsd0JBQUMsZUFBRCxFQUFlLFdBQVUsVUFBVzs7Ozs7V0FDbkM7Ozs7O1dBR0gsd0JBQUMsVUFBRDtZQUNFLGVBQWUsc0JBQXNCLGFBQWE7WUFDbEQsV0FBVTtZQUNWLE9BQU07WUFDTixjQUFXO3NCQUVWLGVBQ0Msd0JBQUMsT0FBRCxFQUFPLFdBQVUsMkJBQTRCOzs7O3VCQUU3Qyx3QkFBQyxNQUFELEVBQU0sV0FBVSxpQ0FBa0M7Ozs7O1dBRTlDOzs7OztVQUNMOzs7OztpQkFDRjs7Ozs7O09BQ0Y7Ozs7O09BR0wsd0JBQUMsT0FBRDtRQUFLLElBQUc7UUFBdUIsV0FBVTtrQkFBekM7U0FHRSx3QkFBQyxLQUFEO1VBQ0UsTUFBSztVQUNMLFFBQU87VUFDUCxLQUFJO1VBQ0osV0FBVTtvQkFKWixDQU1FLHdCQUFDLE9BQUQ7V0FBSyxXQUFVO3FCQUFmLENBQ0Usd0JBQUMsT0FBRDtZQUFLLFdBQVU7c0JBQ2Isd0JBQUMsS0FBRCxFQUFHLFdBQVUsa0NBQW1DOzs7OztXQUM3Qzs7OztxQkFDTCx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsTUFBRDtZQUFJLFdBQVU7c0JBQWQsQ0FBbUgsWUFFakgsd0JBQUMsY0FBRCxFQUFjLFdBQVUsK0RBQWdFOzs7O29CQUN0Rjs7Ozs7cUJBQ0osd0JBQUMsS0FBRDtZQUFHLFdBQVU7c0JBQXlCO1dBQWlCOzs7O21CQUNwRDs7OzttQkFDRjs7Ozs7b0JBQ0wsd0JBQUMsT0FBRDtXQUFLLFdBQVU7cUJBQ2Isd0JBQUMsY0FBRCxFQUFjLFdBQVUsVUFBVzs7Ozs7VUFDaEM7Ozs7a0JBQ0o7Ozs7OztTQUdILHdCQUFDLEtBQUQ7VUFDRSxNQUFLO1VBQ0wsUUFBTztVQUNQLEtBQUk7VUFDSixXQUFVO29CQUpaLENBTUUsd0JBQUMsT0FBRDtXQUFLLFdBQVU7cUJBQWYsQ0FDRSx3QkFBQyxPQUFEO1lBQUssV0FBVTtzQkFDYix3QkFBQyxLQUFELEVBQUcsV0FBVSw4QkFBK0I7Ozs7O1dBQ3pDOzs7O3FCQUNMLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxNQUFEO1lBQUksV0FBVTtzQkFBZCxDQUFtSCxVQUVqSCx3QkFBQyxjQUFELEVBQWMsV0FBVSwrREFBZ0U7Ozs7b0JBQ3RGOzs7OztxQkFDSix3QkFBQyxLQUFEO1lBQUcsV0FBVTtzQkFBeUI7V0FBVzs7OzttQkFDOUM7Ozs7bUJBQ0Y7Ozs7O29CQUNMLHdCQUFDLE9BQUQ7V0FBSyxXQUFVO3FCQUNiLHdCQUFDLGNBQUQsRUFBYyxXQUFVLFVBQVc7Ozs7O1VBQ2hDOzs7O2tCQUNKOzs7Ozs7U0FHSCx3QkFBQyxLQUFEO1VBQ0UsTUFBSztVQUNMLFFBQU87VUFDUCxLQUFJO1VBQ0osV0FBVTtvQkFKWixDQU1FLHdCQUFDLE9BQUQ7V0FBSyxXQUFVO3FCQUFmLENBQ0Usd0JBQUMsT0FBRDtZQUFLLFdBQVU7c0JBQ2Isd0JBQUMsT0FBRDthQUFLLFdBQVU7dUJBQ2Isd0JBQUMsS0FBRCxFQUFHLFdBQVUsaUNBQWtDOzs7OztZQUM1Qzs7Ozs7V0FDRjs7OztxQkFDTCx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsTUFBRDtZQUFJLFdBQVU7c0JBQWQsQ0FBbUgsYUFFakgsd0JBQUMsY0FBRCxFQUFjLFdBQVUsK0RBQWdFOzs7O29CQUN0Rjs7Ozs7cUJBQ0osd0JBQUMsS0FBRDtZQUFHLFdBQVU7c0JBQXlCO1dBQWM7Ozs7bUJBQ2pEOzs7O21CQUNGOzs7OztvQkFDTCx3QkFBQyxPQUFEO1dBQUssV0FBVTtxQkFDYix3QkFBQyxjQUFELEVBQWMsV0FBVSxVQUFXOzs7OztVQUNoQzs7OztrQkFDSjs7Ozs7O1FBRUE7Ozs7OztPQUdMLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQ0Usd0JBQUMsVUFBRDtTQUNFLGVBQWUscUJBQXFCLElBQUk7U0FDeEMsV0FBVTttQkFGWixDQUlFLHdCQUFDLFFBQUQsRUFBUSxXQUFVLDRCQUE2Qjs7OzttQkFBQyx3QkFFMUM7Ozs7O2tCQUVSLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmLENBQ0Usd0JBQUMsUUFBRDtVQUFNLFdBQVU7b0JBQWhCLENBQ0csY0FDQyx3QkFBQyxLQUFELEVBQUssV0FBVSw4QkFBK0I7Ozs7cUJBRTlDLHdCQUFDLFFBQUQsRUFBUSxXQUFVLDZCQUE4Qjs7OztvQkFDaEQsYUFFRTs7Ozs7bUJBQ04sd0JBQUMsVUFBRDtVQUNFLFNBQVM7VUFDVCxXQUFXLCtHQUNULGNBQ0ksaUZBQ0E7b0JBR0wsY0FBYyxrQkFBa0I7U0FDM0I7Ozs7aUJBQ0w7Ozs7O2dCQUNGOzs7Ozs7TUFFRjs7Ozs7YUFDRjs7Ozs7Y0FHTCx3QkFBQyxVQUFEO0tBQVEsV0FBVTtlQUFsQixDQUNFLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQ0Usd0JBQUMsVUFBRDtPQUNFLFNBQVM7T0FDVCxXQUFVO2lCQUZaLENBSUUsd0JBQUMsUUFBRCxFQUFRLFdBQVUsNEJBQTZCOzs7O2lCQUFDLGVBRTFDOzs7OztnQkFFUix3QkFBQyxVQUFEO09BQ0UsZUFBZSx1QkFBdUIsSUFBSTtPQUMxQyxXQUFVO2lCQUZaLENBSUUsd0JBQUMsVUFBRCxFQUFVLFdBQVUsK0JBQWdDOzs7O2lCQUFDLGtCQUUvQzs7Ozs7Y0FDTDs7Ozs7ZUFFTCx3QkFBQyxLQUFEO01BQUcsV0FBVTtnQkFBYjtPQUFzRDtPQUNqRDtPQUFZO01BQ2Q7Ozs7O2FBQ0c7Ozs7O1lBQ0o7Ozs7OztHQUdOLHdCQUFDLGlCQUFELFlBQ0cscUJBQ0Msd0JBQUMsT0FBTyxLQUFSO0lBQ0UsU0FBUyxFQUFFLFNBQVMsRUFBRTtJQUN0QixTQUFTLEVBQUUsU0FBUyxFQUFFO0lBQ3RCLE1BQU0sRUFBRSxTQUFTLEVBQUU7SUFDbkIsWUFBWTtLQUFFLFVBQVU7S0FBTSxNQUFNO0lBQVU7SUFDOUMsVUFBVSxNQUFNO0tBQ2QsSUFBSSxFQUFFLFdBQVcsRUFBRSxlQUFlLHFCQUFxQixLQUFLO0lBQzlEO0lBQ0EsV0FBVTtjQUVWLHdCQUFDLE9BQU8sS0FBUjtLQUNFLFNBQVM7TUFBRSxTQUFTO01BQUcsR0FBRztNQUFJLE9BQU87S0FBSztLQUMxQyxTQUFTO01BQUUsU0FBUztNQUFHLEdBQUc7TUFBRyxPQUFPO0tBQUU7S0FDdEMsTUFBTTtNQUFFLFNBQVM7TUFBRyxHQUFHO01BQUksT0FBTztLQUFLO0tBQ3ZDLFlBQVk7TUFBRSxNQUFNO01BQVUsU0FBUztNQUFJLFdBQVc7TUFBSyxNQUFNO0tBQUk7S0FDckUsV0FBVTtlQUxaO01BU0Usd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDRSx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUNFLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUNiLHdCQUFDLE1BQUQsRUFBTSxXQUFVLFVBQVc7Ozs7O1FBQ3hCOzs7O2tCQUNMLHdCQUFDLE1BQUQ7U0FBSSxXQUFVO21CQUFpQztRQUEwQjs7OztnQkFDdEU7Ozs7O2lCQUNMLHdCQUFDLFVBQUQ7UUFDRSxlQUFlLHFCQUFxQixLQUFLO1FBQ3pDLFdBQVU7UUFDVixjQUFXO2tCQUVYLHdCQUFDLEdBQUQsRUFBRyxXQUFVLFVBQVc7Ozs7O09BQ2xCOzs7O2VBQ0w7Ozs7OztNQUdMLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsT0FBRDtRQUFLLFdBQVcsOENBQThDLGNBQWMsZ0JBQWdCO2tCQUMxRix3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFDYix3QkFBQyxPQUFEO1VBQUssV0FBVyxtR0FDZCxjQUNJLG9GQUNBO29CQUVILFlBQ0Msd0JBQUMsT0FBRDtXQUFLLEtBQUs7V0FBVyxLQUFJO1dBQVUsV0FBVTtVQUEyQzs7OztxQkFFeEYsd0JBQUMsUUFBRDtXQUFNLFdBQVcsdUJBQ2YsY0FBYyw4RkFBOEY7cUJBQzFHO1VBRUU7Ozs7O1NBRUw7Ozs7O1FBQ0Y7Ozs7O09BQ0Y7Ozs7aUJBQ0wsd0JBQUMsUUFBRDtRQUFNLFdBQVU7a0JBQ2IsWUFBWSx5QkFBeUI7T0FDbEM7Ozs7ZUFDSDs7Ozs7O01BRUwsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWY7UUFFRSx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZixDQUNFLHdCQUFDLFNBQUQ7VUFBTyxXQUFVO29CQUFqQixDQUNFLHdCQUFDLGFBQUQsRUFBYSxXQUFVLGNBQWU7Ozs7b0JBQUMscUJBQ2xDOzs7OzttQkFDUCx3QkFBQyxTQUFEO1VBQU8sV0FBVTtvQkFBakIsQ0FDRSx3QkFBQyxPQUFEO1dBQUssV0FBVTtxQkFBZjtZQUNFLHdCQUFDLFFBQUQsRUFBUSxXQUFVLDBFQUEyRTs7Ozs7WUFDN0Ysd0JBQUMsS0FBRDthQUFHLFdBQVU7dUJBQXFDO1lBQXNCOzs7OztZQUN4RSx3QkFBQyxLQUFEO2FBQUcsV0FBVTt1QkFBNkI7WUFBZ0M7Ozs7O1dBQ3ZFOzs7OztvQkFDTCx3QkFBQyxTQUFEO1dBQ0UsTUFBSztXQUNMLFFBQU87V0FDUCxXQUFVO1dBQ1YsVUFBVTtVQUNYOzs7O2tCQUNJOzs7OztpQkFDSjs7Ozs7O1FBR0wsd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWYsQ0FDRSx3QkFBQyxTQUFEO1VBQU8sV0FBVTtvQkFBakIsQ0FDRSx3QkFBQyxXQUFELEVBQVcsV0FBVSxjQUFlOzs7O29CQUFDLHVCQUNoQzs7Ozs7bUJBQ1Asd0JBQUMsUUFBRDtVQUFNLFVBQVU7VUFBc0IsV0FBVTtvQkFBaEQsQ0FDRSx3QkFBQyxTQUFEO1dBQ0UsTUFBSztXQUNMLE9BQU87V0FDUCxXQUFXLE1BQU0sa0JBQWtCLEVBQUUsT0FBTyxLQUFLO1dBQ2pELGFBQVk7V0FDWixXQUFVO1VBQ1g7Ozs7b0JBQ0Qsd0JBQUMsVUFBRDtXQUNFLE1BQUs7V0FDTCxXQUFVO3FCQUNYO1VBRU87Ozs7a0JBQ0o7Ozs7O2lCQUNIOzs7Ozs7UUFHTCx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsU0FBRDtTQUFPLFdBQVU7bUJBQXVFO1FBRWpGOzs7O2tCQUNQLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUNaLGVBQWUsS0FBSyxRQUFRLFVBQzNCLHdCQUFDLFVBQUQ7VUFFRSxlQUFlO1dBQ2IsYUFBYSxPQUFPLEdBQUc7V0FDdkIsVUFBVSxZQUFZLE9BQU8sS0FBSyxTQUFTO1dBQzNDLHFCQUFxQixLQUFLO1VBQzVCO1VBQ0EsV0FBVTtVQUNWLE9BQU8sT0FBTztvQkFSaEIsQ0FVRSx3QkFBQyxPQUFEO1dBQ0UsS0FBSyxPQUFPO1dBQ1osS0FBSyxPQUFPO1dBQ1osV0FBVTtVQUNYOzs7O29CQUNELHdCQUFDLFFBQUQ7V0FBTSxXQUFVO3FCQUNiLE9BQU87VUFDSjs7OztrQkFDQTtZQWpCRDs7OztnQkFpQkMsQ0FDVDtRQUNFOzs7O2dCQUNGOzs7OztPQUNGOzs7Ozs7TUFHTCx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNFLHdCQUFDLFVBQUQ7UUFDRSxTQUFTO1FBQ1QsV0FBVTtrQkFGWixDQUlFLHdCQUFDLFFBQUQsRUFBUSxXQUFVLGNBQWU7Ozs7a0JBQUMsd0JBRTVCOzs7OztpQkFDUix3QkFBQyxVQUFEO1FBQ0UsZUFBZSxxQkFBcUIsS0FBSztRQUN6QyxXQUFVO2tCQUNYO09BRU87Ozs7ZUFDTDs7Ozs7O0tBRUs7Ozs7OztHQUNGOzs7O1lBRUM7Ozs7O0dBR2pCLHdCQUFDLGlCQUFELFlBQ0csb0JBQ0Msd0JBQUMsT0FBTyxLQUFSO0lBQ0UsU0FBUyxFQUFFLFNBQVMsRUFBRTtJQUN0QixTQUFTLEVBQUUsU0FBUyxFQUFFO0lBQ3RCLE1BQU0sRUFBRSxTQUFTLEVBQUU7SUFDbkIsWUFBWTtLQUFFLFVBQVU7S0FBTSxNQUFNO0lBQVU7SUFDOUMsVUFBVSxNQUFNO0tBQ2QsSUFBSSxFQUFFLFdBQVcsRUFBRSxlQUFlLG9CQUFvQixLQUFLO0lBQzdEO0lBQ0EsV0FBVTtjQUVWLHdCQUFDLE9BQU8sS0FBUjtLQUNFLFNBQVM7TUFBRSxTQUFTO01BQUcsR0FBRztNQUFJLE9BQU87S0FBSztLQUMxQyxTQUFTO01BQUUsU0FBUztNQUFHLEdBQUc7TUFBRyxPQUFPO0tBQUU7S0FDdEMsTUFBTTtNQUFFLFNBQVM7TUFBRyxHQUFHO01BQUksT0FBTztLQUFLO0tBQ3ZDLFlBQVk7TUFBRSxNQUFNO01BQVUsU0FBUztNQUFJLFdBQVc7TUFBSyxNQUFNO0tBQUk7S0FDckUsV0FBVTtlQUxaO01BU0Usd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDRSx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUNFLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUNiLHdCQUFDLFNBQUQsRUFBUyxXQUFVLFVBQVc7Ozs7O1FBQzNCOzs7O2tCQUNMLHdCQUFDLE1BQUQ7U0FBSSxXQUFVO21CQUFpQztRQUFnQzs7OztnQkFDNUU7Ozs7O2lCQUNMLHdCQUFDLFVBQUQ7UUFDRSxlQUFlLG9CQUFvQixLQUFLO1FBQ3hDLFdBQVU7UUFDVixjQUFXO2tCQUVYLHdCQUFDLEdBQUQsRUFBRyxXQUFVLFVBQVc7Ozs7O09BQ2xCOzs7O2VBQ0w7Ozs7OztNQUdMLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsT0FBRCxhQUNFLHdCQUFDLEtBQUQ7UUFBRyxXQUFVO2tCQUFiLENBQ0Usd0JBQUMsTUFBRCxFQUFNLFdBQVUsNEJBQTZCOzs7O2tCQUFDLGlCQUU3Qzs7Ozs7aUJBQ0gsd0JBQUMsS0FBRDtRQUFHLFdBQVU7a0JBQ1YsWUFBWSx3QkFBd0I7T0FDcEM7Ozs7ZUFDQTs7OztpQkFDTCx3QkFBQyxVQUFEO1FBQ0UsZUFBZTtTQUNiLG9CQUFvQixLQUFLO1NBQ3pCLHFCQUFxQixJQUFJO1FBQzNCO1FBQ0EsV0FBVTtrQkFMWixDQU9FLHdCQUFDLFFBQUQsRUFBUSxXQUFVLFVBQVc7Ozs7a0JBQUMsY0FFeEI7Ozs7O2VBQ0w7Ozs7OztNQUdMLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsT0FBRCxhQUNFLHdCQUFDLEtBQUQ7UUFBRyxXQUFVO2tCQUFiLENBQ0Usd0JBQUMsVUFBRCxFQUFVLFdBQVUsOEJBQStCOzs7O2tCQUFDLHVCQUVuRDs7Ozs7aUJBQ0gsd0JBQUMsS0FBRDtRQUFHLFdBQVU7a0JBQ1YsY0FBYyxtREFBbUQ7T0FDakU7Ozs7ZUFDQTs7OztpQkFDTCx3QkFBQyxVQUFEO1FBQ0UsU0FBUztRQUNULFdBQVcsaUZBQ1QsY0FDSSxtRUFDQTtrQkFHTCxjQUFjLGFBQWE7T0FDdEI7Ozs7ZUFDTDs7Ozs7O01BR0wsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWY7UUFHRSx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZixDQUNFLHdCQUFDLFNBQUQ7VUFBTyxXQUFVO29CQUFqQixDQUNFLHdCQUFDLE9BQUQsRUFBTyxXQUFVLGNBQWU7Ozs7b0JBQUMscUJBQzVCOzs7OzttQkFDUCx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFBZixDQUVFLHdCQUFDLFNBQUQ7V0FBTyxXQUFVO3FCQUFqQixDQUNFLHdCQUFDLE9BQUQ7WUFBSyxXQUFVO3NCQUFmO2FBQ0Usd0JBQUMsT0FBRCxFQUFPLFdBQVUsNEVBQTZFOzs7OzthQUM5Rix3QkFBQyxLQUFEO2NBQUcsV0FBVTt3QkFBcUM7YUFBb0I7Ozs7O2FBQ3RFLHdCQUFDLEtBQUQ7Y0FBRyxXQUFVO3dCQUE2QjthQUFzQjs7Ozs7WUFDN0Q7Ozs7O3FCQUNMLHdCQUFDLFNBQUQ7WUFDRSxNQUFLO1lBQ0wsUUFBTztZQUNQLFdBQVU7WUFDVixVQUFVO1dBQ1g7Ozs7bUJBQ0k7Ozs7O29CQUdQLHdCQUFDLFFBQUQ7V0FBTSxVQUFVO1dBQXFCLFdBQVU7cUJBQS9DLENBQ0Usd0JBQUMsU0FBRDtZQUNFLE1BQUs7WUFDTCxPQUFPO1lBQ1AsV0FBVyxNQUFNLGlCQUFpQixFQUFFLE9BQU8sS0FBSztZQUNoRCxhQUFZO1lBQ1osV0FBVTtXQUNYOzs7O3FCQUNELHdCQUFDLFVBQUQ7WUFDRSxNQUFLO1lBQ0wsV0FBVTtzQkFDWDtXQUVPOzs7O21CQUNKOzs7OztrQkFDSDs7Ozs7aUJBQ0Y7Ozs7OztRQUdMLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmLENBQ0Usd0JBQUMsU0FBRDtVQUFPLFdBQVU7b0JBQWpCLENBQ0Usd0JBQUMsV0FBRCxFQUFXLFdBQVUsY0FBZTs7OztvQkFBQyxxQkFDaEM7Ozs7O21CQUNQLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUFmLENBRUUsd0JBQUMsU0FBRDtXQUFPLFdBQVU7cUJBQWpCLENBQ0Usd0JBQUMsT0FBRDtZQUFLLFdBQVU7c0JBQWY7YUFDRSx3QkFBQyxRQUFELEVBQVEsV0FBVSwwRUFBMkU7Ozs7O2FBQzdGLHdCQUFDLEtBQUQ7Y0FBRyxXQUFVO3dCQUFxQzthQUFvQjs7Ozs7YUFDdEUsd0JBQUMsS0FBRDtjQUFHLFdBQVU7d0JBQTZCO2FBQTJCOzs7OztZQUNsRTs7Ozs7cUJBQ0wsd0JBQUMsU0FBRDtZQUNFLE1BQUs7WUFDTCxRQUFPO1lBQ1AsV0FBVTtZQUNWLFVBQVU7V0FDWDs7OzttQkFDSTs7Ozs7b0JBR1Asd0JBQUMsUUFBRDtXQUFNLFVBQVU7V0FBcUIsV0FBVTtxQkFBL0MsQ0FDRSx3QkFBQyxTQUFEO1lBQ0UsTUFBSztZQUNMLE9BQU87WUFDUCxXQUFXLE1BQU0saUJBQWlCLEVBQUUsT0FBTyxLQUFLO1lBQ2hELGFBQVk7WUFDWixXQUFVO1dBQ1g7Ozs7cUJBQ0Qsd0JBQUMsVUFBRDtZQUNFLE1BQUs7WUFDTCxXQUFVO3NCQUNYO1dBRU87Ozs7bUJBQ0o7Ozs7O2tCQUNIOzs7OztpQkFDRjs7Ozs7O1FBR0wsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFNBQUQ7U0FBTyxXQUFVO21CQUF1RTtRQUVqRjs7OztrQkFDUCx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFDWixpQkFBaUIsS0FBSyxXQUNyQix3QkFBQyxVQUFEO1VBRUUsZUFBZSxtQkFBbUIsT0FBTyxLQUFLO1VBQzlDLFdBQVcsbUJBQW1CLE9BQU8sTUFBTSxtRkFDekMsWUFBWSxTQUFTLGNBQWMsWUFBWSxVQUFVLE9BQU8sUUFDNUQseUNBQ0E7VUFFTixPQUFPLE9BQU87b0JBRWQsd0JBQUMsUUFBRDtXQUFNLFdBQVU7cUJBQ2IsT0FBTztVQUNKOzs7OztTQUNBLEdBWkQsT0FBTzs7OztnQkFZTixDQUNUO1FBQ0U7Ozs7Z0JBQ0Y7Ozs7O09BRUY7Ozs7OztNQUdMLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsVUFBRDtRQUNFLFNBQVM7UUFDVCxXQUFVO2tCQUZaLENBSUUsd0JBQUMsV0FBRCxFQUFXLFdBQVUsY0FBZTs7OztrQkFBQyxlQUUvQjs7Ozs7aUJBQ1Isd0JBQUMsVUFBRDtRQUNFLGVBQWUsb0JBQW9CLEtBQUs7UUFDeEMsV0FBVTtrQkFDWDtPQUVPOzs7O2VBQ0w7Ozs7OztLQUVLOzs7Ozs7R0FDRjs7OztZQUVDOzs7OztHQUdqQix3QkFBQyxpQkFBRCxZQUNHLGlCQUNDLHdCQUFDLE9BQU8sS0FBUjtJQUNFLFNBQVMsRUFBRSxTQUFTLEVBQUU7SUFDdEIsU0FBUyxFQUFFLFNBQVMsRUFBRTtJQUN0QixNQUFNLEVBQUUsU0FBUyxFQUFFO0lBQ25CLFlBQVk7S0FBRSxVQUFVO0tBQU0sTUFBTTtJQUFVO0lBQzlDLFVBQVUsTUFBTTtLQUNkLElBQUksRUFBRSxXQUFXLEVBQUUsZUFBZSxpQkFBaUIsS0FBSztJQUMxRDtJQUNBLFdBQVU7Y0FFVix3QkFBQyxPQUFPLEtBQVI7S0FDRSxTQUFTO01BQUUsU0FBUztNQUFHLEdBQUc7TUFBSSxPQUFPO0tBQUs7S0FDMUMsU0FBUztNQUFFLFNBQVM7TUFBRyxHQUFHO01BQUcsT0FBTztLQUFFO0tBQ3RDLE1BQU07TUFBRSxTQUFTO01BQUcsR0FBRztNQUFJLE9BQU87S0FBSztLQUN2QyxZQUFZO01BQUUsTUFBTTtNQUFVLFNBQVM7TUFBSSxXQUFXO01BQUssTUFBTTtLQUFJO0tBQ3JFLFdBQVU7ZUFMWjtNQU9FLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsTUFBRDtRQUFJLFdBQVU7a0JBQWQsQ0FDRSx3QkFBQyxRQUFELEVBQVEsV0FBVSx3QkFBeUI7Ozs7a0JBQUMsaUJBRTFDOzs7OztpQkFDSix3QkFBQyxVQUFEO1FBQ0UsZUFBZSxpQkFBaUIsS0FBSztRQUNyQyxXQUFVO2tCQUVWLHdCQUFDLEdBQUQsRUFBRyxXQUFVLGNBQWU7Ozs7O09BQ3RCOzs7O2VBQ0w7Ozs7OztNQUdMLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUNiLHdCQUFDLE9BQUQ7UUFDRSxLQUFLLGlFQUFpRSxtQkFDcEUsT0FBTyxXQUFXLGNBQWMsT0FBTyxTQUFTLE9BQU8sMkJBQ3pEO1FBQ0EsS0FBSTtRQUNKLFdBQVU7UUFDVixVQUFVLE1BQU07U0FDZCxBQUFDLEVBQUUsT0FBNEIsTUFBTSxVQUFVO1FBQ2pEO09BQ0Q7Ozs7O01BQ0U7Ozs7O01BRUwsd0JBQUMsS0FBRDtPQUFHLFdBQVU7aUJBQXNDO01BQThCOzs7OztNQUNqRix3QkFBQyxLQUFEO09BQUcsV0FBVTtpQkFBa0M7TUFBaUQ7Ozs7O01BRWhHLHdCQUFDLFVBQUQ7T0FDRSxlQUFlO1FBQ2IsbUJBQW1CO1FBQ25CLGlCQUFpQixLQUFLO09BQ3hCO09BQ0EsV0FBVTtpQkFDWDtNQUVPOzs7OztLQUNFOzs7Ozs7R0FDRjs7OztZQUVDOzs7OztHQUdqQix3QkFBQyxpQkFBRCxZQUNHLHVCQUNDLHdCQUFDLE9BQU8sS0FBUjtJQUNFLFNBQVMsRUFBRSxTQUFTLEVBQUU7SUFDdEIsU0FBUyxFQUFFLFNBQVMsRUFBRTtJQUN0QixNQUFNLEVBQUUsU0FBUyxFQUFFO0lBQ25CLFlBQVk7S0FBRSxVQUFVO0tBQU0sTUFBTTtJQUFVO0lBQzlDLFVBQVUsTUFBTTtLQUNkLElBQUksRUFBRSxXQUFXLEVBQUUsZUFBZSx1QkFBdUIsS0FBSztJQUNoRTtJQUNBLFdBQVU7Y0FFVix3QkFBQyxPQUFPLEtBQVI7S0FDRSxTQUFTO01BQUUsU0FBUztNQUFHLEdBQUc7TUFBSSxPQUFPO0tBQUs7S0FDMUMsU0FBUztNQUFFLFNBQVM7TUFBRyxHQUFHO01BQUcsT0FBTztLQUFFO0tBQ3RDLE1BQU07TUFBRSxTQUFTO01BQUcsR0FBRztNQUFJLE9BQU87S0FBSztLQUN2QyxZQUFZO01BQUUsTUFBTTtNQUFVLFNBQVM7TUFBSSxXQUFXO01BQUssTUFBTTtLQUFJO0tBQ3JFLFdBQVU7ZUFMWjtNQU9FLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWYsQ0FDRSx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFDYix3QkFBQyxVQUFELEVBQVUsV0FBVSxVQUFXOzs7OztRQUM1Qjs7OztrQkFDTCx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZixDQUNFLHdCQUFDLE1BQUQ7VUFBSSxXQUFVO29CQUFpQztTQUEwQjs7OzttQkFDekUsd0JBQUMsS0FBRDtVQUFHLFdBQVU7b0JBQTZCO1NBQXdDOzs7O2lCQUMvRTs7Ozs7Z0JBQ0Y7Ozs7O2lCQUNMLHdCQUFDLFVBQUQ7UUFDRSxlQUFlLHVCQUF1QixLQUFLO1FBQzNDLFdBQVU7UUFDVixjQUFXO2tCQUVYLHdCQUFDLEdBQUQsRUFBRyxXQUFVLFVBQVc7Ozs7O09BQ2xCOzs7O2VBQ0w7Ozs7OztNQUVMLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmO1FBRUUsd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWYsQ0FDRSx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFBZixDQUNFLHdCQUFDLE9BQUQ7V0FBSyxXQUFVO3FCQUNiLHdCQUFDLGFBQUQsRUFBYSxXQUFVLFVBQVc7Ozs7O1VBQy9COzs7O29CQUNMLHdCQUFDLE9BQUQ7V0FBSyxXQUFVO3FCQUFmLENBQ0Usd0JBQUMsT0FBRDtZQUFLLFdBQVU7c0JBQWYsQ0FDRSx3QkFBQyxNQUFEO2FBQUksV0FBVTt1QkFBOEU7WUFFeEY7Ozs7c0JBQ0osd0JBQUMsUUFBRDthQUFNLFdBQVU7dUJBQTJJO1lBRXJKOzs7O29CQUNIOzs7OztxQkFDTCx3QkFBQyxLQUFEO1lBQUcsV0FBVTtzQkFBYjthQUFzRDthQUNILHdCQUFDLFFBQUQ7Y0FBTSxXQUFVO3dCQUFtQjthQUFrQjs7Ozs7YUFBQztZQUN0Rzs7Ozs7bUJBQ0E7Ozs7O2tCQUNGOzs7OzttQkFFTCx3QkFBQyxVQUFEO1VBQ0UsU0FBUztVQUNULFVBQVU7VUFDVixXQUFVO29CQUVULGdCQUNDLGdEQUNFLHdCQUFDLFNBQUQsRUFBUyxXQUFVLHVCQUF3Qjs7OztvQkFBQywwQkFFNUM7Ozs7cUJBRUYsZ0RBQ0Usd0JBQUMsVUFBRCxFQUFVLFdBQVUsVUFBVzs7OztvQkFBQyw4QkFFaEM7Ozs7O1NBRUU7Ozs7aUJBQ0w7Ozs7OztRQUdMLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmLENBQ0Usd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQWYsQ0FDRSx3QkFBQyxPQUFEO1dBQUssV0FBVTtxQkFDYix3QkFBQyxVQUFELEVBQVUsV0FBVSxVQUFXOzs7OztVQUM1Qjs7OztvQkFDTCx3QkFBQyxPQUFEO1dBQUssV0FBVTtxQkFBZixDQUNFLHdCQUFDLE1BQUQ7WUFBSSxXQUFVO3NCQUFrRjtXQUU1Rjs7OztxQkFDSix3QkFBQyxLQUFEO1lBQUcsV0FBVTtzQkFBeUM7V0FFbkQ7Ozs7bUJBQ0E7Ozs7O2tCQUNGOzs7OzttQkFFTCx3QkFBQyxVQUFEO1VBQ0UsU0FBUztVQUNULFdBQVU7b0JBRlosQ0FJRSx3QkFBQyxVQUFELEVBQVUsV0FBVSxVQUFXOzs7O29CQUFDLDZCQUUxQjs7Ozs7aUJBQ0w7Ozs7OztRQUdMLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmLENBQ0Usd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQWYsQ0FDRSx3QkFBQyxPQUFEO1dBQUssV0FBVTtxQkFDYix3QkFBQyxTQUFELEVBQVMsV0FBVSxVQUFXOzs7OztVQUMzQjs7OztvQkFDTCx3QkFBQyxPQUFEO1dBQUssV0FBVTtxQkFBZixDQUNFLHdCQUFDLE1BQUQ7WUFBSSxXQUFVO3NCQUFvRjtXQUU5Rjs7OztxQkFDSix3QkFBQyxLQUFEO1lBQUcsV0FBVTtzQkFBeUM7V0FFbkQ7Ozs7bUJBQ0E7Ozs7O2tCQUNGOzs7OzttQkFFTCx3QkFBQyxVQUFEO1VBQ0UsU0FBUztVQUNULFdBQVU7b0JBRlosQ0FJRSx3QkFBQyxVQUFELEVBQVUsV0FBVSxVQUFXOzs7O29CQUFDLHlCQUUxQjs7Ozs7aUJBQ0w7Ozs7OztPQUNGOzs7Ozs7TUFFTCx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFDYix3QkFBQyxVQUFEO1FBQ0UsZUFBZSx1QkFBdUIsS0FBSztRQUMzQyxXQUFVO2tCQUNYO09BRU87Ozs7O01BQ0w7Ozs7O0tBQ0s7Ozs7OztHQUNGOzs7O1lBRUM7Ozs7O0dBR2pCLHdCQUFDLGlCQUFELFlBQ0csU0FDQyx3QkFBQyxPQUFPLEtBQVI7SUFDRSxTQUFTO0tBQUUsU0FBUztLQUFHLEdBQUc7S0FBSSxPQUFPO0lBQUs7SUFDMUMsU0FBUztLQUFFLFNBQVM7S0FBRyxHQUFHO0tBQUcsT0FBTztJQUFFO0lBQ3RDLE1BQU07S0FBRSxTQUFTO0tBQUcsR0FBRztLQUFJLE9BQU87SUFBSztJQUN2QyxZQUFZO0tBQUUsTUFBTTtLQUFVLFNBQVM7S0FBSSxXQUFXO0lBQUk7SUFDMUQsV0FBVTtjQUxaLENBT0csTUFBTSxTQUFTLFVBQ2Qsd0JBQUMsYUFBRCxFQUFhLFdBQVUsaUNBQWtDOzs7O2VBQ3ZELE1BQU0sU0FBUyxTQUNqQix3QkFBQyxVQUFELEVBQVUsV0FBVSxtQ0FBb0M7Ozs7ZUFFeEQsd0JBQUMsY0FBRCxFQUFjLFdBQVUsb0NBQXFDOzs7O2NBRS9ELHdCQUFDLFFBQUQsWUFBTyxNQUFNLFFBQWM7Ozs7WUFDakI7Ozs7O1lBRUM7Ozs7O0dBR2pCLHdCQUFDLGlCQUFELFlBQ0csbUJBQ0Msd0JBQUMsT0FBTyxLQUFSO0lBQ0UsU0FBUztLQUFFLFNBQVM7S0FBRyxHQUFHO0tBQUksT0FBTztJQUFLO0lBQzFDLFNBQVM7S0FBRSxTQUFTO0tBQUcsR0FBRztLQUFHLE9BQU87SUFBRTtJQUN0QyxNQUFNO0tBQUUsU0FBUztLQUFHLEdBQUc7S0FBSSxPQUFPO0lBQUs7SUFDdkMsWUFBWTtLQUFFLE1BQU07S0FBVSxTQUFTO0tBQUksV0FBVztLQUFLLE1BQU07SUFBSTtJQUNyRSxXQUFXLCtKQUNULGNBQ0ksd0VBQ0E7Y0FSUixDQVdFLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWYsQ0FDRSx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUNFLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQ2Isd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQ1osWUFDQyx3QkFBQyxPQUFEO1VBQUssS0FBSztVQUFXLEtBQUk7VUFBUyxXQUFVO1NBQThCOzs7O29CQUUxRSx3QkFBQyxRQUFEO1VBQU0sV0FBVTtvQkFBb0c7U0FFOUc7Ozs7O1FBRUw7Ozs7O09BQ0Y7Ozs7aUJBQ0wsd0JBQUMsUUFBRCxFQUFNLFdBQVUsK0dBQWdIOzs7O2VBQzdIOzs7OztnQkFDTCx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsTUFBRDtPQUFJLFdBQVU7aUJBQWQsQ0FBdUUsd0JBRXJFLHdCQUFDLFVBQUQsRUFBVSxXQUFVLDBCQUEyQjs7OztlQUM3Qzs7Ozs7Z0JBQ0osd0JBQUMsS0FBRDtPQUFHLFdBQVU7aUJBQTZCO01BRXZDOzs7O2NBQ0E7Ozs7Y0FDRjs7Ozs7ZUFFTCx3QkFBQyxVQUFEO01BQ0UsZUFBZSxtQkFBbUIsS0FBSztNQUN2QyxXQUFVO01BQ1YsY0FBVztnQkFFWCx3QkFBQyxHQUFELEVBQUcsV0FBVSxjQUFlOzs7OztLQUN0Qjs7OzthQUNMOzs7OztjQUdMLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWY7TUFDRSx3QkFBQyxLQUFEO09BQ0UsTUFBSztPQUNMLFFBQU87T0FDUCxLQUFJO09BQ0osZUFBZSxtQkFBbUIsS0FBSztPQUN2QyxXQUFVO2lCQUxaLENBT0Usd0JBQUMsS0FBRCxFQUFHLFdBQVUsa0NBQW1DOzs7O2lCQUNoRCx3QkFBQyxRQUFELFlBQU0sV0FBYzs7OztlQUNuQjs7Ozs7O01BRUgsd0JBQUMsS0FBRDtPQUNFLE1BQUs7T0FDTCxRQUFPO09BQ1AsS0FBSTtPQUNKLGVBQWUsbUJBQW1CLEtBQUs7T0FDdkMsV0FBVTtpQkFMWixDQU9FLHdCQUFDLEtBQUQsRUFBRyxXQUFVLDhCQUErQjs7OztpQkFDNUMsd0JBQUMsUUFBRCxZQUFNLFNBQVk7Ozs7ZUFDakI7Ozs7OztNQUVILHdCQUFDLEtBQUQ7T0FDRSxNQUFLO09BQ0wsUUFBTztPQUNQLEtBQUk7T0FDSixlQUFlLG1CQUFtQixLQUFLO09BQ3ZDLFdBQVU7aUJBTFosQ0FPRSx3QkFBQyxLQUFELEVBQUcsV0FBVSxpQ0FBa0M7Ozs7aUJBQy9DLHdCQUFDLFFBQUQsWUFBTSxZQUFlOzs7O2VBQ3BCOzs7Ozs7S0FDQTs7Ozs7WUFDSzs7Ozs7WUFFQzs7Ozs7RUFFZDs7Ozs7O0FBRVQiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiQXBwLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyIvKipcbiAqIEBsaWNlbnNlXG4gKiBTUERYLUxpY2Vuc2UtSWRlbnRpZmllcjogQXBhY2hlLTIuMFxuICovXG5cbmltcG9ydCBSZWFjdCwgeyB1c2VTdGF0ZSwgdXNlRWZmZWN0LCB1c2VSZWYgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyBtb3Rpb24sIEFuaW1hdGVQcmVzZW5jZSB9IGZyb20gJ21vdGlvbi9yZWFjdCc7XG5pbXBvcnQge1xuICBTcGFya2xlcyxcbiAgUGhvbmUsXG4gIFBob25lQ2FsbCxcbiAgTWVzc2FnZVNxdWFyZSxcbiAgQ29weSxcbiAgQ2hlY2ssXG4gIFNoYXJlMixcbiAgQ2FtZXJhLFxuICBSb3RhdGVDY3csXG4gIFgsXG4gIEV4dGVybmFsTGluayxcbiAgVmlkZW8sXG4gIEltYWdlIGFzIEltYWdlSWNvbixcbiAgUGFsZXR0ZSxcbiAgUXJDb2RlLFxuICBDaGVja0NpcmNsZTIsXG4gIEFsZXJ0Q2lyY2xlLFxuICBDaGV2cm9uUmlnaHQsXG4gIE1vb24sXG4gIFphcCxcbiAgWmFwT2ZmLFxuICBVc2VyLFxuICBUcmFzaDIsXG4gIFVwbG9hZENsb3VkLFxuICBEb3dubG9hZCxcbiAgRmlsZUFyY2hpdmUsXG4gIEZpbGVDb2RlLFxuICBDb250YWN0LFxuICBMb2FkZXIyXG59IGZyb20gJ2x1Y2lkZS1yZWFjdCc7XG5pbXBvcnQge1xuICBkb3dubG9hZFByb2plY3RaaXAsXG4gIGRvd25sb2FkU3RhbmRhbG9uZUh0bWwsXG4gIGRvd25sb2FkVkNhcmRcbn0gZnJvbSAnLi91dGlscy9kb3dubG9hZGVyLnRzJztcblxuaW50ZXJmYWNlIENvdmVyQ29uZmlnIHtcbiAgdHlwZTogJ2dyYWRpZW50JyB8ICdpbWFnZScgfCAndmlkZW8nO1xuICB2YWx1ZTogc3RyaW5nO1xufVxuXG5pbnRlcmZhY2UgVG9hc3RJbmZvIHtcbiAgbWVzc2FnZTogc3RyaW5nO1xuICB0eXBlOiAnc3VjY2VzcycgfCAnZXJyb3InIHwgJ2luZm8nO1xufVxuXG5jb25zdCBQUkVTRVRfR1JBRElFTlRTID0gW1xuICB7IGlkOiAnY292ZXItZ3JhZGllbnQtMScsIG5hbWU6ICdDeWJlciBJbmRpZ28nLCBjbGFzczogJ2NvdmVyLWdyYWRpZW50LTEnIH0sXG4gIHsgaWQ6ICdjb3Zlci1ncmFkaWVudC0yJywgbmFtZTogJ0VtZXJhbGQgT2NlYW4nLCBjbGFzczogJ2NvdmVyLWdyYWRpZW50LTInIH0sXG4gIHsgaWQ6ICdjb3Zlci1ncmFkaWVudC0zJywgbmFtZTogJ1N1bnNldCBHbG93JywgY2xhc3M6ICdjb3Zlci1ncmFkaWVudC0zJyB9LFxuICB7IGlkOiAnY292ZXItZ3JhZGllbnQtNCcsIG5hbWU6ICdEYXJrIE1pbmltYWwnLCBjbGFzczogJ2NvdmVyLWdyYWRpZW50LTQnIH0sXG4gIHsgaWQ6ICdjb3Zlci1ncmFkaWVudC01JywgbmFtZTogJ0VsZWN0cmljIFB1cnBsZScsIGNsYXNzOiAnY292ZXItZ3JhZGllbnQtNScgfSxcbiAgeyBpZDogJ2NvdmVyLWdyYWRpZW50LTYnLCBuYW1lOiAnRm9yZXN0IEVtZXJhbGQnLCBjbGFzczogJ2NvdmVyLWdyYWRpZW50LTYnIH0sXG5dO1xuXG4vLyBQcmVzZXQgQXZhdGFycyBmb3IgcXVpY2sgc2VsZWN0aW9uXG5jb25zdCBQUkVTRVRfQVZBVEFSUyA9IFtcbiAge1xuICAgIG5hbWU6ICdDeWJlciBOZW9uJyxcbiAgICB1cmw6ICdodHRwczovL2ltYWdlcy51bnNwbGFzaC5jb20vcGhvdG8tMTUzNDUyODc0MTc3NS01Mzk5NGE2OWRhZWI/dz00MDAmYXV0bz1mb3JtYXQmZml0PWNyb3AmcT04MCcsXG4gIH0sXG4gIHtcbiAgICBuYW1lOiAnTW9kZXJuIFBvcnRyYWl0JyxcbiAgICB1cmw6ICdodHRwczovL2ltYWdlcy51bnNwbGFzaC5jb20vcGhvdG8tMTUwNzAwMzIxMTE2OS0wYTFkZDcyMjhmMmQ/dz00MDAmYXV0bz1mb3JtYXQmZml0PWNyb3AmcT04MCcsXG4gIH0sXG4gIHtcbiAgICBuYW1lOiAnQWVzdGhldGljIE1pbmltYWwnLFxuICAgIHVybDogJ2h0dHBzOi8vaW1hZ2VzLnVuc3BsYXNoLmNvbS9waG90by0xNTAwNjQ4NzY3NzkxLTAwZGNjOTk0YTQzZT93PTQwMCZhdXRvPWZvcm1hdCZmaXQ9Y3JvcCZxPTgwJyxcbiAgfSxcbiAge1xuICAgIG5hbWU6ICdDcmVhdGl2ZSBVcmJhbicsXG4gICAgdXJsOiAnaHR0cHM6Ly9pbWFnZXMudW5zcGxhc2guY29tL3Bob3RvLTE0OTI1NjIwODAwMjMtYWIzZGI5NWJmYmNlP3c9NDAwJmF1dG89Zm9ybWF0JmZpdD1jcm9wJnE9ODAnLFxuICB9LFxuXTtcblxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gQXBwKCkge1xuICAvLyBHbG93IENvbG9ycyBTdGF0ZSAtIHBlcnNpc3RlZCBpbiBsb2NhbFN0b3JhZ2VcbiAgY29uc3QgW2dsb3dFbmFibGVkLCBzZXRHbG93RW5hYmxlZF0gPSB1c2VTdGF0ZTxib29sZWFuPigoKSA9PiB7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHNhdmVkID0gbG9jYWxTdG9yYWdlLmdldEl0ZW0oJ2FsYmVydF9yb2JsZWRvX2dsb3dfZW5hYmxlZCcpO1xuICAgICAgcmV0dXJuIHNhdmVkICE9PSBudWxsID8gSlNPTi5wYXJzZShzYXZlZCkgOiB0cnVlO1xuICAgIH0gY2F0Y2gge1xuICAgICAgcmV0dXJuIHRydWU7XG4gICAgfVxuICB9KTtcblxuICAvLyBQcm9maWxlIFBpY3R1cmUgKEF2YXRhcikgU3RhdGUgLSBwZXJzaXN0ZWQgaW4gbG9jYWxTdG9yYWdlXG4gIGNvbnN0IFthdmF0YXJVcmwsIHNldEF2YXRhclVybF0gPSB1c2VTdGF0ZTxzdHJpbmcgfCBudWxsPigoKSA9PiB7XG4gICAgdHJ5IHtcbiAgICAgIHJldHVybiBsb2NhbFN0b3JhZ2UuZ2V0SXRlbSgnYWxiZXJ0X3JvYmxlZG9fYXZhdGFyX3YxJykgfHwgbnVsbDtcbiAgICB9IGNhdGNoIHtcbiAgICAgIHJldHVybiBudWxsO1xuICAgIH1cbiAgfSk7XG5cbiAgLy8gQ292ZXIgQmFubmVyIENvbmZpZ3VyYXRpb24gLSBwZXJzaXN0ZWQgaW4gbG9jYWxTdG9yYWdlXG4gIGNvbnN0IFtjb3ZlckNvbmZpZywgc2V0Q292ZXJDb25maWddID0gdXNlU3RhdGU8Q292ZXJDb25maWc+KCgpID0+IHtcbiAgICB0cnkge1xuICAgICAgY29uc3Qgc2F2ZWQgPSBsb2NhbFN0b3JhZ2UuZ2V0SXRlbSgnYWxiZXJ0X3JvYmxlZG9fY292ZXJfdjInKTtcbiAgICAgIGlmIChzYXZlZCkgcmV0dXJuIEpTT04ucGFyc2Uoc2F2ZWQpO1xuICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgIGNvbnNvbGUud2FybignQ291bGQgbm90IHBhcnNlIHNhdmVkIGNvdmVyIGNvbmZpZycsIGUpO1xuICAgIH1cbiAgICByZXR1cm4geyB0eXBlOiAnZ3JhZGllbnQnLCB2YWx1ZTogJ2NvdmVyLWdyYWRpZW50LTEnIH07XG4gIH0pO1xuXG4gIC8vIE1vZGFscyAmIElucHV0c1xuICBjb25zdCBbaXNDb3Zlck1vZGFsT3Blbiwgc2V0SXNDb3Zlck1vZGFsT3Blbl0gPSB1c2VTdGF0ZShmYWxzZSk7XG4gIGNvbnN0IFtpc0F2YXRhck1vZGFsT3Blbiwgc2V0SXNBdmF0YXJNb2RhbE9wZW5dID0gdXNlU3RhdGUoZmFsc2UpO1xuICBjb25zdCBbaXNRck1vZGFsT3Blbiwgc2V0SXNRck1vZGFsT3Blbl0gPSB1c2VTdGF0ZShmYWxzZSk7XG4gIGNvbnN0IFtpc0Rvd25sb2FkTW9kYWxPcGVuLCBzZXRJc0Rvd25sb2FkTW9kYWxPcGVuXSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgY29uc3QgW2lzRG93bmxvYWRpbmcsIHNldElzRG93bmxvYWRpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xuXG4gIGNvbnN0IFtpbWFnZVVybElucHV0LCBzZXRJbWFnZVVybElucHV0XSA9IHVzZVN0YXRlKCcnKTtcbiAgY29uc3QgW3ZpZGVvVXJsSW5wdXQsIHNldFZpZGVvVXJsSW5wdXRdID0gdXNlU3RhdGUoJycpO1xuICBjb25zdCBbYXZhdGFyVXJsSW5wdXQsIHNldEF2YXRhclVybElucHV0XSA9IHVzZVN0YXRlKCcnKTtcbiAgY29uc3QgW2NvcGllZE51bWJlciwgc2V0Q29waWVkTnVtYmVyXSA9IHVzZVN0YXRlKGZhbHNlKTtcblxuICAvLyBGb2xsb3cgbWUgb24gc29jaWFsIG5vdGlmaWNhdGlvbiB0b2FzdCAoYXBwZWFycyA1cyBhZnRlciBwYWdlIGxvYWQpXG4gIGNvbnN0IFtzaG93U29jaWFsVG9hc3QsIHNldFNob3dTb2NpYWxUb2FzdF0gPSB1c2VTdGF0ZShmYWxzZSk7XG5cbiAgLy8gVG9hc3QgTm90aWZpY2F0aW9uIFN0YXRlXG4gIGNvbnN0IFt0b2FzdCwgc2V0VG9hc3RdID0gdXNlU3RhdGU8VG9hc3RJbmZvIHwgbnVsbD4obnVsbCk7XG4gIGNvbnN0IHRvYXN0VGltZXJSZWYgPSB1c2VSZWY8Tm9kZUpTLlRpbWVvdXQgfCBudWxsPihudWxsKTtcblxuICBjb25zdCB2aWRlb0VsZW1lbnRSZWYgPSB1c2VSZWY8SFRNTFZpZGVvRWxlbWVudCB8IG51bGw+KG51bGwpO1xuXG4gIC8vIFNob3cgVG9hc3QgSGVscGVyXG4gIGNvbnN0IHNob3dUb2FzdCA9IChtZXNzYWdlOiBzdHJpbmcsIHR5cGU6ICdzdWNjZXNzJyB8ICdlcnJvcicgfCAnaW5mbycgPSAnc3VjY2VzcycpID0+IHtcbiAgICBpZiAodG9hc3RUaW1lclJlZi5jdXJyZW50KSBjbGVhclRpbWVvdXQodG9hc3RUaW1lclJlZi5jdXJyZW50KTtcbiAgICBzZXRUb2FzdCh7IG1lc3NhZ2UsIHR5cGUgfSk7XG4gICAgdG9hc3RUaW1lclJlZi5jdXJyZW50ID0gc2V0VGltZW91dCgoKSA9PiB7XG4gICAgICBzZXRUb2FzdChudWxsKTtcbiAgICB9LCAyODAwKTtcbiAgfTtcblxuICAvLyBUb2dnbGUgR2xvdyBDb2xvcnMgZmVhdHVyZVxuICBjb25zdCB0b2dnbGVHbG93ID0gKCkgPT4ge1xuICAgIGNvbnN0IG5leHRTdGF0ZSA9ICFnbG93RW5hYmxlZDtcbiAgICBzZXRHbG93RW5hYmxlZChuZXh0U3RhdGUpO1xuICAgIHRyeSB7XG4gICAgICBsb2NhbFN0b3JhZ2Uuc2V0SXRlbSgnYWxiZXJ0X3JvYmxlZG9fZ2xvd19lbmFibGVkJywgSlNPTi5zdHJpbmdpZnkobmV4dFN0YXRlKSk7XG4gICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICBjb25zb2xlLndhcm4oJ0xvY2FsU3RvcmFnZSBlcnJvcicsIGVycik7XG4gICAgfVxuICAgIGlmIChuZXh0U3RhdGUpIHtcbiAgICAgIHNob3dUb2FzdCgnR2xvd2luZyBjb2xvcnMgYWN0aXZhdGVkISDinKgnLCAnc3VjY2VzcycpO1xuICAgIH0gZWxzZSB7XG4gICAgICBzaG93VG9hc3QoJ0FsbCBnbG93aW5nIGNvbG9ycyB0dXJuZWQgb2ZmIChTdGVhbHRoIG1vZGUpIPCfjJEnLCAnaW5mbycpO1xuICAgIH1cbiAgfTtcblxuICAvLyBQcm9maWxlIFBpY3R1cmUgSGVscGVyc1xuICBjb25zdCB1cGRhdGVBdmF0YXIgPSAodXJsOiBzdHJpbmcgfCBudWxsKSA9PiB7XG4gICAgc2V0QXZhdGFyVXJsKHVybCk7XG4gICAgdHJ5IHtcbiAgICAgIGlmICh1cmwpIHtcbiAgICAgICAgbG9jYWxTdG9yYWdlLnNldEl0ZW0oJ2FsYmVydF9yb2JsZWRvX2F2YXRhcl92MScsIHVybCk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBsb2NhbFN0b3JhZ2UucmVtb3ZlSXRlbSgnYWxiZXJ0X3JvYmxlZG9fYXZhdGFyX3YxJyk7XG4gICAgICB9XG4gICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICBjb25zb2xlLndhcm4oJ0xvY2FsU3RvcmFnZSBzYXZlIGZhaWxlZCBmb3IgYXZhdGFyOicsIGVycik7XG4gICAgfVxuICB9O1xuXG4gIGNvbnN0IGhhbmRsZUF2YXRhckZpbGVVcGxvYWQgPSAoZTogUmVhY3QuQ2hhbmdlRXZlbnQ8SFRNTElucHV0RWxlbWVudD4pID0+IHtcbiAgICBjb25zdCBmaWxlID0gZS50YXJnZXQuZmlsZXM/LlswXTtcbiAgICBpZiAoIWZpbGUpIHJldHVybjtcblxuICAgIGlmICghZmlsZS50eXBlLnN0YXJ0c1dpdGgoJ2ltYWdlLycpKSB7XG4gICAgICBzaG93VG9hc3QoJ1BsZWFzZSBzZWxlY3QgYSB2YWxpZCBpbWFnZSBmaWxlJywgJ2Vycm9yJyk7XG4gICAgICByZXR1cm47XG4gICAgfVxuXG4gICAgY29uc3QgcmVhZGVyID0gbmV3IEZpbGVSZWFkZXIoKTtcbiAgICByZWFkZXIub25sb2FkID0gKGV2ZW50KSA9PiB7XG4gICAgICBjb25zdCByZXN1bHQgPSBldmVudC50YXJnZXQ/LnJlc3VsdCBhcyBzdHJpbmc7XG4gICAgICBpZiAocmVzdWx0KSB7XG4gICAgICAgIHVwZGF0ZUF2YXRhcihyZXN1bHQpO1xuICAgICAgICBzaG93VG9hc3QoJ1Byb2ZpbGUgcGljdHVyZSB1cGRhdGVkIScpO1xuICAgICAgICBzZXRJc0F2YXRhck1vZGFsT3BlbihmYWxzZSk7XG4gICAgICB9XG4gICAgfTtcbiAgICByZWFkZXIucmVhZEFzRGF0YVVSTChmaWxlKTtcbiAgfTtcblxuICBjb25zdCBoYW5kbGVBcHBseUF2YXRhclVybCA9IChlPzogUmVhY3QuRm9ybUV2ZW50KSA9PiB7XG4gICAgaWYgKGUpIGUucHJldmVudERlZmF1bHQoKTtcbiAgICBjb25zdCB1cmwgPSBhdmF0YXJVcmxJbnB1dC50cmltKCk7XG4gICAgaWYgKCF1cmwpIHtcbiAgICAgIHNob3dUb2FzdCgnUGxlYXNlIGVudGVyIGFuIGltYWdlIFVSTCcsICdlcnJvcicpO1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICB1cGRhdGVBdmF0YXIodXJsKTtcbiAgICBzZXRBdmF0YXJVcmxJbnB1dCgnJyk7XG4gICAgc2hvd1RvYXN0KCdQcm9maWxlIHBpY3R1cmUgdXBkYXRlZCBmcm9tIFVSTCEnKTtcbiAgICBzZXRJc0F2YXRhck1vZGFsT3BlbihmYWxzZSk7XG4gIH07XG5cbiAgY29uc3QgaGFuZGxlUmVzZXRBdmF0YXIgPSAoKSA9PiB7XG4gICAgdXBkYXRlQXZhdGFyKG51bGwpO1xuICAgIHNob3dUb2FzdCgnUHJvZmlsZSBwaWN0dXJlIHJlc2V0IHRvIGRlZmF1bHQgKEFSIEluaXRpYWxzKScpO1xuICAgIHNldElzQXZhdGFyTW9kYWxPcGVuKGZhbHNlKTtcbiAgfTtcblxuICAvLyBTYXZlIENvdmVyIENvbmZpZyBIZWxwZXJcbiAgY29uc3QgdXBkYXRlQ292ZXJDb25maWcgPSAoY29uZmlnOiBDb3ZlckNvbmZpZykgPT4ge1xuICAgIHNldENvdmVyQ29uZmlnKGNvbmZpZyk7XG4gICAgdHJ5IHtcbiAgICAgIGxvY2FsU3RvcmFnZS5zZXRJdGVtKCdhbGJlcnRfcm9ibGVkb19jb3Zlcl92MicsIEpTT04uc3RyaW5naWZ5KGNvbmZpZykpO1xuICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgY29uc29sZS53YXJuKCdMb2NhbFN0b3JhZ2Ugd3JpdGUgZmFpbGVkOicsIGVycik7XG4gICAgfVxuICB9O1xuXG4gIC8vIEhhbmRsZSBQcmVzZXQgVGhlbWUgQ2xpY2tcbiAgY29uc3QgaGFuZGxlU2VsZWN0UHJlc2V0ID0gKGdyYWRpZW50Q2xhc3M6IHN0cmluZykgPT4ge1xuICAgIHVwZGF0ZUNvdmVyQ29uZmlnKHsgdHlwZTogJ2dyYWRpZW50JywgdmFsdWU6IGdyYWRpZW50Q2xhc3MgfSk7XG4gICAgc2hvd1RvYXN0KCdUaGVtZSBwcmVzZXQgYXBwbGllZCEnKTtcbiAgICBzZXRJc0NvdmVyTW9kYWxPcGVuKGZhbHNlKTtcbiAgfTtcblxuICAvLyBIYW5kbGUgSW1hZ2UgVVJMXG4gIGNvbnN0IGhhbmRsZUFwcGx5SW1hZ2VVcmwgPSAoZT86IFJlYWN0LkZvcm1FdmVudCkgPT4ge1xuICAgIGlmIChlKSBlLnByZXZlbnREZWZhdWx0KCk7XG4gICAgY29uc3QgdXJsID0gaW1hZ2VVcmxJbnB1dC50cmltKCk7XG4gICAgaWYgKCF1cmwpIHtcbiAgICAgIHNob3dUb2FzdCgnUGxlYXNlIGVudGVyIGFuIGltYWdlIFVSTCcsICdlcnJvcicpO1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICB1cGRhdGVDb3ZlckNvbmZpZyh7IHR5cGU6ICdpbWFnZScsIHZhbHVlOiB1cmwgfSk7XG4gICAgc2V0SW1hZ2VVcmxJbnB1dCgnJyk7XG4gICAgc2hvd1RvYXN0KCdDb3ZlciBwaG90byB1cGRhdGVkIGZyb20gVVJMIScpO1xuICAgIHNldElzQ292ZXJNb2RhbE9wZW4oZmFsc2UpO1xuICB9O1xuXG4gIC8vIEhhbmRsZSBWaWRlbyBVUkxcbiAgY29uc3QgaGFuZGxlQXBwbHlWaWRlb1VybCA9IChlPzogUmVhY3QuRm9ybUV2ZW50KSA9PiB7XG4gICAgaWYgKGUpIGUucHJldmVudERlZmF1bHQoKTtcbiAgICBjb25zdCB1cmwgPSB2aWRlb1VybElucHV0LnRyaW0oKTtcbiAgICBpZiAoIXVybCkge1xuICAgICAgc2hvd1RvYXN0KCdQbGVhc2UgZW50ZXIgYSB2aWRlbyBVUkwnLCAnZXJyb3InKTtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgdXBkYXRlQ292ZXJDb25maWcoeyB0eXBlOiAndmlkZW8nLCB2YWx1ZTogdXJsIH0pO1xuICAgIHNldFZpZGVvVXJsSW5wdXQoJycpO1xuICAgIHNob3dUb2FzdCgnQ292ZXIgdmlkZW8gdXBkYXRlZCBmcm9tIFVSTCEnKTtcbiAgICBzZXRJc0NvdmVyTW9kYWxPcGVuKGZhbHNlKTtcbiAgfTtcblxuICAvLyBIYW5kbGUgSW1hZ2UgRmlsZSBVcGxvYWRcbiAgY29uc3QgaGFuZGxlSW1hZ2VGaWxlVXBsb2FkID0gKGU6IFJlYWN0LkNoYW5nZUV2ZW50PEhUTUxJbnB1dEVsZW1lbnQ+KSA9PiB7XG4gICAgY29uc3QgZmlsZSA9IGUudGFyZ2V0LmZpbGVzPy5bMF07XG4gICAgaWYgKCFmaWxlKSByZXR1cm47XG5cbiAgICBpZiAoIWZpbGUudHlwZS5zdGFydHNXaXRoKCdpbWFnZS8nKSkge1xuICAgICAgc2hvd1RvYXN0KCdQbGVhc2UgdXBsb2FkIGEgdmFsaWQgaW1hZ2UgZmlsZScsICdlcnJvcicpO1xuICAgICAgcmV0dXJuO1xuICAgIH1cblxuICAgIGNvbnN0IHJlYWRlciA9IG5ldyBGaWxlUmVhZGVyKCk7XG4gICAgcmVhZGVyLm9ubG9hZCA9IChldmVudCkgPT4ge1xuICAgICAgY29uc3QgcmVzdWx0ID0gZXZlbnQudGFyZ2V0Py5yZXN1bHQgYXMgc3RyaW5nO1xuICAgICAgaWYgKHJlc3VsdCkge1xuICAgICAgICB1cGRhdGVDb3ZlckNvbmZpZyh7IHR5cGU6ICdpbWFnZScsIHZhbHVlOiByZXN1bHQgfSk7XG4gICAgICAgIHNob3dUb2FzdCgnQ292ZXIgcGhvdG8gdXBkYXRlZCBmcm9tIGZpbGUhJyk7XG4gICAgICAgIHNldElzQ292ZXJNb2RhbE9wZW4oZmFsc2UpO1xuICAgICAgfVxuICAgIH07XG4gICAgcmVhZGVyLnJlYWRBc0RhdGFVUkwoZmlsZSk7XG4gIH07XG5cbiAgLy8gSGFuZGxlIFZpZGVvIEZpbGUgVXBsb2FkXG4gIGNvbnN0IGhhbmRsZVZpZGVvRmlsZVVwbG9hZCA9IChlOiBSZWFjdC5DaGFuZ2VFdmVudDxIVE1MSW5wdXRFbGVtZW50PikgPT4ge1xuICAgIGNvbnN0IGZpbGUgPSBlLnRhcmdldC5maWxlcz8uWzBdO1xuICAgIGlmICghZmlsZSkgcmV0dXJuO1xuXG4gICAgaWYgKCFmaWxlLnR5cGUuc3RhcnRzV2l0aCgndmlkZW8vJykpIHtcbiAgICAgIHNob3dUb2FzdCgnUGxlYXNlIHNlbGVjdCBhIHZhbGlkIHZpZGVvIGZpbGUgKE1QNCwgV0VCTSknLCAnZXJyb3InKTtcbiAgICAgIHJldHVybjtcbiAgICB9XG5cbiAgICBjb25zdCB2aWRlb1VybCA9IFVSTC5jcmVhdGVPYmplY3RVUkwoZmlsZSk7XG4gICAgdXBkYXRlQ292ZXJDb25maWcoeyB0eXBlOiAndmlkZW8nLCB2YWx1ZTogdmlkZW9VcmwgfSk7XG4gICAgc2hvd1RvYXN0KCdDb3ZlciB2aWRlbyBsb2FkZWQgZnJvbSBmaWxlIScpO1xuICAgIHNldElzQ292ZXJNb2RhbE9wZW4oZmFsc2UpO1xuICB9O1xuXG4gIC8vIFJlc2V0IERlZmF1bHQgQ292ZXJcbiAgY29uc3QgaGFuZGxlUmVzZXRDb3ZlciA9ICgpID0+IHtcbiAgICBjb25zdCBkZWZhdWx0Q29uZmlnOiBDb3ZlckNvbmZpZyA9IHsgdHlwZTogJ2dyYWRpZW50JywgdmFsdWU6ICdjb3Zlci1ncmFkaWVudC0xJyB9O1xuICAgIHVwZGF0ZUNvdmVyQ29uZmlnKGRlZmF1bHRDb25maWcpO1xuICAgIHNob3dUb2FzdCgnUmVzZXQgdG8gZGVmYXVsdCBjb3ZlciBiYW5uZXInKTtcbiAgICBzZXRJc0NvdmVyTW9kYWxPcGVuKGZhbHNlKTtcbiAgfTtcblxuICAvLyBDb3B5IFBob25lIE51bWJlclxuICBjb25zdCBoYW5kbGVDb3B5UGhvbmVOdW1iZXIgPSAobnVtYmVyOiBzdHJpbmcpID0+IHtcbiAgICBuYXZpZ2F0b3IuY2xpcGJvYXJkLndyaXRlVGV4dChudW1iZXIpLnRoZW4oKCkgPT4ge1xuICAgICAgc2V0Q29waWVkTnVtYmVyKHRydWUpO1xuICAgICAgc2hvd1RvYXN0KCdQaG9uZSBudW1iZXIgMDk2NiAwMjQgODIyMSBjb3BpZWQhJyk7XG4gICAgICBzZXRUaW1lb3V0KCgpID0+IHNldENvcGllZE51bWJlcihmYWxzZSksIDIwMDApO1xuICAgIH0pLmNhdGNoKCgpID0+IHtcbiAgICAgIHNob3dUb2FzdCgnRmFpbGVkIHRvIGNvcHkgbnVtYmVyJywgJ2Vycm9yJyk7XG4gICAgfSk7XG4gIH07XG5cbiAgLy8gU2hhcmUgUHJvZmlsZVxuICBjb25zdCBoYW5kbGVTaGFyZVByb2ZpbGUgPSAoKSA9PiB7XG4gICAgaWYgKG5hdmlnYXRvci5zaGFyZSkge1xuICAgICAgbmF2aWdhdG9yLnNoYXJlKHtcbiAgICAgICAgdGl0bGU6ICdBbGJlcnQgUm9ibGVkbyB8IFBlcnNvbmFsIFByb2ZpbGUnLFxuICAgICAgICB0ZXh0OiAnQ29ubmVjdCB3aXRoIEFsYmVydCBSb2JsZWRvIG9uIHNvY2lhbCBtZWRpYSBvciBkaXJlY3QgY29udGFjdCEnLFxuICAgICAgICB1cmw6IHdpbmRvdy5sb2NhdGlvbi5ocmVmLFxuICAgICAgfSkuY2F0Y2goKCkgPT4ge30pO1xuICAgIH0gZWxzZSB7XG4gICAgICBuYXZpZ2F0b3IuY2xpcGJvYXJkLndyaXRlVGV4dCh3aW5kb3cubG9jYXRpb24uaHJlZik7XG4gICAgICBzaG93VG9hc3QoJ1Byb2ZpbGUgbGluayBjb3BpZWQgdG8gY2xpcGJvYXJkIScpO1xuICAgIH1cbiAgfTtcblxuICAvLyBEb3dubG9hZCBIYW5kbGVyc1xuICBjb25zdCBoYW5kbGVEb3dubG9hZFppcCA9IGFzeW5jICgpID0+IHtcbiAgICBzZXRJc0Rvd25sb2FkaW5nKHRydWUpO1xuICAgIHNob3dUb2FzdCgnUGFja2luZyBwcm9qZWN0IGludG8gWklQIGZpbGUuLi4nLCAnaW5mbycpO1xuICAgIHRyeSB7XG4gICAgICBhd2FpdCBkb3dubG9hZFByb2plY3RaaXAoKTtcbiAgICAgIHNob3dUb2FzdCgnUHJvamVjdCBaSVAgZG93bmxvYWRlZCEg8J+TpicsICdzdWNjZXNzJyk7XG4gICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICBjb25zb2xlLmVycm9yKGVycik7XG4gICAgICBzaG93VG9hc3QoJ0ZhaWxlZCB0byBnZW5lcmF0ZSBaSVAnLCAnZXJyb3InKTtcbiAgICB9IGZpbmFsbHkge1xuICAgICAgc2V0SXNEb3dubG9hZGluZyhmYWxzZSk7XG4gICAgfVxuICB9O1xuXG4gIGNvbnN0IGhhbmRsZURvd25sb2FkSHRtbCA9ICgpID0+IHtcbiAgICBkb3dubG9hZFN0YW5kYWxvbmVIdG1sKGF2YXRhclVybCwgZ2xvd0VuYWJsZWQpO1xuICAgIHNob3dUb2FzdCgnU2luZ2xlLWZpbGUgb2ZmbGluZSBIVE1MIGRvd25sb2FkZWQhIPCfk4QnLCAnc3VjY2VzcycpO1xuICB9O1xuXG4gIGNvbnN0IGhhbmRsZURvd25sb2FkQ29udGFjdCA9ICgpID0+IHtcbiAgICBkb3dubG9hZFZDYXJkKCk7XG4gICAgc2hvd1RvYXN0KCdDb250YWN0IGNhcmQgKC52Y2YpIGRvd25sb2FkZWQhIPCfk7EnLCAnc3VjY2VzcycpO1xuICB9O1xuXG4gIC8vIE1hbmFnZSBWaWRlbyBhdXRvcGxheVxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGlmIChjb3ZlckNvbmZpZy50eXBlID09PSAndmlkZW8nICYmIHZpZGVvRWxlbWVudFJlZi5jdXJyZW50KSB7XG4gICAgICB2aWRlb0VsZW1lbnRSZWYuY3VycmVudC5zcmMgPSBjb3ZlckNvbmZpZy52YWx1ZTtcbiAgICAgIHZpZGVvRWxlbWVudFJlZi5jdXJyZW50LnBsYXkoKS5jYXRjaCgoZXJyKSA9PiB7XG4gICAgICAgIGNvbnNvbGUubG9nKCdWaWRlbyBhdXRvcGxheSBwcmV2ZW50ZWQgb3IgZm9ybWF0IGlzc3VlJywgZXJyKTtcbiAgICAgIH0pO1xuICAgIH1cbiAgfSwgW2NvdmVyQ29uZmlnXSk7XG5cbiAgLy8gU2hvdyBcIkZvbGxvdyBtZSBvbiBzb2NpYWxcIiBub3RpZmljYXRpb24gdG9hc3QgNSBzZWNvbmRzIGFmdGVyIHBhZ2UgbG9hZFxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGNvbnN0IHRpbWVyID0gc2V0VGltZW91dCgoKSA9PiB7XG4gICAgICBzZXRTaG93U29jaWFsVG9hc3QodHJ1ZSk7XG4gICAgfSwgNTAwMCk7XG5cbiAgICByZXR1cm4gKCkgPT4gY2xlYXJUaW1lb3V0KHRpbWVyKTtcbiAgfSwgW10pO1xuXG4gIGNvbnN0IGN1cnJlbnRZZWFyID0gbmV3IERhdGUoKS5nZXRGdWxsWWVhcigpO1xuXG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9e2BtaW4taC1zY3JlZW4gdGV4dC1zbGF0ZS0xMDAgZmxleCBmbGV4LWNvbCBqdXN0aWZ5LWJldHdlZW4gaXRlbXMtY2VudGVyIHJlbGF0aXZlIG92ZXJmbG93LXgtaGlkZGVuIGZvbnQtc2FucyBzZWxlY3Rpb246YmctcHVycGxlLTUwMCBzZWxlY3Rpb246dGV4dC13aGl0ZSBwYi0xMiB0cmFuc2l0aW9uLWNvbG9ycyBkdXJhdGlvbi01MDAgYmctc2xhdGUtOTUwYH0+XG4gICAgICBcbiAgICAgIHsvKiBCYWNrZ3JvdW5kIEFtYmllbnQgR2xvd3MgJiBHcmlkIFBhdHRlcm4gKi99XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImZpeGVkIGluc2V0LTAgcG9pbnRlci1ldmVudHMtbm9uZSB6LTAgb3ZlcmZsb3ctaGlkZGVuIHNlbGVjdC1ub25lXCI+XG4gICAgICAgIHsvKiBHbG93aW5nIE9yYnMgLSBDb250cm9sbGVkIGJ5IGdsb3dFbmFibGVkICovfVxuICAgICAgICA8ZGl2XG4gICAgICAgICAgY2xhc3NOYW1lPXtgYWJzb2x1dGUgLXRvcC0zMiAtbGVmdC0zMiB3LTk2IGgtOTYgcm91bmRlZC1mdWxsIHRyYW5zaXRpb24tb3BhY2l0eSBkdXJhdGlvbi03MDAgJHtcbiAgICAgICAgICAgIGdsb3dFbmFibGVkID8gJ2JnLW9yYi0xIGFuaW1hdGUtZmxvYXQtc2xvdyBvcGFjaXR5LTEwMCcgOiAnb3BhY2l0eS0wJ1xuICAgICAgICAgIH1gfVxuICAgICAgICAvPlxuICAgICAgICA8ZGl2XG4gICAgICAgICAgY2xhc3NOYW1lPXtgYWJzb2x1dGUgdG9wLTEvMiAtcmlnaHQtMzIgdy05NiBoLTk2IHJvdW5kZWQtZnVsbCB0cmFuc2l0aW9uLW9wYWNpdHkgZHVyYXRpb24tNzAwICR7XG4gICAgICAgICAgICBnbG93RW5hYmxlZCA/ICdiZy1vcmItMiBhbmltYXRlLWZsb2F0LXNsb3cgb3BhY2l0eS0xMDAnIDogJ29wYWNpdHktMCdcbiAgICAgICAgICB9YH1cbiAgICAgICAgICBzdHlsZT17eyBhbmltYXRpb25EZWxheTogJy0yLjVzJyB9fVxuICAgICAgICAvPlxuICAgICAgICA8ZGl2XG4gICAgICAgICAgY2xhc3NOYW1lPXtgYWJzb2x1dGUgLWJvdHRvbS0zMiBsZWZ0LTEvMyB3LTk2IGgtOTYgcm91bmRlZC1mdWxsIHRyYW5zaXRpb24tb3BhY2l0eSBkdXJhdGlvbi03MDAgJHtcbiAgICAgICAgICAgIGdsb3dFbmFibGVkID8gJ2JnLW9yYi0zIGFuaW1hdGUtZmxvYXQtc2xvdyBvcGFjaXR5LTEwMCcgOiAnb3BhY2l0eS0wJ1xuICAgICAgICAgIH1gfVxuICAgICAgICAgIHN0eWxlPXt7IGFuaW1hdGlvbkRlbGF5OiAnLTQuNXMnIH19XG4gICAgICAgIC8+XG5cbiAgICAgICAgey8qIFN1YnRsZSBnZW9tZXRyaWMgZG90IGdyaWQgcGF0dGVybiAqL31cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhYnNvbHV0ZSBpbnNldC0wIGJnLVtyYWRpYWwtZ3JhZGllbnQoIzMzNDE1NV8xcHgsdHJhbnNwYXJlbnRfMXB4KV0gW2JhY2tncm91bmQtc2l6ZToyNHB4XzI0cHhdIG9wYWNpdHktMjBcIiAvPlxuICAgICAgPC9kaXY+XG5cbiAgICAgIHsvKiBUb3AgRmxvYXRpbmcgQ29udHJvbCBCYXIgKi99XG4gICAgICA8aGVhZGVyIGNsYXNzTmFtZT1cInctZnVsbCBtYXgtdy1sZyBweC00IHB0LTQgc206cHQtNiB6LTIwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBnYXAtMlwiPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XG4gICAgICAgICAgey8qIE1haW4gVXNlciBSZXF1ZXN0ZWQgRmVhdHVyZTogVHVybiBPZmYgLyBPbiBBbGwgR2xvd2luZyBDb2xvcnMgKi99XG4gICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgb25DbGljaz17dG9nZ2xlR2xvd31cbiAgICAgICAgICAgIGFyaWEtbGFiZWw9e2dsb3dFbmFibGVkID8gJ1R1cm4gb2ZmIGdsb3dpbmcgY29sb3JzJyA6ICdUdXJuIG9uIGdsb3dpbmcgY29sb3JzJ31cbiAgICAgICAgICAgIGNsYXNzTmFtZT17YGdyb3VwIHJlbGF0aXZlIGZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHB4LTMuNSBweS0xLjUgcm91bmRlZC1mdWxsIHRleHQteHMgZm9udC1zZW1pYm9sZCBiYWNrZHJvcC1ibHVyLXhsIGJvcmRlciB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0zMDAgc2hhZG93LWxnIGN1cnNvci1wb2ludGVyIGFjdGl2ZTpzY2FsZS05NSAke1xuICAgICAgICAgICAgICBnbG93RW5hYmxlZFxuICAgICAgICAgICAgICAgID8gJ2JnLXB1cnBsZS05NTAvNzAgYm9yZGVyLXB1cnBsZS01MDAvNDAgdGV4dC1wdXJwbGUtMjAwIHNoYWRvdy1wdXJwbGUtOTAwLzQwIGhvdmVyOmJnLXB1cnBsZS05MDAvODAgaG92ZXI6Ym9yZGVyLXB1cnBsZS00MDAnXG4gICAgICAgICAgICAgICAgOiAnYmctc2xhdGUtOTAwLzgwIGJvcmRlci1zbGF0ZS03MDAvNjAgdGV4dC1zbGF0ZS00MDAgaG92ZXI6dGV4dC1zbGF0ZS0yMDAgaG92ZXI6Ymctc2xhdGUtODAwJ1xuICAgICAgICAgICAgfWB9XG4gICAgICAgICAgICB0aXRsZT17Z2xvd0VuYWJsZWQgPyAnQ2xpY2sgdG8gdHVybiBvZmYgYWxsIGdsb3dpbmcgY29sb3JzJyA6ICdDbGljayB0byB0dXJuIG9uIGFsbCBnbG93aW5nIGNvbG9ycyd9XG4gICAgICAgICAgPlxuICAgICAgICAgICAge2dsb3dFbmFibGVkID8gKFxuICAgICAgICAgICAgICA8PlxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInJlbGF0aXZlIGZsZXggaC0yIHctMlwiPlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiYW5pbWF0ZS1waW5nIGFic29sdXRlIGlubGluZS1mbGV4IGgtZnVsbCB3LWZ1bGwgcm91bmRlZC1mdWxsIGJnLXB1cnBsZS00MDAgb3BhY2l0eS03NVwiPjwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInJlbGF0aXZlIGlubGluZS1mbGV4IHJvdW5kZWQtZnVsbCBoLTIgdy0yIGJnLXB1cnBsZS01MDBcIj48L3NwYW4+XG4gICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgIDxTcGFya2xlcyBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNSB0ZXh0LXB1cnBsZS0zMDAgZ3JvdXAtaG92ZXI6cm90YXRlLTEyIHRyYW5zaXRpb24tdHJhbnNmb3JtXCIgLz5cbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0cmFja2luZy13aWRlXCI+R2xvdzogPHN0cm9uZyBjbGFzc05hbWU9XCJ0ZXh0LXdoaXRlXCI+T048L3N0cm9uZz48L3NwYW4+XG4gICAgICAgICAgICAgIDwvPlxuICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgPD5cbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCByb3VuZGVkLWZ1bGwgaC0yIHctMiBiZy1zbGF0ZS02MDBcIj48L3NwYW4+XG4gICAgICAgICAgICAgICAgPE1vb24gY2xhc3NOYW1lPVwidy0zLjUgaC0zLjUgdGV4dC1zbGF0ZS00MDBcIiAvPlxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRyYWNraW5nLXdpZGVcIj5HbG93OiA8c3Ryb25nIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNDAwXCI+T0ZGPC9zdHJvbmc+PC9zcGFuPlxuICAgICAgICAgICAgICA8Lz5cbiAgICAgICAgICAgICl9XG4gICAgICAgICAgPC9idXR0b24+XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIHsvKiBRdWljayBBY3Rpb25zIGluIHRvcCBiYXIgKi99XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRJc0Rvd25sb2FkTW9kYWxPcGVuKHRydWUpfVxuICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtMi41IHB5LTEuNSByb3VuZGVkLWZ1bGwgYmctZW1lcmFsZC05NTAvNjAgaG92ZXI6YmctZW1lcmFsZC05MDAvODAgYm9yZGVyIGJvcmRlci1lbWVyYWxkLTUwMC80MCB0ZXh0LWVtZXJhbGQtMzAwIGhvdmVyOnRleHQtd2hpdGUgdHJhbnNpdGlvbi1hbGwgYmFja2Ryb3AtYmx1ci1tZCBzaGFkb3ctbWQgYWN0aXZlOnNjYWxlLTk1IGN1cnNvci1wb2ludGVyIGZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgdGV4dC14cyBmb250LXNlbWlib2xkXCJcbiAgICAgICAgICAgIHRpdGxlPVwiRG93bmxvYWQgUHJvamVjdCBGaWxlcyAoWklQLCBIVE1MLCBWQ0YpXCJcbiAgICAgICAgICAgIGFyaWEtbGFiZWw9XCJEb3dubG9hZCBQcm9qZWN0XCJcbiAgICAgICAgICA+XG4gICAgICAgICAgICA8RG93bmxvYWQgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjUgdGV4dC1lbWVyYWxkLTQwMFwiIC8+XG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJoaWRkZW4gc206aW5saW5lXCI+RG93bmxvYWQ8L3NwYW4+XG4gICAgICAgICAgPC9idXR0b24+XG5cbiAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRJc1FyTW9kYWxPcGVuKHRydWUpfVxuICAgICAgICAgICAgY2xhc3NOYW1lPVwicC0yIHJvdW5kZWQtZnVsbCBiZy1zbGF0ZS05MDAvODAgaG92ZXI6Ymctc2xhdGUtODAwIGJvcmRlciBib3JkZXItc2xhdGUtNzAwLzYwIHRleHQtc2xhdGUtMzAwIGhvdmVyOnRleHQtd2hpdGUgdHJhbnNpdGlvbi1hbGwgYmFja2Ryb3AtYmx1ci1tZCBzaGFkb3ctbWQgYWN0aXZlOnNjYWxlLTk1IGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgIHRpdGxlPVwiU2hvdyBQcm9maWxlIFFSIENvZGVcIlxuICAgICAgICAgICAgYXJpYS1sYWJlbD1cIlFSIENvZGVcIlxuICAgICAgICAgID5cbiAgICAgICAgICAgIDxRckNvZGUgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjVcIiAvPlxuICAgICAgICAgIDwvYnV0dG9uPlxuXG4gICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgb25DbGljaz17aGFuZGxlU2hhcmVQcm9maWxlfVxuICAgICAgICAgICAgY2xhc3NOYW1lPVwicC0yIHJvdW5kZWQtZnVsbCBiZy1zbGF0ZS05MDAvODAgaG92ZXI6Ymctc2xhdGUtODAwIGJvcmRlciBib3JkZXItc2xhdGUtNzAwLzYwIHRleHQtc2xhdGUtMzAwIGhvdmVyOnRleHQtd2hpdGUgdHJhbnNpdGlvbi1hbGwgYmFja2Ryb3AtYmx1ci1tZCBzaGFkb3ctbWQgYWN0aXZlOnNjYWxlLTk1IGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgIHRpdGxlPVwiU2hhcmUgUHJvZmlsZVwiXG4gICAgICAgICAgICBhcmlhLWxhYmVsPVwiU2hhcmVcIlxuICAgICAgICAgID5cbiAgICAgICAgICAgIDxTaGFyZTIgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjUgdGV4dC1ibHVlLTQwMFwiIC8+XG4gICAgICAgICAgPC9idXR0b24+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9oZWFkZXI+XG5cbiAgICAgIHsvKiBNYWluIFByb2ZpbGUgQ2FyZCBDb250YWluZXIgKi99XG4gICAgICA8bWFpbiBjbGFzc05hbWU9XCJ3LWZ1bGwgbWF4LXctbGcgcHgtNCBzbTpweC02IHB0LTMgei0xMCBmbGV4IGZsZXgtY29sIGl0ZW1zLWNlbnRlclwiPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT17YHctZnVsbCBnbGFzcy1jYXJkIHJvdW5kZWQtM3hsIG92ZXJmbG93LWhpZGRlbiBzaGFkb3ctMnhsIHJlbGF0aXZlIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTUwMCBib3JkZXIgJHtcbiAgICAgICAgICBnbG93RW5hYmxlZCA/ICdib3JkZXItc2xhdGUtODAwLzkwIHNoYWRvdy1zbGF0ZS05NTAvODAnIDogJ2JvcmRlci1zbGF0ZS04MDAgYmctc2xhdGUtOTUwLzkwIHNoYWRvdy1ub25lJ1xuICAgICAgICB9YH0+XG4gICAgICAgICAgXG4gICAgICAgICAgey8qIENvdmVyIFBob3RvIC8gVmlkZW8gQmFubmVyICovfVxuICAgICAgICAgIDxkaXZcbiAgICAgICAgICAgIGNsYXNzTmFtZT17YHJlbGF0aXZlIHctZnVsbCBoLTQ0IHNtOmgtNTIgYmctc2xhdGUtOTAwIGJnLWNvdmVyIGJnLWNlbnRlciB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi01MDAgb3ZlcmZsb3ctaGlkZGVuICR7XG4gICAgICAgICAgICAgIGNvdmVyQ29uZmlnLnR5cGUgPT09ICdncmFkaWVudCcgPyBjb3ZlckNvbmZpZy52YWx1ZSA6ICcnXG4gICAgICAgICAgICB9YH1cbiAgICAgICAgICAgIHN0eWxlPXt7XG4gICAgICAgICAgICAgIGJhY2tncm91bmRJbWFnZTogY292ZXJDb25maWcudHlwZSA9PT0gJ2ltYWdlJyA/IGB1cmwoXCIke2NvdmVyQ29uZmlnLnZhbHVlfVwiKWAgOiB1bmRlZmluZWQsXG4gICAgICAgICAgICB9fVxuICAgICAgICAgID5cbiAgICAgICAgICAgIHsvKiBDb3ZlciBWaWRlbyBQbGF5ZXIgKi99XG4gICAgICAgICAgICB7Y292ZXJDb25maWcudHlwZSA9PT0gJ3ZpZGVvJyAmJiAoXG4gICAgICAgICAgICAgIDx2aWRlb1xuICAgICAgICAgICAgICAgIHJlZj17dmlkZW9FbGVtZW50UmVmfVxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImFic29sdXRlIGluc2V0LTAgdy1mdWxsIGgtZnVsbCBvYmplY3QtY292ZXJcIlxuICAgICAgICAgICAgICAgIGF1dG9QbGF5XG4gICAgICAgICAgICAgICAgbXV0ZWRcbiAgICAgICAgICAgICAgICBsb29wXG4gICAgICAgICAgICAgICAgcGxheXNJbmxpbmVcbiAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICl9XG5cbiAgICAgICAgICAgIHsvKiBHcmFkaWVudCBPdmVybGF5IGZvciBUZXh0IENvbnRyYXN0ICovfVxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhYnNvbHV0ZSBpbnNldC0wIGJnLWdyYWRpZW50LXRvLWIgZnJvbS1ibGFjay8zNSB2aWEtdHJhbnNwYXJlbnQgdG8tc2xhdGUtOTUwLzk1IHBvaW50ZXItZXZlbnRzLW5vbmUgei0xMFwiIC8+XG5cbiAgICAgICAgICAgIHsvKiBFZGl0IENvdmVyIEFjdGlvbiBCdXR0b24gKi99XG4gICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldElzQ292ZXJNb2RhbE9wZW4odHJ1ZSl9XG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cImFic29sdXRlIHRvcC0zLjUgcmlnaHQtMy41IHotMjAgYmctc2xhdGUtOTAwLzgwIGhvdmVyOmJnLXNsYXRlLTkwMCB0ZXh0LXdoaXRlIHRleHQteHMgZm9udC1zZW1pYm9sZCBweC0zIHB5LTEuNSBzbTpweC0zLjUgc206cHktMiByb3VuZGVkLXhsIGJhY2tkcm9wLWJsdXItbWQgYm9yZGVyIGJvcmRlci13aGl0ZS8xNSBzaGFkb3ctbGcgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgdHJhbnNpdGlvbi1hbGwgaG92ZXI6c2NhbGUtMTA1IGFjdGl2ZTpzY2FsZS05NSBncm91cCBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgICAgIHRpdGxlPVwiQ2hhbmdlIENvdmVyIEJhbm5lciBvciBCYWNrZ3JvdW5kIFRoZW1lXCJcbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgPENhbWVyYSBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNSB0ZXh0LWJsdWUtNDAwIGdyb3VwLWhvdmVyOnJvdGF0ZS0xMiB0cmFuc2l0aW9uLXRyYW5zZm9ybVwiIC8+XG4gICAgICAgICAgICAgIDxzcGFuPkVkaXQgQ292ZXI8L3NwYW4+XG4gICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIHsvKiBQcm9maWxlIERldGFpbHMgKE92ZXJsYXBzIENvdmVyIEJhbm5lcikgKi99XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJweC01IHNtOnB4LTggcGItOCAtbXQtMTYgc206LW10LTIwIHJlbGF0aXZlIHotMTAgZmxleCBmbGV4LWNvbCBpdGVtcy1jZW50ZXIgdGV4dC1jZW50ZXJcIj5cbiAgICAgICAgICAgIFxuICAgICAgICAgICAgey8qIFByb2ZpbGUgQXZhdGFyIHdpdGggR2xvd2luZyBSaW5nIGFuZCBDYW1lcmEgQ2hhbmdlIEJ1dHRvbiAqL31cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmUgbWItNCBncm91cFwiPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT17YGdsb3ctcmluZyB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi01MDAgJHtnbG93RW5hYmxlZCA/ICdnbG93LWFjdGl2ZScgOiAnZ2xvdy1kaXNhYmxlZCd9YH0+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZSB6LTEwIHctMjggaC0yOCBzbTp3LTMyIHNtOmgtMzIgcm91bmRlZC1mdWxsIGJnLXNsYXRlLTk1MCBwLTEgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXJcIj5cbiAgICAgICAgICAgICAgICAgIDxkaXZcbiAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0SXNBdmF0YXJNb2RhbE9wZW4odHJ1ZSl9XG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHctZnVsbCBoLWZ1bGwgcm91bmRlZC1mdWxsIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHNoYWRvdy1pbm5lciBvdmVyZmxvdy1oaWRkZW4gYm9yZGVyIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTMwMCByZWxhdGl2ZSBjdXJzb3ItcG9pbnRlciBncm91cC1ob3ZlcjpyaW5nLTIgZ3JvdXAtaG92ZXI6cmluZy1ibHVlLTUwMC81MCAke1xuICAgICAgICAgICAgICAgICAgICAgIGdsb3dFbmFibGVkXG4gICAgICAgICAgICAgICAgICAgICAgICA/ICdiZy1ncmFkaWVudC10by10ciBmcm9tLXNsYXRlLTkwMCB2aWEtc2xhdGUtODAwIHRvLXNsYXRlLTkwMCBib3JkZXItc2xhdGUtNzAwLzYwJ1xuICAgICAgICAgICAgICAgICAgICAgICAgOiAnYmctc2xhdGUtOTAwIGJvcmRlci1zbGF0ZS04MDAnXG4gICAgICAgICAgICAgICAgICAgIH1gfVxuICAgICAgICAgICAgICAgICAgICB0aXRsZT1cIkNsaWNrIHRvIENoYW5nZSBQcm9maWxlIFBpY3R1cmVcIlxuICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICB7YXZhdGFyVXJsID8gKFxuICAgICAgICAgICAgICAgICAgICAgIDxpbWdcbiAgICAgICAgICAgICAgICAgICAgICAgIHNyYz17YXZhdGFyVXJsfVxuICAgICAgICAgICAgICAgICAgICAgICAgYWx0PVwiQWxiZXJ0IFJvYmxlZG9cIlxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGgtZnVsbCBvYmplY3QtY292ZXIgcm91bmRlZC1mdWxsXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9uRXJyb3I9eygpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgc2hvd1RvYXN0KCdGYWlsZWQgdG8gbG9hZCBwcm9maWxlIHBob3RvIFVSTCcsICdlcnJvcicpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICB1cGRhdGVBdmF0YXIobnVsbCk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPXtgdGV4dC0zeGwgc206dGV4dC00eGwgZm9udC1ibGFjayB0cmFja2luZy13aWRlciBzZWxlY3Qtbm9uZSB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi01MDAgJHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGdsb3dFbmFibGVkXG4gICAgICAgICAgICAgICAgICAgICAgICAgID8gJ2JnLWdyYWRpZW50LXRvLXIgZnJvbS1ibHVlLTQwMCB2aWEtaW5kaWdvLTMwMCB0by1wdXJwbGUtNDAwIGJnLWNsaXAtdGV4dCB0ZXh0LXRyYW5zcGFyZW50IGRyb3Atc2hhZG93LXNtJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICA6ICd0ZXh0LXNsYXRlLTIwMCdcbiAgICAgICAgICAgICAgICAgICAgICB9YH0+XG4gICAgICAgICAgICAgICAgICAgICAgICBBUlxuICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgKX1cblxuICAgICAgICAgICAgICAgICAgICB7LyogSG92ZXIgT3ZlcmxheSB0byBFZGl0IFByb2ZpbGUgUGhvdG8gKi99XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWJzb2x1dGUgaW5zZXQtMCBiZy1ibGFjay82MCBvcGFjaXR5LTAgZ3JvdXAtaG92ZXI6b3BhY2l0eS0xMDAgdHJhbnNpdGlvbi1vcGFjaXR5IGZsZXggZmxleC1jb2wgaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGdhcC0xIHRleHQtd2hpdGVcIj5cbiAgICAgICAgICAgICAgICAgICAgICA8Q2FtZXJhIGNsYXNzTmFtZT1cInctNSBoLTUgdGV4dC1ibHVlLTQwMFwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gZm9udC1ib2xkIHRyYWNraW5nLXRpZ2h0XCI+RWRpdCBQaG90bzwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgey8qIFF1aWNrIENhbWVyYSBBY3Rpb24gQmFkZ2UgYXQgQm90dG9tIFJpZ2h0IG9mIEF2YXRhciAqL31cbiAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldElzQXZhdGFyTW9kYWxPcGVuKHRydWUpfVxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImFic29sdXRlIGJvdHRvbS0xIHJpZ2h0LTEgei0yMCB3LTggaC04IHJvdW5kZWQtZnVsbCBiZy1ibHVlLTYwMCBob3ZlcjpiZy1ibHVlLTUwMCB0ZXh0LXdoaXRlIGJvcmRlci0yIGJvcmRlci1zbGF0ZS05NTAgc2hhZG93LWxnIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTIwMCBob3ZlcjpzY2FsZS0xMTAgYWN0aXZlOnNjYWxlLTk1IGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgICAgICB0aXRsZT1cIkNoYW5nZSBQcm9maWxlIFBpY3R1cmVcIlxuICAgICAgICAgICAgICAgIGFyaWEtbGFiZWw9XCJDaGFuZ2UgUHJvZmlsZSBQaWN0dXJlXCJcbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIDxDYW1lcmEgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjVcIiAvPlxuICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICB7LyogUHJvZmlsZSBOYW1lICYgVmVyaWZpZWQgQmFkZ2UgKi99XG4gICAgICAgICAgICA8aDEgY2xhc3NOYW1lPVwidGV4dC0yeGwgc206dGV4dC0zeGwgZm9udC1leHRyYWJvbGQgdHJhY2tpbmctdGlnaHQgdGV4dC13aGl0ZSBtYi0xLjUgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgPHNwYW4+QWxiZXJ0IFJvYmxlZG88L3NwYW4+XG4gICAgICAgICAgICAgIDxzcGFuIHRpdGxlPVwiVmVyaWZpZWQgUHJvZmlsZVwiIGNsYXNzTmFtZT1cImlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciB0ZXh0LWJsdWUtNTAwXCI+XG4gICAgICAgICAgICAgICAgPENoZWNrQ2lyY2xlMiBjbGFzc05hbWU9XCJ3LTUgaC01IGZpbGwtYmx1ZS01MDAgdGV4dC1zbGF0ZS05NTBcIiAvPlxuICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICA8L2gxPlxuXG4gICAgICAgICAgICB7LyogQXZhaWxhYmlsaXR5IFN0YXR1cyBCYWRnZSAqL31cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgbWItM1wiPlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9e2BpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSBweC0zIHB5LTEgcm91bmRlZC1mdWxsIHRleHQteHMgZm9udC1tZWRpdW0gYm9yZGVyIHRyYW5zaXRpb24tY29sb3JzICR7XG4gICAgICAgICAgICAgICAgZ2xvd0VuYWJsZWRcbiAgICAgICAgICAgICAgICAgID8gJ2JnLWVtZXJhbGQtNTAwLzEwIHRleHQtZW1lcmFsZC00MDAgYm9yZGVyLWVtZXJhbGQtNTAwLzIwJ1xuICAgICAgICAgICAgICAgICAgOiAnYmctc2xhdGUtOTAwIHRleHQtc2xhdGUtMzAwIGJvcmRlci1zbGF0ZS04MDAnXG4gICAgICAgICAgICAgIH1gfT5cbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9e2B3LTIgaC0yIHJvdW5kZWQtZnVsbCAke2dsb3dFbmFibGVkID8gJ2JnLWVtZXJhbGQtNDAwIGFuaW1hdGUtcHVsc2UnIDogJ2JnLWVtZXJhbGQtNTAwJ31gfSAvPlxuICAgICAgICAgICAgICAgIEF2YWlsYWJsZSBmb3IgQ29udGFjdFxuICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgey8qIEJpbyBEZXNjcmlwdGlvbiAqL31cbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgc206dGV4dC1zbSB0ZXh0LXNsYXRlLTMwMCBtYXgtdy1zbSBsZWFkaW5nLXJlbGF4ZWQgbWItNiBmb250LWxpZ2h0XCI+XG4gICAgICAgICAgICAgIFdlbGNvbWUgdG8gbXkgcGVyc29uYWwgbGFuZGluZyBwYWdlLiBDb25uZWN0IHdpdGggbWUgb24gc29jaWFsIG1lZGlhIG9yIHJlYWNoIG91dCBkaXJlY3RseSFcbiAgICAgICAgICAgIDwvcD5cblxuICAgICAgICAgICAgey8qIERpcmVjdCBDb250YWN0IENhcmQgKi99XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbCBiZy1zbGF0ZS05MDAvODAgcm91bmRlZC0yeGwgcC00IG1iLTYgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAvOTAgc2hhZG93LWlubmVyXCI+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGdhcC0zXCI+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMy41IG92ZXJmbG93LWhpZGRlbiB0ZXh0LWxlZnRcIj5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPXtgdy0xMSBoLTExIHJvdW5kZWQteGwgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgc2hyaW5rLTAgYm9yZGVyIHRyYW5zaXRpb24tYWxsICR7XG4gICAgICAgICAgICAgICAgICAgIGdsb3dFbmFibGVkXG4gICAgICAgICAgICAgICAgICAgICAgPyAnYmctYmx1ZS01MDAvMTUgYm9yZGVyLWJsdWUtNTAwLzMwIHRleHQtYmx1ZS00MDAnXG4gICAgICAgICAgICAgICAgICAgICAgOiAnYmctc2xhdGUtODAwIGJvcmRlci1zbGF0ZS03MDAgdGV4dC1zbGF0ZS0zMDAnXG4gICAgICAgICAgICAgICAgICB9YH0+XG4gICAgICAgICAgICAgICAgICAgIDxQaG9uZUNhbGwgY2xhc3NOYW1lPVwidy01IGgtNVwiIC8+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidHJ1bmNhdGVcIj5cbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gdXBwZXJjYXNlIGZvbnQtYm9sZCB0cmFja2luZy13aWRlciB0ZXh0LXNsYXRlLTQwMFwiPkRpcmVjdCBDb250YWN0PC9wPlxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIHNtOnRleHQtYmFzZSBmb250LWJvbGQgdGV4dC1zbGF0ZS0xMDAgZm9udC1tb25vIHRyYWNraW5nLXRpZ2h0XCI+XG4gICAgICAgICAgICAgICAgICAgICAgMDk2NiAwMjQgODIyMVxuICAgICAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgIHsvKiBEaXJlY3QgQWN0aW9uIEJ1dHRvbnM6IENhbGwsIFNNUywgQ29weSAqL31cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHNocmluay0wXCI+XG4gICAgICAgICAgICAgICAgICB7LyogQ2FsbCBCdXR0b24gKi99XG4gICAgICAgICAgICAgICAgICA8YVxuICAgICAgICAgICAgICAgICAgICBocmVmPVwidGVsOjA5NjYwMjQ4MjIxXCJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgdy05IGgtOSBzbTp3LTEwIHNtOmgtMTAgcm91bmRlZC14bCBib3JkZXIgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tMjAwIGFjdGl2ZTpzY2FsZS05NSAke1xuICAgICAgICAgICAgICAgICAgICAgIGdsb3dFbmFibGVkXG4gICAgICAgICAgICAgICAgICAgICAgICA/ICdiZy1lbWVyYWxkLTUwMC8yMCBob3ZlcjpiZy1lbWVyYWxkLTUwMC8zMCB0ZXh0LWVtZXJhbGQtNDAwIGJvcmRlci1lbWVyYWxkLTUwMC8zMCdcbiAgICAgICAgICAgICAgICAgICAgICAgIDogJ2JnLXNsYXRlLTgwMCBob3ZlcjpiZy1zbGF0ZS03MDAgdGV4dC1zbGF0ZS0yMDAgYm9yZGVyLXNsYXRlLTcwMCdcbiAgICAgICAgICAgICAgICAgICAgfWB9XG4gICAgICAgICAgICAgICAgICAgIHRpdGxlPVwiQ2FsbCBEaXJlY3RseVwiXG4gICAgICAgICAgICAgICAgICAgIGFyaWEtbGFiZWw9XCJDYWxsXCJcbiAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgPFBob25lIGNsYXNzTmFtZT1cInctNCBoLTRcIiAvPlxuICAgICAgICAgICAgICAgICAgPC9hPlxuXG4gICAgICAgICAgICAgICAgICB7LyogU01TIEJ1dHRvbiAqL31cbiAgICAgICAgICAgICAgICAgIDxhXG4gICAgICAgICAgICAgICAgICAgIGhyZWY9XCJzbXM6MDk2NjAyNDgyMjFcIlxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2B3LTkgaC05IHNtOnctMTAgc206aC0xMCByb3VuZGVkLXhsIGJvcmRlciBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0yMDAgYWN0aXZlOnNjYWxlLTk1ICR7XG4gICAgICAgICAgICAgICAgICAgICAgZ2xvd0VuYWJsZWRcbiAgICAgICAgICAgICAgICAgICAgICAgID8gJ2JnLWluZGlnby01MDAvMjAgaG92ZXI6YmctaW5kaWdvLTUwMC8zMCB0ZXh0LWluZGlnby00MDAgYm9yZGVyLWluZGlnby01MDAvMzAnXG4gICAgICAgICAgICAgICAgICAgICAgICA6ICdiZy1zbGF0ZS04MDAgaG92ZXI6Ymctc2xhdGUtNzAwIHRleHQtc2xhdGUtMjAwIGJvcmRlci1zbGF0ZS03MDAnXG4gICAgICAgICAgICAgICAgICAgIH1gfVxuICAgICAgICAgICAgICAgICAgICB0aXRsZT1cIlNlbmQgU01TIE1lc3NhZ2VcIlxuICAgICAgICAgICAgICAgICAgICBhcmlhLWxhYmVsPVwiU2VuZCBNZXNzYWdlXCJcbiAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgPE1lc3NhZ2VTcXVhcmUgY2xhc3NOYW1lPVwidy00IGgtNFwiIC8+XG4gICAgICAgICAgICAgICAgICA8L2E+XG5cbiAgICAgICAgICAgICAgICAgIHsvKiBDb3B5IE51bWJlciBCdXR0b24gKi99XG4gICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZUNvcHlQaG9uZU51bWJlcignMDk2NjAyNDgyMjEnKX1cbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy05IGgtOSBzbTp3LTEwIHNtOmgtMTAgcm91bmRlZC14bCBiZy1zbGF0ZS04MDAgaG92ZXI6Ymctc2xhdGUtNzAwIHRleHQtc2xhdGUtMzAwIGJvcmRlciBib3JkZXItc2xhdGUtNzAwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTIwMCBhY3RpdmU6c2NhbGUtOTUgZ3JvdXAgY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgICAgICAgICAgICB0aXRsZT1cIkNvcHkgUGhvbmUgTnVtYmVyXCJcbiAgICAgICAgICAgICAgICAgICAgYXJpYS1sYWJlbD1cIkNvcHkgUGhvbmUgTnVtYmVyXCJcbiAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAge2NvcGllZE51bWJlciA/IChcbiAgICAgICAgICAgICAgICAgICAgICA8Q2hlY2sgY2xhc3NOYW1lPVwidy00IGgtNCB0ZXh0LWVtZXJhbGQtNDAwXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICAgICAgICA8Q29weSBjbGFzc05hbWU9XCJ3LTQgaC00IGdyb3VwLWhvdmVyOnRleHQtd2hpdGVcIiAvPlxuICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIHsvKiBTb2NpYWwgTWVkaWEgTGlua3MgU2VjdGlvbiAqL31cbiAgICAgICAgICAgIDxkaXYgaWQ9XCJzb2NpYWwtbGlua3Mtc2VjdGlvblwiIGNsYXNzTmFtZT1cInctZnVsbCBmbGV4IGZsZXgtY29sIGdhcC0zLjUgc2Nyb2xsLW10LTIwXCI+XG4gICAgICAgICAgICAgIFxuICAgICAgICAgICAgICB7LyogRmFjZWJvb2sgQ2FyZCAqL31cbiAgICAgICAgICAgICAgPGFcbiAgICAgICAgICAgICAgICBocmVmPVwiaHR0cHM6Ly93d3cuZmFjZWJvb2suY29tL3Byb2ZpbGUucGhwP2lkPTYxNTk0MjU2NTQ5OTIxXCJcbiAgICAgICAgICAgICAgICB0YXJnZXQ9XCJfYmxhbmtcIlxuICAgICAgICAgICAgICAgIHJlbD1cIm5vb3BlbmVyIG5vcmVmZXJyZXJcIlxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImdsYXNzLWNhcmQgZ2xhc3MtY2FyZC1ob3ZlciByb3VuZGVkLTJ4bCBwLTQgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGdyb3VwIHRleHQtbGVmdCBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC00XCI+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMTEgaC0xMSByb3VuZGVkLXhsIGJnLVsjMTg3N0YyXS8xNSBib3JkZXIgYm9yZGVyLVsjMTg3N0YyXS8zMCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciB0ZXh0LVsjMTg3N0YyXSBncm91cC1ob3ZlcjpzY2FsZS0xMTAgdHJhbnNpdGlvbi10cmFuc2Zvcm0gZHVyYXRpb24tMzAwXCI+XG4gICAgICAgICAgICAgICAgICAgIDxpIGNsYXNzTmFtZT1cImZhLWJyYW5kcyBmYS1mYWNlYm9vay1mIHRleHQtbGdcIiAvPlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LWJvbGQgdGV4dC13aGl0ZSBncm91cC1ob3Zlcjp0ZXh0LWJsdWUtNDAwIHRyYW5zaXRpb24tY29sb3JzIGZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjVcIj5cbiAgICAgICAgICAgICAgICAgICAgICBGYWNlYm9va1xuICAgICAgICAgICAgICAgICAgICAgIDxFeHRlcm5hbExpbmsgY2xhc3NOYW1lPVwidy0zIGgtMyBvcGFjaXR5LTAgZ3JvdXAtaG92ZXI6b3BhY2l0eS0xMDAgdHJhbnNpdGlvbi1vcGFjaXR5XCIgLz5cbiAgICAgICAgICAgICAgICAgICAgPC9oMj5cbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXNsYXRlLTQwMFwiPkFsYmVydCBSb2JsZWRvPC9wPlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTggaC04IHJvdW5kZWQtZnVsbCBiZy1zbGF0ZS04MDAvNjAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgdGV4dC1zbGF0ZS00MDAgZ3JvdXAtaG92ZXI6dGV4dC13aGl0ZSBncm91cC1ob3Zlcjp0cmFuc2xhdGUteC0xIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTMwMFwiPlxuICAgICAgICAgICAgICAgICAgPENoZXZyb25SaWdodCBjbGFzc05hbWU9XCJ3LTQgaC00XCIgLz5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPC9hPlxuXG4gICAgICAgICAgICAgIHsvKiBUaWtUb2sgQ2FyZCAqL31cbiAgICAgICAgICAgICAgPGFcbiAgICAgICAgICAgICAgICBocmVmPVwiaHR0cHM6Ly93d3cudGlrdG9rLmNvbS9AX2trd2t3az9fcj0xJl90PVpTLTlBSmtrRTBtNFc1XCJcbiAgICAgICAgICAgICAgICB0YXJnZXQ9XCJfYmxhbmtcIlxuICAgICAgICAgICAgICAgIHJlbD1cIm5vb3BlbmVyIG5vcmVmZXJyZXJcIlxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImdsYXNzLWNhcmQgZ2xhc3MtY2FyZC1ob3ZlciByb3VuZGVkLTJ4bCBwLTQgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGdyb3VwIHRleHQtbGVmdCBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC00XCI+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMTEgaC0xMSByb3VuZGVkLXhsIGJnLXNsYXRlLTgwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTcwMCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciB0ZXh0LXdoaXRlIGdyb3VwLWhvdmVyOnNjYWxlLTExMCB0cmFuc2l0aW9uLXRyYW5zZm9ybSBkdXJhdGlvbi0zMDAgc2hhZG93LXNtXCI+XG4gICAgICAgICAgICAgICAgICAgIDxpIGNsYXNzTmFtZT1cImZhLWJyYW5kcyBmYS10aWt0b2sgdGV4dC1sZ1wiIC8+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtYm9sZCB0ZXh0LXdoaXRlIGdyb3VwLWhvdmVyOnRleHQtcGluay00MDAgdHJhbnNpdGlvbi1jb2xvcnMgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNVwiPlxuICAgICAgICAgICAgICAgICAgICAgIFRpa1Rva1xuICAgICAgICAgICAgICAgICAgICAgIDxFeHRlcm5hbExpbmsgY2xhc3NOYW1lPVwidy0zIGgtMyBvcGFjaXR5LTAgZ3JvdXAtaG92ZXI6b3BhY2l0eS0xMDAgdHJhbnNpdGlvbi1vcGFjaXR5XCIgLz5cbiAgICAgICAgICAgICAgICAgICAgPC9oMj5cbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXNsYXRlLTQwMFwiPkBfa2t3a3drPC9wPlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTggaC04IHJvdW5kZWQtZnVsbCBiZy1zbGF0ZS04MDAvNjAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgdGV4dC1zbGF0ZS00MDAgZ3JvdXAtaG92ZXI6dGV4dC13aGl0ZSBncm91cC1ob3Zlcjp0cmFuc2xhdGUteC0xIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTMwMFwiPlxuICAgICAgICAgICAgICAgICAgPENoZXZyb25SaWdodCBjbGFzc05hbWU9XCJ3LTQgaC00XCIgLz5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPC9hPlxuXG4gICAgICAgICAgICAgIHsvKiBJbnN0YWdyYW0gQ2FyZCAqL31cbiAgICAgICAgICAgICAgPGFcbiAgICAgICAgICAgICAgICBocmVmPVwiaHR0cHM6Ly93d3cuaW5zdGFncmFtLmNvbS9fYmx1dXVlZTAwP3N0a249Y1dNeWMybzNiVEJvZVRKaFwiXG4gICAgICAgICAgICAgICAgdGFyZ2V0PVwiX2JsYW5rXCJcbiAgICAgICAgICAgICAgICByZWw9XCJub29wZW5lciBub3JlZmVycmVyXCJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJnbGFzcy1jYXJkIGdsYXNzLWNhcmQtaG92ZXIgcm91bmRlZC0yeGwgcC00IGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBncm91cCB0ZXh0LWxlZnQgY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtNFwiPlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTExIGgtMTEgcm91bmRlZC14bCBiZy1ncmFkaWVudC10by10ciBmcm9tLVsjZjA5NDMzXSB2aWEtWyNkYzI3NDNdIHRvLVsjYmMxODg4XSBwLVsxcHhdIGdyb3VwLWhvdmVyOnNjYWxlLTExMCB0cmFuc2l0aW9uLXRyYW5zZm9ybSBkdXJhdGlvbi0zMDBcIj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGwgaC1mdWxsIGJnLXNsYXRlLTk1MCByb3VuZGVkLVsxMXB4XSBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciB0ZXh0LVsjRTQ0MDVGXVwiPlxuICAgICAgICAgICAgICAgICAgICAgIDxpIGNsYXNzTmFtZT1cImZhLWJyYW5kcyBmYS1pbnN0YWdyYW0gdGV4dC1sZ1wiIC8+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LWJvbGQgdGV4dC13aGl0ZSBncm91cC1ob3Zlcjp0ZXh0LXBpbmstNDAwIHRyYW5zaXRpb24tY29sb3JzIGZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjVcIj5cbiAgICAgICAgICAgICAgICAgICAgICBJbnN0YWdyYW1cbiAgICAgICAgICAgICAgICAgICAgICA8RXh0ZXJuYWxMaW5rIGNsYXNzTmFtZT1cInctMyBoLTMgb3BhY2l0eS0wIGdyb3VwLWhvdmVyOm9wYWNpdHktMTAwIHRyYW5zaXRpb24tb3BhY2l0eVwiIC8+XG4gICAgICAgICAgICAgICAgICAgIDwvaDI+XG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1zbGF0ZS00MDBcIj5AX2JsdXV1ZWUwMDwvcD5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy04IGgtOCByb3VuZGVkLWZ1bGwgYmctc2xhdGUtODAwLzYwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHRleHQtc2xhdGUtNDAwIGdyb3VwLWhvdmVyOnRleHQtd2hpdGUgZ3JvdXAtaG92ZXI6dHJhbnNsYXRlLXgtMSB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0zMDBcIj5cbiAgICAgICAgICAgICAgICAgIDxDaGV2cm9uUmlnaHQgY2xhc3NOYW1lPVwidy00IGgtNFwiIC8+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDwvYT5cblxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIHsvKiBHbG93aW5nIFRvZ2dsZSAmIFByb2ZpbGUgQ3VzdG9taXphdGlvbiBCYXIgSW5zaWRlIFByb2ZpbGUgQ2FyZCAqL31cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsIG10LTYgcHQtNSBib3JkZXItdCBib3JkZXItc2xhdGUtODAwLzgwIGZsZXggZmxleC1jb2wgc206ZmxleC1yb3cgaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBnYXAtMyB0ZXh0LXhzXCI+XG4gICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRJc0F2YXRhck1vZGFsT3Blbih0cnVlKX1cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgc206dy1hdXRvIHB4LTMuNSBweS0xLjUgcm91bmRlZC14bCBiZy1zbGF0ZS05MDAgaG92ZXI6Ymctc2xhdGUtODAwIHRleHQtc2xhdGUtMzAwIGhvdmVyOnRleHQtd2hpdGUgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZ2FwLTIgdHJhbnNpdGlvbi1hbGwgY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgPENhbWVyYSBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNSB0ZXh0LWJsdWUtNDAwXCIgLz5cbiAgICAgICAgICAgICAgICBDaGFuZ2UgUHJvZmlsZSBQaWN0dXJlXG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxuXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIHctZnVsbCBzbTp3LWF1dG8gZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTQwMCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IGZvbnQtbWVkaXVtXCI+XG4gICAgICAgICAgICAgICAgICB7Z2xvd0VuYWJsZWQgPyAoXG4gICAgICAgICAgICAgICAgICAgIDxaYXAgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjUgdGV4dC1wdXJwbGUtNDAwXCIgLz5cbiAgICAgICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgICAgIDxaYXBPZmYgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjUgdGV4dC1zbGF0ZS01MDBcIiAvPlxuICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgIEdsb3cgQ29sb3JzXG4gICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9e3RvZ2dsZUdsb3d9XG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BweC0zIHB5LTEgcm91bmRlZC1mdWxsIHRleHQteHMgZm9udC1zZW1pYm9sZCBib3JkZXIgdHJhbnNpdGlvbi1hbGwgY3Vyc29yLXBvaW50ZXIgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSAke1xuICAgICAgICAgICAgICAgICAgICBnbG93RW5hYmxlZFxuICAgICAgICAgICAgICAgICAgICAgID8gJ2JnLXB1cnBsZS05MDAvNDAgdGV4dC1wdXJwbGUtMzAwIGJvcmRlci1wdXJwbGUtNTAwLzQwIGhvdmVyOmJnLXB1cnBsZS05MDAvNjAnXG4gICAgICAgICAgICAgICAgICAgICAgOiAnYmctc2xhdGUtODAwIHRleHQtc2xhdGUtMzAwIGJvcmRlci1zbGF0ZS03MDAgaG92ZXI6Ymctc2xhdGUtNzAwJ1xuICAgICAgICAgICAgICAgICAgfWB9XG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAge2dsb3dFbmFibGVkID8gJ1R1cm4gT2ZmIEdsb3cnIDogJ1R1cm4gT24gR2xvdyd9XG4gICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgey8qIEZvb3RlciAvIFNoYXJlICYgRG93bmxvYWQgQWN0aW9ucyAqL31cbiAgICAgICAgPGZvb3RlciBjbGFzc05hbWU9XCJ3LWZ1bGwgZmxleCBmbGV4LWNvbCBpdGVtcy1jZW50ZXIgZ2FwLTQgbXQtOFwiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXdyYXAgaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGdhcC0yLjVcIj5cbiAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgb25DbGljaz17aGFuZGxlU2hhcmVQcm9maWxlfVxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1zbGF0ZS0zMDAgaG92ZXI6dGV4dC13aGl0ZSBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBweS0yLjUgcHgtNCByb3VuZGVkLWZ1bGwgYmctc2xhdGUtOTAwLzgwIGhvdmVyOmJnLXNsYXRlLTgwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTcwMC82MCBzaGFkb3ctbGcgdHJhbnNpdGlvbi1hbGwgYWN0aXZlOnNjYWxlLTk1IGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgPFNoYXJlMiBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNSB0ZXh0LWJsdWUtNDAwXCIgLz5cbiAgICAgICAgICAgICAgU2hhcmUgUHJvZmlsZVxuICAgICAgICAgICAgPC9idXR0b24+XG5cbiAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0SXNEb3dubG9hZE1vZGFsT3Blbih0cnVlKX1cbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtZW1lcmFsZC0zMDAgaG92ZXI6dGV4dC13aGl0ZSBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBweS0yLjUgcHgtNCByb3VuZGVkLWZ1bGwgYmctZW1lcmFsZC05NTAvNDAgaG92ZXI6YmctZW1lcmFsZC05MDAvNjAgYm9yZGVyIGJvcmRlci1lbWVyYWxkLTUwMC80MCBzaGFkb3ctbGcgdHJhbnNpdGlvbi1hbGwgYWN0aXZlOnNjYWxlLTk1IGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgPERvd25sb2FkIGNsYXNzTmFtZT1cInctMy41IGgtMy41IHRleHQtZW1lcmFsZC00MDBcIiAvPlxuICAgICAgICAgICAgICBEb3dubG9hZCBQcm9qZWN0XG4gICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICBcbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSB0ZXh0LXNsYXRlLTUwMCBmb250LW1lZGl1bVwiPlxuICAgICAgICAgICAgwqkge2N1cnJlbnRZZWFyfSBBbGJlcnQgUm9ibGVkbyDigKIgQnVpbHQgZm9yIHF1aWNrIGNvbm5lY3Rpb25cbiAgICAgICAgICA8L3A+XG4gICAgICAgIDwvZm9vdGVyPlxuICAgICAgPC9tYWluPlxuXG4gICAgICB7LyogUHJvZmlsZSBQaWN0dXJlIENoYW5nZSBNb2RhbCAqL31cbiAgICAgIDxBbmltYXRlUHJlc2VuY2U+XG4gICAgICAgIHtpc0F2YXRhck1vZGFsT3BlbiAmJiAoXG4gICAgICAgICAgPG1vdGlvbi5kaXZcbiAgICAgICAgICAgIGluaXRpYWw9e3sgb3BhY2l0eTogMCB9fVxuICAgICAgICAgICAgYW5pbWF0ZT17eyBvcGFjaXR5OiAxIH19XG4gICAgICAgICAgICBleGl0PXt7IG9wYWNpdHk6IDAgfX1cbiAgICAgICAgICAgIHRyYW5zaXRpb249e3sgZHVyYXRpb246IDAuMjQsIGVhc2U6ICdlYXNlT3V0JyB9fVxuICAgICAgICAgICAgb25DbGljaz17KGUpID0+IHtcbiAgICAgICAgICAgICAgaWYgKGUudGFyZ2V0ID09PSBlLmN1cnJlbnRUYXJnZXQpIHNldElzQXZhdGFyTW9kYWxPcGVuKGZhbHNlKTtcbiAgICAgICAgICAgIH19XG4gICAgICAgICAgICBjbGFzc05hbWU9XCJmaXhlZCBpbnNldC0wIHotNTAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcC00IGJnLWJsYWNrLzc1IGJhY2tkcm9wLWJsdXItbWRcIlxuICAgICAgICAgID5cbiAgICAgICAgICAgIDxtb3Rpb24uZGl2XG4gICAgICAgICAgICAgIGluaXRpYWw9e3sgb3BhY2l0eTogMCwgeTogNDQsIHNjYWxlOiAwLjk0IH19XG4gICAgICAgICAgICAgIGFuaW1hdGU9e3sgb3BhY2l0eTogMSwgeTogMCwgc2NhbGU6IDEgfX1cbiAgICAgICAgICAgICAgZXhpdD17eyBvcGFjaXR5OiAwLCB5OiAzMCwgc2NhbGU6IDAuOTUgfX1cbiAgICAgICAgICAgICAgdHJhbnNpdGlvbj17eyB0eXBlOiAnc3ByaW5nJywgZGFtcGluZzogMjcsIHN0aWZmbmVzczogMzMwLCBtYXNzOiAwLjggfX1cbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIHJvdW5kZWQtM3hsIHctZnVsbCBtYXgtdy1tZCBwLTYgc2hhZG93LTJ4bCByZWxhdGl2ZSBtYXgtaC1bOTB2aF0gb3ZlcmZsb3cteS1hdXRvXCJcbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgXG4gICAgICAgICAgICAgIHsvKiBNb2RhbCBIZWFkZXIgKi99XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIHBiLTQgYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTgwMCBtYi01XCI+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMi41XCI+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctOCBoLTggcm91bmRlZC1sZyBiZy1ibHVlLTUwMC8xMCBib3JkZXIgYm9yZGVyLWJsdWUtNTAwLzIwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHRleHQtYmx1ZS00MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgPFVzZXIgY2xhc3NOYW1lPVwidy00IGgtNFwiIC8+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LWJhc2UgZm9udC1ib2xkIHRleHQtd2hpdGVcIj5DaGFuZ2UgUHJvZmlsZSBQaWN0dXJlPC9oMz5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRJc0F2YXRhck1vZGFsT3BlbihmYWxzZSl9XG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LTggaC04IHJvdW5kZWQtZnVsbCBiZy1zbGF0ZS04MDAgdGV4dC1zbGF0ZS00MDAgaG92ZXI6dGV4dC13aGl0ZSBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciB0cmFuc2l0aW9uLWNvbG9ycyBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgICAgICAgICBhcmlhLWxhYmVsPVwiQ2xvc2UgTW9kYWxcIlxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgIDxYIGNsYXNzTmFtZT1cInctNCBoLTRcIiAvPlxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICB7LyogTGl2ZSBBdmF0YXIgUHJldmlldyAqL31cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIGl0ZW1zLWNlbnRlciBtYi02IHAtNCBiZy1zbGF0ZS05NTAvNjAgcm91bmRlZC0yeGwgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAvODBcIj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT17YGdsb3ctcmluZyBtYi0zIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTMwMCAke2dsb3dFbmFibGVkID8gJ2dsb3ctYWN0aXZlJyA6ICdnbG93LWRpc2FibGVkJ31gfT5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmUgei0xMCB3LTI0IGgtMjQgcm91bmRlZC1mdWxsIGJnLXNsYXRlLTk1MCBwLTEgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXJcIj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9e2B3LWZ1bGwgaC1mdWxsIHJvdW5kZWQtZnVsbCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBzaGFkb3ctaW5uZXIgb3ZlcmZsb3ctaGlkZGVuIGJvcmRlciAke1xuICAgICAgICAgICAgICAgICAgICAgIGdsb3dFbmFibGVkXG4gICAgICAgICAgICAgICAgICAgICAgICA/ICdiZy1ncmFkaWVudC10by10ciBmcm9tLXNsYXRlLTkwMCB2aWEtc2xhdGUtODAwIHRvLXNsYXRlLTkwMCBib3JkZXItc2xhdGUtNzAwLzYwJ1xuICAgICAgICAgICAgICAgICAgICAgICAgOiAnYmctc2xhdGUtOTAwIGJvcmRlci1zbGF0ZS04MDAnXG4gICAgICAgICAgICAgICAgICAgIH1gfT5cbiAgICAgICAgICAgICAgICAgICAgICB7YXZhdGFyVXJsID8gKFxuICAgICAgICAgICAgICAgICAgICAgICAgPGltZyBzcmM9e2F2YXRhclVybH0gYWx0PVwiUHJldmlld1wiIGNsYXNzTmFtZT1cInctZnVsbCBoLWZ1bGwgb2JqZWN0LWNvdmVyIHJvdW5kZWQtZnVsbFwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT17YHRleHQtMnhsIGZvbnQtYmxhY2sgJHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgZ2xvd0VuYWJsZWQgPyAnYmctZ3JhZGllbnQtdG8tciBmcm9tLWJsdWUtNDAwIHZpYS1pbmRpZ28tMzAwIHRvLXB1cnBsZS00MDAgYmctY2xpcC10ZXh0IHRleHQtdHJhbnNwYXJlbnQnIDogJ3RleHQtc2xhdGUtMjAwJ1xuICAgICAgICAgICAgICAgICAgICAgICAgfWB9PlxuICAgICAgICAgICAgICAgICAgICAgICAgICBBUlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXNsYXRlLTQwMCBmb250LW1lZGl1bVwiPlxuICAgICAgICAgICAgICAgICAge2F2YXRhclVybCA/ICdDdXJyZW50IEN1c3RvbSBQaG90bycgOiAnRGVmYXVsdCBJbml0aWFscyAoQVIpJ31cbiAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS01XCI+XG4gICAgICAgICAgICAgICAgey8qIE9wdGlvbiAxOiBVcGxvYWQgZnJvbSBkZXZpY2UgKi99XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTMuNSBiZy1zbGF0ZS05NTAvNjAgcm91bmRlZC0yeGwgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDBcIj5cbiAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXhzIGZvbnQtYm9sZCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgdGV4dC1ibHVlLTQwMCBtYi0yLjUgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNVwiPlxuICAgICAgICAgICAgICAgICAgICA8VXBsb2FkQ2xvdWQgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjVcIiAvPiBVcGxvYWQgZnJvbSBEZXZpY2VcbiAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgdy1mdWxsIGgtMjAgYm9yZGVyLTIgYm9yZGVyLWRhc2hlZCBib3JkZXItc2xhdGUtNzAwIGhvdmVyOmJvcmRlci1ibHVlLTUwMCByb3VuZGVkLXhsIGN1cnNvci1wb2ludGVyIGJnLXNsYXRlLTkwMC81MCBob3ZlcjpiZy1zbGF0ZS04MDAvNDAgdHJhbnNpdGlvbi1hbGwgZ3JvdXBcIj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBwdC0yIHBiLTJcIj5cbiAgICAgICAgICAgICAgICAgICAgICA8Q2FtZXJhIGNsYXNzTmFtZT1cInctNSBoLTUgdGV4dC1zbGF0ZS00MDAgZ3JvdXAtaG92ZXI6dGV4dC1ibHVlLTQwMCBtYi0xIHRyYW5zaXRpb24tY29sb3JzXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc2xhdGUtMzAwIGZvbnQtbWVkaXVtXCI+Q2hvb3NlIGEgcGhvdG8gZmlsZTwvcD5cbiAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSB0ZXh0LXNsYXRlLTUwMFwiPlBORywgSlBHLCBXRUJQLCBHSUYgc3VwcG9ydGVkPC9wPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImZpbGVcIlxuICAgICAgICAgICAgICAgICAgICAgIGFjY2VwdD1cImltYWdlLypcIlxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImhpZGRlblwiXG4gICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUF2YXRhckZpbGVVcGxvYWR9XG4gICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICA8L2xhYmVsPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgey8qIE9wdGlvbiAyOiBJbWFnZSBVUkwgKi99XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTMuNSBiZy1zbGF0ZS05NTAvNjAgcm91bmRlZC0yeGwgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDBcIj5cbiAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXhzIGZvbnQtYm9sZCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgdGV4dC1pbmRpZ28tNDAwIG1iLTIuNSBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41XCI+XG4gICAgICAgICAgICAgICAgICAgIDxJbWFnZUljb24gY2xhc3NOYW1lPVwidy0zLjUgaC0zLjVcIiAvPiBQaG90byBXZWIgTGluayAoVVJMKVxuICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgIDxmb3JtIG9uU3VibWl0PXtoYW5kbGVBcHBseUF2YXRhclVybH0gY2xhc3NOYW1lPVwiZmxleCBnYXAtMlwiPlxuICAgICAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidXJsXCJcbiAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17YXZhdGFyVXJsSW5wdXR9XG4gICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRBdmF0YXJVcmxJbnB1dChlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJodHRwczovL2V4YW1wbGUuY29tL3Bob3RvLmpwZ1wiXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleC0xIGJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCByb3VuZGVkLXhsIHB4LTMgcHktMiB0ZXh0LXhzIHRleHQtd2hpdGUgcGxhY2Vob2xkZXItc2xhdGUtNTAwIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpib3JkZXItaW5kaWdvLTUwMCB0cmFuc2l0aW9uLWNvbG9yc1wiXG4gICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwic3VibWl0XCJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1pbmRpZ28tNjAwIGhvdmVyOmJnLWluZGlnby01MDAgdGV4dC13aGl0ZSB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgcHgtMy41IHB5LTIgcm91bmRlZC14bCB0cmFuc2l0aW9uLWNvbG9ycyBzaHJpbmstMCBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICBBcHBseSBVUkxcbiAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICA8L2Zvcm0+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICB7LyogT3B0aW9uIDM6IFByZXNldCBBdmF0YXJzICovfVxuICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC14cyBmb250LWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIHRleHQtc2xhdGUtNDAwIG1iLTJcIj5cbiAgICAgICAgICAgICAgICAgICAgUHJlc2V0IEF2YXRhcnNcbiAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTQgZ2FwLTIuNVwiPlxuICAgICAgICAgICAgICAgICAgICB7UFJFU0VUX0FWQVRBUlMubWFwKChwcmVzZXQsIGluZGV4KSA9PiAoXG4gICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAga2V5PXtpbmRleH1cbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdXBkYXRlQXZhdGFyKHByZXNldC51cmwpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICBzaG93VG9hc3QoYFNlbGVjdGVkICR7cHJlc2V0Lm5hbWV9IGF2YXRhciFgKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0SXNBdmF0YXJNb2RhbE9wZW4oZmFsc2UpO1xuICAgICAgICAgICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImdyb3VwIGZsZXggZmxleC1jb2wgaXRlbXMtY2VudGVyIGdhcC0xLjUgcC0yIHJvdW5kZWQteGwgYmctc2xhdGUtOTUwLzYwIGhvdmVyOmJnLXNsYXRlLTgwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCBob3Zlcjpib3JkZXItYmx1ZS01MDAvNjAgdHJhbnNpdGlvbi1hbGwgY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgICAgICAgICAgICAgICAgdGl0bGU9e3ByZXNldC5uYW1lfVxuICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxpbWdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgc3JjPXtwcmVzZXQudXJsfVxuICAgICAgICAgICAgICAgICAgICAgICAgICBhbHQ9e3ByZXNldC5uYW1lfVxuICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LTExIGgtMTEgcm91bmRlZC1mdWxsIG9iamVjdC1jb3ZlciBib3JkZXIgYm9yZGVyLXNsYXRlLTcwMCBncm91cC1ob3ZlcjpzY2FsZS0xMDUgdHJhbnNpdGlvbi10cmFuc2Zvcm1cIlxuICAgICAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIHRleHQtc2xhdGUtNDAwIGdyb3VwLWhvdmVyOnRleHQtd2hpdGUgdHJ1bmNhdGUgbWF4LXctZnVsbFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICB7cHJlc2V0Lm5hbWV9XG4gICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgIHsvKiBNb2RhbCBGb290ZXIgQWN0aW9ucyAqL31cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC02IHB0LTQgYm9yZGVyLXQgYm9yZGVyLXNsYXRlLTgwMCBmbGV4IGp1c3RpZnktYmV0d2VlbiBpdGVtcy1jZW50ZXJcIj5cbiAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVSZXNldEF2YXRhcn1cbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LXJvc2UtNDAwIGhvdmVyOnRleHQtcm9zZS0zMDAgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgPFRyYXNoMiBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNVwiIC8+XG4gICAgICAgICAgICAgICAgICBSZXNldCB0byBJbml0aWFscyAoQVIpXG4gICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0SXNBdmF0YXJNb2RhbE9wZW4oZmFsc2UpfVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctc2xhdGUtODAwIGhvdmVyOmJnLXNsYXRlLTcwMCB0ZXh0LXNsYXRlLTIwMCB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgcHgtNCBweS0yIHJvdW5kZWQteGwgdHJhbnNpdGlvbi1jb2xvcnMgY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgIERvbmVcbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIDwvbW90aW9uLmRpdj5cbiAgICAgICAgICA8L21vdGlvbi5kaXY+XG4gICAgICAgICl9XG4gICAgICA8L0FuaW1hdGVQcmVzZW5jZT5cblxuICAgICAgey8qIENvdmVyIEN1c3RvbWl6ZXIgTW9kYWwgKi99XG4gICAgICA8QW5pbWF0ZVByZXNlbmNlPlxuICAgICAgICB7aXNDb3Zlck1vZGFsT3BlbiAmJiAoXG4gICAgICAgICAgPG1vdGlvbi5kaXZcbiAgICAgICAgICAgIGluaXRpYWw9e3sgb3BhY2l0eTogMCB9fVxuICAgICAgICAgICAgYW5pbWF0ZT17eyBvcGFjaXR5OiAxIH19XG4gICAgICAgICAgICBleGl0PXt7IG9wYWNpdHk6IDAgfX1cbiAgICAgICAgICAgIHRyYW5zaXRpb249e3sgZHVyYXRpb246IDAuMjQsIGVhc2U6ICdlYXNlT3V0JyB9fVxuICAgICAgICAgICAgb25DbGljaz17KGUpID0+IHtcbiAgICAgICAgICAgICAgaWYgKGUudGFyZ2V0ID09PSBlLmN1cnJlbnRUYXJnZXQpIHNldElzQ292ZXJNb2RhbE9wZW4oZmFsc2UpO1xuICAgICAgICAgICAgfX1cbiAgICAgICAgICAgIGNsYXNzTmFtZT1cImZpeGVkIGluc2V0LTAgei01MCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBwLTQgYmctYmxhY2svNzUgYmFja2Ryb3AtYmx1ci1tZFwiXG4gICAgICAgICAgPlxuICAgICAgICAgICAgPG1vdGlvbi5kaXZcbiAgICAgICAgICAgICAgaW5pdGlhbD17eyBvcGFjaXR5OiAwLCB5OiA0NCwgc2NhbGU6IDAuOTQgfX1cbiAgICAgICAgICAgICAgYW5pbWF0ZT17eyBvcGFjaXR5OiAxLCB5OiAwLCBzY2FsZTogMSB9fVxuICAgICAgICAgICAgICBleGl0PXt7IG9wYWNpdHk6IDAsIHk6IDMwLCBzY2FsZTogMC45NSB9fVxuICAgICAgICAgICAgICB0cmFuc2l0aW9uPXt7IHR5cGU6ICdzcHJpbmcnLCBkYW1waW5nOiAyNywgc3RpZmZuZXNzOiAzMzAsIG1hc3M6IDAuOCB9fVxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgcm91bmRlZC0zeGwgdy1mdWxsIG1heC13LW1kIHAtNiBzaGFkb3ctMnhsIHJlbGF0aXZlIG1heC1oLVs5MHZoXSBvdmVyZmxvdy15LWF1dG9cIlxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICBcbiAgICAgICAgICAgICAgey8qIE1vZGFsIEhlYWRlciAqL31cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gcGItNCBib3JkZXItYiBib3JkZXItc2xhdGUtODAwIG1iLTVcIj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yLjVcIj5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy04IGgtOCByb3VuZGVkLWxnIGJnLWJsdWUtNTAwLzEwIGJvcmRlciBib3JkZXItYmx1ZS01MDAvMjAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgdGV4dC1ibHVlLTQwMFwiPlxuICAgICAgICAgICAgICAgICAgICA8UGFsZXR0ZSBjbGFzc05hbWU9XCJ3LTQgaC00XCIgLz5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtYmFzZSBmb250LWJvbGQgdGV4dC13aGl0ZVwiPkN1c3RvbWl6ZSBDb3ZlciAmIEFwcGVhcmFuY2U8L2gzPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldElzQ292ZXJNb2RhbE9wZW4oZmFsc2UpfVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy04IGgtOCByb3VuZGVkLWZ1bGwgYmctc2xhdGUtODAwIHRleHQtc2xhdGUtNDAwIGhvdmVyOnRleHQtd2hpdGUgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgdHJhbnNpdGlvbi1jb2xvcnMgY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgICAgICAgICAgYXJpYS1sYWJlbD1cIkNsb3NlIE1vZGFsXCJcbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICA8WCBjbGFzc05hbWU9XCJ3LTQgaC00XCIgLz5cbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgey8qIFF1aWNrIFN3aXRjaCB0byBQcm9maWxlIFBpY3R1cmUgKi99XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItNSBwLTMuNSBiZy1zbGF0ZS05NTAvNzAgcm91bmRlZC0yeGwgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuXCI+XG4gICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1ib2xkIHRleHQtd2hpdGUgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNVwiPlxuICAgICAgICAgICAgICAgICAgICA8VXNlciBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNSB0ZXh0LWJsdWUtNDAwXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgUHJvZmlsZSBQaWN0dXJlXG4gICAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSB0ZXh0LXNsYXRlLTQwMFwiPlxuICAgICAgICAgICAgICAgICAgICB7YXZhdGFyVXJsID8gJ0N1c3RvbSBwaG90byBhY3RpdmUnIDogJ0RlZmF1bHQgXCJBUlwiIGluaXRpYWxzJ31cbiAgICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgIHNldElzQ292ZXJNb2RhbE9wZW4oZmFsc2UpO1xuICAgICAgICAgICAgICAgICAgICBzZXRJc0F2YXRhck1vZGFsT3Blbih0cnVlKTtcbiAgICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC0zIHB5LTEuNSByb3VuZGVkLXhsIHRleHQteHMgZm9udC1zZW1pYm9sZCBiZy1ibHVlLTYwMC8yMCBob3ZlcjpiZy1ibHVlLTYwMC8zMCB0ZXh0LWJsdWUtMzAwIGJvcmRlciBib3JkZXItYmx1ZS01MDAvMzAgdHJhbnNpdGlvbi1hbGwgY3Vyc29yLXBvaW50ZXIgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTFcIlxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgIDxDYW1lcmEgY2xhc3NOYW1lPVwidy0zIGgtM1wiIC8+XG4gICAgICAgICAgICAgICAgICBDaGFuZ2UgUGhvdG9cbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgey8qIEdsb3dpbmcgQ29sb3JzIFF1aWNrIFNldHRpbmcgaW4gTW9kYWwgKi99XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItNSBwLTMuNSBiZy1zbGF0ZS05NTAvNzAgcm91bmRlZC0yeGwgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuXCI+XG4gICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1ib2xkIHRleHQtd2hpdGUgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNVwiPlxuICAgICAgICAgICAgICAgICAgICA8U3BhcmtsZXMgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjUgdGV4dC1wdXJwbGUtNDAwXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgR2xvd2luZyBDb2xvciBFZmZlY3RzXG4gICAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSB0ZXh0LXNsYXRlLTQwMFwiPlxuICAgICAgICAgICAgICAgICAgICB7Z2xvd0VuYWJsZWQgPyAnTmVvbiBnbG93aW5nIGhhbG8gYW5kIGZsb2F0aW5nIG9yYnMgYXJlIGFjdGl2ZScgOiAnR2xvd2luZyBlZmZlY3RzIGFyZSBkaXNhYmxlZCBmb3IgYSBjbGVhbiBsb29rJ31cbiAgICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXt0b2dnbGVHbG93fVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgcHgtMyBweS0xLjUgcm91bmRlZC14bCB0ZXh0LXhzIGZvbnQtYm9sZCBib3JkZXIgdHJhbnNpdGlvbi1hbGwgY3Vyc29yLXBvaW50ZXIgJHtcbiAgICAgICAgICAgICAgICAgICAgZ2xvd0VuYWJsZWRcbiAgICAgICAgICAgICAgICAgICAgICA/ICdiZy1wdXJwbGUtNjAwIHRleHQtd2hpdGUgYm9yZGVyLXB1cnBsZS01MDAgaG92ZXI6YmctcHVycGxlLTUwMCdcbiAgICAgICAgICAgICAgICAgICAgICA6ICdiZy1zbGF0ZS04MDAgdGV4dC1zbGF0ZS0zMDAgYm9yZGVyLXNsYXRlLTcwMCBob3ZlcjpiZy1zbGF0ZS03MDAnXG4gICAgICAgICAgICAgICAgICB9YH1cbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICB7Z2xvd0VuYWJsZWQgPyAnR2xvdzogT04nIDogJ0dsb3c6IE9GRid9XG4gICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgIHsvKiBNb2RhbCBCb2R5IE9wdGlvbnMgKi99XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS01XCI+XG4gICAgICAgICAgICAgICAgXG4gICAgICAgICAgICAgICAgey8qIFZpZGVvIE9wdGlvbnMgU2VjdGlvbiAqL31cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtMy41IGJnLXNsYXRlLTk1MC82MCByb3VuZGVkLTJ4bCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMFwiPlxuICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQteHMgZm9udC1ib2xkIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciB0ZXh0LWluZGlnby00MDAgbWItMi41IGZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjVcIj5cbiAgICAgICAgICAgICAgICAgICAgPFZpZGVvIGNsYXNzTmFtZT1cInctMy41IGgtMy41XCIgLz4gQ292ZXIgVmlkZW8gT3B0aW9uXG4gICAgICAgICAgICAgICAgICA8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTNcIj5cbiAgICAgICAgICAgICAgICAgICAgey8qIFZpZGVvIEZpbGUgVXBsb2FkICovfVxuICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgdy1mdWxsIGgtMjAgYm9yZGVyLTIgYm9yZGVyLWRhc2hlZCBib3JkZXItc2xhdGUtNzAwIGhvdmVyOmJvcmRlci1pbmRpZ28tNTAwIHJvdW5kZWQteGwgY3Vyc29yLXBvaW50ZXIgYmctc2xhdGUtOTAwLzUwIGhvdmVyOmJnLXNsYXRlLTgwMC80MCB0cmFuc2l0aW9uLWFsbCBncm91cFwiPlxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcHQtMiBwYi0yXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8VmlkZW8gY2xhc3NOYW1lPVwidy01IGgtNSB0ZXh0LXNsYXRlLTQwMCBncm91cC1ob3Zlcjp0ZXh0LWluZGlnby00MDAgbWItMSB0cmFuc2l0aW9uLWNvbG9yc1wiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc2xhdGUtMzAwIGZvbnQtbWVkaXVtXCI+VXBsb2FkIFZpZGVvIEZpbGU8L3A+XG4gICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSB0ZXh0LXNsYXRlLTUwMFwiPk1QNCwgV0VCTSBzdXBwb3J0ZWQ8L3A+XG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiZmlsZVwiXG4gICAgICAgICAgICAgICAgICAgICAgICBhY2NlcHQ9XCJ2aWRlby9tcDQsdmlkZW8vd2VibSx2aWRlby9vZ2dcIlxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaGlkZGVuXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVWaWRlb0ZpbGVVcGxvYWR9XG4gICAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cblxuICAgICAgICAgICAgICAgICAgICB7LyogVmlkZW8gVVJMIElucHV0ICovfVxuICAgICAgICAgICAgICAgICAgICA8Zm9ybSBvblN1Ym1pdD17aGFuZGxlQXBwbHlWaWRlb1VybH0gY2xhc3NOYW1lPVwiZmxleCBnYXAtMlwiPlxuICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInVybFwiXG4gICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17dmlkZW9VcmxJbnB1dH1cbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0VmlkZW9VcmxJbnB1dChlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cImh0dHBzOi8vZXhhbXBsZS5jb20vdmlkZW8ubXA0XCJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXgtMSBiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgcm91bmRlZC14bCBweC0zIHB5LTIgdGV4dC14cyB0ZXh0LXdoaXRlIHBsYWNlaG9sZGVyLXNsYXRlLTUwMCBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6Ym9yZGVyLWluZGlnby01MDAgdHJhbnNpdGlvbi1jb2xvcnNcIlxuICAgICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInN1Ym1pdFwiXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1pbmRpZ28tNjAwIGhvdmVyOmJnLWluZGlnby01MDAgdGV4dC13aGl0ZSB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgcHgtMy41IHB5LTIgcm91bmRlZC14bCB0cmFuc2l0aW9uLWNvbG9ycyBzaHJpbmstMCBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgQXBwbHkgVmlkZW9cbiAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgPC9mb3JtPlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICB7LyogSW1hZ2UgT3B0aW9ucyBTZWN0aW9uICovfVxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC0zLjUgYmctc2xhdGUtOTUwLzYwIHJvdW5kZWQtMnhsIGJvcmRlciBib3JkZXItc2xhdGUtODAwXCI+XG4gICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC14cyBmb250LWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIHRleHQtYmx1ZS00MDAgbWItMi41IGZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjVcIj5cbiAgICAgICAgICAgICAgICAgICAgPEltYWdlSWNvbiBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNVwiIC8+IENvdmVyIEltYWdlIE9wdGlvblxuICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0zXCI+XG4gICAgICAgICAgICAgICAgICAgIHsvKiBJbWFnZSBGaWxlIFVwbG9hZCAqL31cbiAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHctZnVsbCBoLTIwIGJvcmRlci0yIGJvcmRlci1kYXNoZWQgYm9yZGVyLXNsYXRlLTcwMCBob3Zlcjpib3JkZXItYmx1ZS01MDAgcm91bmRlZC14bCBjdXJzb3ItcG9pbnRlciBiZy1zbGF0ZS05MDAvNTAgaG92ZXI6Ymctc2xhdGUtODAwLzQwIHRyYW5zaXRpb24tYWxsIGdyb3VwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBwdC0yIHBiLTJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxDYW1lcmEgY2xhc3NOYW1lPVwidy01IGgtNSB0ZXh0LXNsYXRlLTQwMCBncm91cC1ob3Zlcjp0ZXh0LWJsdWUtNDAwIG1iLTEgdHJhbnNpdGlvbi1jb2xvcnNcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXNsYXRlLTMwMCBmb250LW1lZGl1bVwiPlVwbG9hZCBJbWFnZSBGaWxlPC9wPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gdGV4dC1zbGF0ZS01MDBcIj5QTkcsIEpQRywgV0VCUCBzdXBwb3J0ZWQ8L3A+XG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiZmlsZVwiXG4gICAgICAgICAgICAgICAgICAgICAgICBhY2NlcHQ9XCJpbWFnZS8qXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImhpZGRlblwiXG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlSW1hZ2VGaWxlVXBsb2FkfVxuICAgICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XG5cbiAgICAgICAgICAgICAgICAgICAgey8qIEltYWdlIFVSTCBJbnB1dCAqL31cbiAgICAgICAgICAgICAgICAgICAgPGZvcm0gb25TdWJtaXQ9e2hhbmRsZUFwcGx5SW1hZ2VVcmx9IGNsYXNzTmFtZT1cImZsZXggZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ1cmxcIlxuICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2ltYWdlVXJsSW5wdXR9XG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldEltYWdlVXJsSW5wdXQoZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJodHRwczovL2V4YW1wbGUuY29tL2ltYWdlLmpwZ1wiXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4LTEgYmctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIHJvdW5kZWQteGwgcHgtMyBweS0yIHRleHQteHMgdGV4dC13aGl0ZSBwbGFjZWhvbGRlci1zbGF0ZS01MDAgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOmJvcmRlci1ibHVlLTUwMCB0cmFuc2l0aW9uLWNvbG9yc1wiXG4gICAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwic3VibWl0XCJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWJsdWUtNjAwIGhvdmVyOmJnLWJsdWUtNTAwIHRleHQtd2hpdGUgdGV4dC14cyBmb250LXNlbWlib2xkIHB4LTMuNSBweS0yIHJvdW5kZWQteGwgdHJhbnNpdGlvbi1jb2xvcnMgc2hyaW5rLTAgY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgIEFwcGx5IEltYWdlXG4gICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgIDwvZm9ybT5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgey8qIFByZXNldCBUaGVtZXMgKi99XG4gICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXhzIGZvbnQtYm9sZCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgdGV4dC1zbGF0ZS00MDAgbWItMlwiPlxuICAgICAgICAgICAgICAgICAgICBQcmVzZXQgVGhlbWVzXG4gICAgICAgICAgICAgICAgICA8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0zIGdhcC0yLjVcIj5cbiAgICAgICAgICAgICAgICAgICAge1BSRVNFVF9HUkFESUVOVFMubWFwKChwcmVzZXQpID0+IChcbiAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICBrZXk9e3ByZXNldC5pZH1cbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZVNlbGVjdFByZXNldChwcmVzZXQuY2xhc3MpfVxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgaC0xMiByb3VuZGVkLXhsICR7cHJlc2V0LmNsYXNzfSBib3JkZXItMiB0cmFuc2l0aW9uLWFsbCBzaGFkb3ctc20gZmxleCBpdGVtcy1lbmQgcC0xLjUgY3Vyc29yLXBvaW50ZXIgdGV4dC1sZWZ0ICR7XG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNvdmVyQ29uZmlnLnR5cGUgPT09ICdncmFkaWVudCcgJiYgY292ZXJDb25maWcudmFsdWUgPT09IHByZXNldC5jbGFzc1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gJ2JvcmRlci13aGl0ZSByaW5nLTIgcmluZy1ibHVlLTUwMC81MCdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA6ICdib3JkZXItdHJhbnNwYXJlbnQgaG92ZXI6Ym9yZGVyLXNsYXRlLTQwMCdcbiAgICAgICAgICAgICAgICAgICAgICAgIH1gfVxuICAgICAgICAgICAgICAgICAgICAgICAgdGl0bGU9e3ByZXNldC5uYW1lfVxuICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzlweF0gZm9udC1ib2xkIHRleHQtd2hpdGUvOTAgZHJvcC1zaGFkb3ctc20gdHJ1bmNhdGVcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAge3ByZXNldC5uYW1lfVxuICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgIHsvKiBNb2RhbCBGb290ZXIgQWN0aW9ucyAqL31cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC02IHB0LTQgYm9yZGVyLXQgYm9yZGVyLXNsYXRlLTgwMCBmbGV4IGp1c3RpZnktYmV0d2VlbiBpdGVtcy1jZW50ZXJcIj5cbiAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVSZXNldENvdmVyfVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtcm9zZS00MDAgaG92ZXI6dGV4dC1yb3NlLTMwMCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICA8Um90YXRlQ2N3IGNsYXNzTmFtZT1cInctMy41IGgtMy41XCIgLz5cbiAgICAgICAgICAgICAgICAgIFJlc2V0IERlZmF1bHRcbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRJc0NvdmVyTW9kYWxPcGVuKGZhbHNlKX1cbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLXNsYXRlLTgwMCBob3ZlcjpiZy1zbGF0ZS03MDAgdGV4dC1zbGF0ZS0yMDAgdGV4dC14cyBmb250LXNlbWlib2xkIHB4LTQgcHktMiByb3VuZGVkLXhsIHRyYW5zaXRpb24tY29sb3JzIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICBEb25lXG4gICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICA8L21vdGlvbi5kaXY+XG4gICAgICAgICAgPC9tb3Rpb24uZGl2PlxuICAgICAgICApfVxuICAgICAgPC9BbmltYXRlUHJlc2VuY2U+XG5cbiAgICAgIHsvKiBRUiBDb2RlIFF1aWNrIFZpZXcgTW9kYWwgKi99XG4gICAgICA8QW5pbWF0ZVByZXNlbmNlPlxuICAgICAgICB7aXNRck1vZGFsT3BlbiAmJiAoXG4gICAgICAgICAgPG1vdGlvbi5kaXZcbiAgICAgICAgICAgIGluaXRpYWw9e3sgb3BhY2l0eTogMCB9fVxuICAgICAgICAgICAgYW5pbWF0ZT17eyBvcGFjaXR5OiAxIH19XG4gICAgICAgICAgICBleGl0PXt7IG9wYWNpdHk6IDAgfX1cbiAgICAgICAgICAgIHRyYW5zaXRpb249e3sgZHVyYXRpb246IDAuMjQsIGVhc2U6ICdlYXNlT3V0JyB9fVxuICAgICAgICAgICAgb25DbGljaz17KGUpID0+IHtcbiAgICAgICAgICAgICAgaWYgKGUudGFyZ2V0ID09PSBlLmN1cnJlbnRUYXJnZXQpIHNldElzUXJNb2RhbE9wZW4oZmFsc2UpO1xuICAgICAgICAgICAgfX1cbiAgICAgICAgICAgIGNsYXNzTmFtZT1cImZpeGVkIGluc2V0LTAgei01MCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBwLTQgYmctYmxhY2svNzUgYmFja2Ryb3AtYmx1ci1tZFwiXG4gICAgICAgICAgPlxuICAgICAgICAgICAgPG1vdGlvbi5kaXZcbiAgICAgICAgICAgICAgaW5pdGlhbD17eyBvcGFjaXR5OiAwLCB5OiA0NCwgc2NhbGU6IDAuOTQgfX1cbiAgICAgICAgICAgICAgYW5pbWF0ZT17eyBvcGFjaXR5OiAxLCB5OiAwLCBzY2FsZTogMSB9fVxuICAgICAgICAgICAgICBleGl0PXt7IG9wYWNpdHk6IDAsIHk6IDMwLCBzY2FsZTogMC45NSB9fVxuICAgICAgICAgICAgICB0cmFuc2l0aW9uPXt7IHR5cGU6ICdzcHJpbmcnLCBkYW1waW5nOiAyNywgc3RpZmZuZXNzOiAzMzAsIG1hc3M6IDAuOCB9fVxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgcm91bmRlZC0zeGwgdy1mdWxsIG1heC13LXNtIHAtNiBzaGFkb3ctMnhsIHJlbGF0aXZlIHRleHQtY2VudGVyXCJcbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gcGItMyBib3JkZXItYiBib3JkZXItc2xhdGUtODAwIG1iLTRcIj5cbiAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LWJvbGQgdGV4dC13aGl0ZSBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgICAgICAgICAgPFFyQ29kZSBjbGFzc05hbWU9XCJ3LTQgaC00IHRleHQtYmx1ZS00MDBcIiAvPlxuICAgICAgICAgICAgICAgICAgUHJvZmlsZSBRUiBDb2RlXG4gICAgICAgICAgICAgICAgPC9oMz5cbiAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRJc1FyTW9kYWxPcGVuKGZhbHNlKX1cbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctNyBoLTcgcm91bmRlZC1mdWxsIGJnLXNsYXRlLTgwMCB0ZXh0LXNsYXRlLTQwMCBob3Zlcjp0ZXh0LXdoaXRlIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICA8WCBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNVwiIC8+XG4gICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgIHsvKiBDbGVhbiBTVkcgUVIgQ29kZSAqL31cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSBwLTQgcm91bmRlZC0yeGwgaW5saW5lLWJsb2NrIG1iLTMgc2hhZG93LWxnXCI+XG4gICAgICAgICAgICAgICAgPGltZ1xuICAgICAgICAgICAgICAgICAgc3JjPXtgaHR0cHM6Ly9hcGkucXJzZXJ2ZXIuY29tL3YxL2NyZWF0ZS1xci1jb2RlLz9zaXplPTE4MHgxODAmZGF0YT0ke2VuY29kZVVSSUNvbXBvbmVudChcbiAgICAgICAgICAgICAgICAgICAgdHlwZW9mIHdpbmRvdyAhPT0gJ3VuZGVmaW5lZCcgPyB3aW5kb3cubG9jYXRpb24uaHJlZiA6ICdodHRwczovL2FsYmVydHJvYmxlZG8uY29tJ1xuICAgICAgICAgICAgICAgICAgKX1gfVxuICAgICAgICAgICAgICAgICAgYWx0PVwiQWxiZXJ0IFJvYmxlZG8gUHJvZmlsZSBRUiBDb2RlXCJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctNDQgaC00NCBvYmplY3QtY29udGFpblwiXG4gICAgICAgICAgICAgICAgICBvbkVycm9yPXsoZSkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAoZS50YXJnZXQgYXMgSFRNTEltYWdlRWxlbWVudCkuc3R5bGUuZGlzcGxheSA9ICdub25lJztcbiAgICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LWJvbGQgdGV4dC13aGl0ZSBtYi0wLjVcIj5TY2FuIHRvIGNvbm5lY3Qgd2l0aCBBbGJlcnQ8L3A+XG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIHRleHQtc2xhdGUtNDAwIG1iLTRcIj5PcGVucyBkaXJlY3QgbGluayB0byBwcm9maWxlICYgc29jaWFsIGNvbnRhY3RzPC9wPlxuXG4gICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XG4gICAgICAgICAgICAgICAgICBoYW5kbGVTaGFyZVByb2ZpbGUoKTtcbiAgICAgICAgICAgICAgICAgIHNldElzUXJNb2RhbE9wZW4oZmFsc2UpO1xuICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB5LTIgcHgtNCByb3VuZGVkLXhsIGJnLWJsdWUtNjAwIGhvdmVyOmJnLWJsdWUtNTAwIHRleHQtd2hpdGUgdGV4dC14cyBmb250LXNlbWlib2xkIHRyYW5zaXRpb24tYWxsIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIENvcHkgLyBTaGFyZSBMaW5rIEluc3RlYWRcbiAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICA8L21vdGlvbi5kaXY+XG4gICAgICAgICAgPC9tb3Rpb24uZGl2PlxuICAgICAgICApfVxuICAgICAgPC9BbmltYXRlUHJlc2VuY2U+XG5cbiAgICAgIHsvKiBQcm9qZWN0IERvd25sb2FkIE1vZGFsICovfVxuICAgICAgPEFuaW1hdGVQcmVzZW5jZT5cbiAgICAgICAge2lzRG93bmxvYWRNb2RhbE9wZW4gJiYgKFxuICAgICAgICAgIDxtb3Rpb24uZGl2XG4gICAgICAgICAgICBpbml0aWFsPXt7IG9wYWNpdHk6IDAgfX1cbiAgICAgICAgICAgIGFuaW1hdGU9e3sgb3BhY2l0eTogMSB9fVxuICAgICAgICAgICAgZXhpdD17eyBvcGFjaXR5OiAwIH19XG4gICAgICAgICAgICB0cmFuc2l0aW9uPXt7IGR1cmF0aW9uOiAwLjI0LCBlYXNlOiAnZWFzZU91dCcgfX1cbiAgICAgICAgICAgIG9uQ2xpY2s9eyhlKSA9PiB7XG4gICAgICAgICAgICAgIGlmIChlLnRhcmdldCA9PT0gZS5jdXJyZW50VGFyZ2V0KSBzZXRJc0Rvd25sb2FkTW9kYWxPcGVuKGZhbHNlKTtcbiAgICAgICAgICAgIH19XG4gICAgICAgICAgICBjbGFzc05hbWU9XCJmaXhlZCBpbnNldC0wIHotNTAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcC00IGJnLWJsYWNrLzc1IGJhY2tkcm9wLWJsdXItbWRcIlxuICAgICAgICAgID5cbiAgICAgICAgICAgIDxtb3Rpb24uZGl2XG4gICAgICAgICAgICAgIGluaXRpYWw9e3sgb3BhY2l0eTogMCwgeTogNDQsIHNjYWxlOiAwLjk0IH19XG4gICAgICAgICAgICAgIGFuaW1hdGU9e3sgb3BhY2l0eTogMSwgeTogMCwgc2NhbGU6IDEgfX1cbiAgICAgICAgICAgICAgZXhpdD17eyBvcGFjaXR5OiAwLCB5OiAzMCwgc2NhbGU6IDAuOTUgfX1cbiAgICAgICAgICAgICAgdHJhbnNpdGlvbj17eyB0eXBlOiAnc3ByaW5nJywgZGFtcGluZzogMjcsIHN0aWZmbmVzczogMzMwLCBtYXNzOiAwLjggfX1cbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIHJvdW5kZWQtM3hsIHctZnVsbCBtYXgtdy1tZCBwLTYgc2hhZG93LTJ4bCByZWxhdGl2ZSBtYXgtaC1bOTB2aF0gb3ZlcmZsb3cteS1hdXRvXCJcbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gcGItMy41IGJvcmRlci1iIGJvcmRlci1zbGF0ZS04MDAgbWItNVwiPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIuNVwiPlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTggaC04IHJvdW5kZWQtbGcgYmctZW1lcmFsZC01MDAvMTUgYm9yZGVyIGJvcmRlci1lbWVyYWxkLTUwMC8zMCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciB0ZXh0LWVtZXJhbGQtNDAwXCI+XG4gICAgICAgICAgICAgICAgICAgIDxEb3dubG9hZCBjbGFzc05hbWU9XCJ3LTQgaC00XCIgLz5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LWxlZnRcIj5cbiAgICAgICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtYmFzZSBmb250LWJvbGQgdGV4dC13aGl0ZVwiPkRvd25sb2FkIFByb2plY3QgRmlsZXM8L2gzPlxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSB0ZXh0LXNsYXRlLTQwMFwiPkNob29zZSB5b3VyIHByZWZlcnJlZCBkb3dubG9hZCBmb3JtYXQ8L3A+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRJc0Rvd25sb2FkTW9kYWxPcGVuKGZhbHNlKX1cbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctOCBoLTggcm91bmRlZC1mdWxsIGJnLXNsYXRlLTgwMCB0ZXh0LXNsYXRlLTQwMCBob3Zlcjp0ZXh0LXdoaXRlIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHRyYW5zaXRpb24tY29sb3JzIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgICAgICAgIGFyaWEtbGFiZWw9XCJDbG9zZSBNb2RhbFwiXG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgPFggY2xhc3NOYW1lPVwidy00IGgtNFwiIC8+XG4gICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0zLjUgdGV4dC1sZWZ0XCI+XG4gICAgICAgICAgICAgICAgey8qIE9wdGlvbiAxOiBGdWxsIFJlYWN0IFNvdXJjZSBQcm9qZWN0IFpJUCAqL31cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNCByb3VuZGVkLTJ4bCBiZy1zbGF0ZS05NTAvNzAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgaG92ZXI6Ym9yZGVyLWVtZXJhbGQtNTAwLzQwIHRyYW5zaXRpb24tYWxsIGZsZXggZmxleC1jb2wgZ2FwLTMgZ3JvdXBcIj5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1zdGFydCBnYXAtMy41XCI+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xMCBoLTEwIHJvdW5kZWQteGwgYmctZW1lcmFsZC01MDAvMTUgYm9yZGVyIGJvcmRlci1lbWVyYWxkLTUwMC8zMCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciB0ZXh0LWVtZXJhbGQtNDAwIHNocmluay0wXCI+XG4gICAgICAgICAgICAgICAgICAgICAgPEZpbGVBcmNoaXZlIGNsYXNzTmFtZT1cInctNSBoLTVcIiAvPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LTEgbWluLXctMFwiPlxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgbWItMC41XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8aDQgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LWJvbGQgdGV4dC13aGl0ZSBncm91cC1ob3Zlcjp0ZXh0LWVtZXJhbGQtMzAwIHRyYW5zaXRpb24tY29sb3JzXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIENvbXBsZXRlIFByb2plY3QgKC5aSVApXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2g0PlxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bOXB4XSB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgZm9udC1leHRyYWJvbGQgcHgtMS41IHB5LTAuNSByb3VuZGVkIGJnLWVtZXJhbGQtNTAwLzIwIHRleHQtZW1lcmFsZC00MDAgYm9yZGVyIGJvcmRlci1lbWVyYWxkLTUwMC8zMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICBSZWNvbW1lbmRlZFxuICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1zbGF0ZS00MDAgbGVhZGluZy1yZWxheGVkXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICBGdWxsIFJlYWN0IDE5ICsgVml0ZSArIFRhaWx3aW5kIHNvdXJjZSBjb2RlIHdpdGggPGNvZGUgY2xhc3NOYW1lPVwidGV4dC1lbWVyYWxkLTQwMFwiPnBhY2thZ2UuanNvbjwvY29kZT4gYW5kIGluc3RydWN0aW9ucyB0byBydW4gbG9jYWxseSBvciBkZXBsb3kgYW55d2hlcmUuXG4gICAgICAgICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZURvd25sb2FkWmlwfVxuICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17aXNEb3dubG9hZGluZ31cbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB5LTIuNSBweC00IHJvdW5kZWQteGwgYmctZW1lcmFsZC02MDAgaG92ZXI6YmctZW1lcmFsZC01MDAgdGV4dC13aGl0ZSB0ZXh0LXhzIGZvbnQtYm9sZCB0cmFuc2l0aW9uLWFsbCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBnYXAtMiBzaGFkb3ctbGcgc2hhZG93LWVtZXJhbGQtOTUwLzUwIGN1cnNvci1wb2ludGVyIGRpc2FibGVkOm9wYWNpdHktNTBcIlxuICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICB7aXNEb3dubG9hZGluZyA/IChcbiAgICAgICAgICAgICAgICAgICAgICA8PlxuICAgICAgICAgICAgICAgICAgICAgICAgPExvYWRlcjIgY2xhc3NOYW1lPVwidy00IGgtNCBhbmltYXRlLXNwaW5cIiAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgR2VuZXJhdGluZyBaSVAgQnVuZGxlLi4uXG4gICAgICAgICAgICAgICAgICAgICAgPC8+XG4gICAgICAgICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgICAgICAgPD5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxEb3dubG9hZCBjbGFzc05hbWU9XCJ3LTQgaC00XCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgIERvd25sb2FkIEZ1bGwgUHJvamVjdCAoLlpJUClcbiAgICAgICAgICAgICAgICAgICAgICA8Lz5cbiAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgey8qIE9wdGlvbiAyOiBTaW5nbGUtRmlsZSBTdGFuZGFsb25lIEhUTUwgKi99XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTQgcm91bmRlZC0yeGwgYmctc2xhdGUtOTUwLzcwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIGhvdmVyOmJvcmRlci1ibHVlLTUwMC80MCB0cmFuc2l0aW9uLWFsbCBmbGV4IGZsZXgtY29sIGdhcC0zIGdyb3VwXCI+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtc3RhcnQgZ2FwLTMuNVwiPlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMTAgaC0xMCByb3VuZGVkLXhsIGJnLWJsdWUtNTAwLzE1IGJvcmRlciBib3JkZXItYmx1ZS01MDAvMzAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgdGV4dC1ibHVlLTQwMCBzaHJpbmstMFwiPlxuICAgICAgICAgICAgICAgICAgICAgIDxGaWxlQ29kZSBjbGFzc05hbWU9XCJ3LTUgaC01XCIgLz5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC0xIG1pbi13LTBcIj5cbiAgICAgICAgICAgICAgICAgICAgICA8aDQgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LWJvbGQgdGV4dC13aGl0ZSBncm91cC1ob3Zlcjp0ZXh0LWJsdWUtMzAwIHRyYW5zaXRpb24tY29sb3JzIG1iLTAuNVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgU3RhbmRhbG9uZSBXZWJwYWdlICguSFRNTClcbiAgICAgICAgICAgICAgICAgICAgICA8L2g0PlxuICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1zbGF0ZS00MDAgbGVhZGluZy1yZWxheGVkXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICBBIHNpbmdsZSBzZWxmLWNvbnRhaW5lZCBIVE1MIGZpbGUuIEp1c3QgZG91YmxlLWNsaWNrIGl0IHRvIG9wZW4gb2ZmbGluZSBpbiBhbnkgYnJvd3NlciBhbnl3aGVyZSB3aXRob3V0IGluc3RhbGxpbmcgYW55dGhpbmcuXG4gICAgICAgICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZURvd25sb2FkSHRtbH1cbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB5LTIuNSBweC00IHJvdW5kZWQteGwgYmctYmx1ZS02MDAgaG92ZXI6YmctYmx1ZS01MDAgdGV4dC13aGl0ZSB0ZXh0LXhzIGZvbnQtYm9sZCB0cmFuc2l0aW9uLWFsbCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBnYXAtMiBzaGFkb3ctbGcgc2hhZG93LWJsdWUtOTUwLzUwIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgPERvd25sb2FkIGNsYXNzTmFtZT1cInctNCBoLTRcIiAvPlxuICAgICAgICAgICAgICAgICAgICBEb3dubG9hZCBTdGFuZGFsb25lICguSFRNTClcbiAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgey8qIE9wdGlvbiAzOiBDb250YWN0IHZDYXJkICovfVxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC00IHJvdW5kZWQtMnhsIGJnLXNsYXRlLTk1MC83MCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCBob3Zlcjpib3JkZXItcHVycGxlLTUwMC80MCB0cmFuc2l0aW9uLWFsbCBmbGV4IGZsZXgtY29sIGdhcC0zIGdyb3VwXCI+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtc3RhcnQgZ2FwLTMuNVwiPlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMTAgaC0xMCByb3VuZGVkLXhsIGJnLXB1cnBsZS01MDAvMTUgYm9yZGVyIGJvcmRlci1wdXJwbGUtNTAwLzMwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHRleHQtcHVycGxlLTQwMCBzaHJpbmstMFwiPlxuICAgICAgICAgICAgICAgICAgICAgIDxDb250YWN0IGNsYXNzTmFtZT1cInctNSBoLTVcIiAvPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LTEgbWluLXctMFwiPlxuICAgICAgICAgICAgICAgICAgICAgIDxoNCBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtYm9sZCB0ZXh0LXdoaXRlIGdyb3VwLWhvdmVyOnRleHQtcHVycGxlLTMwMCB0cmFuc2l0aW9uLWNvbG9ycyBtYi0wLjVcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIENvbnRhY3QgQ2FyZCAoLlZDRilcbiAgICAgICAgICAgICAgICAgICAgICA8L2g0PlxuICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1zbGF0ZS00MDAgbGVhZGluZy1yZWxheGVkXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICBEaXJlY3QgY29udGFjdCBjYXJkIGZpbGUuIE9wZW5zIGltbWVkaWF0ZWx5IG9uIHBob25lIGFkZHJlc3MgYm9va3MgdG8gc2F2ZSBBbGJlcnQgUm9ibGVkbydzIGNvbnRhY3QuXG4gICAgICAgICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZURvd25sb2FkQ29udGFjdH1cbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB5LTIuNSBweC00IHJvdW5kZWQteGwgYmctcHVycGxlLTYwMCBob3ZlcjpiZy1wdXJwbGUtNTAwIHRleHQtd2hpdGUgdGV4dC14cyBmb250LWJvbGQgdHJhbnNpdGlvbi1hbGwgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZ2FwLTIgc2hhZG93LWxnIHNoYWRvdy1wdXJwbGUtOTUwLzUwIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgPERvd25sb2FkIGNsYXNzTmFtZT1cInctNCBoLTRcIiAvPlxuICAgICAgICAgICAgICAgICAgICBEb3dubG9hZCBDb250YWN0ICguVkNGKVxuICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtNSBwdC0zLjUgYm9yZGVyLXQgYm9yZGVyLXNsYXRlLTgwMCBmbGV4IGp1c3RpZnktZW5kXCI+XG4gICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0SXNEb3dubG9hZE1vZGFsT3BlbihmYWxzZSl9XG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1zbGF0ZS04MDAgaG92ZXI6Ymctc2xhdGUtNzAwIHRleHQtc2xhdGUtMzAwIHRleHQteHMgZm9udC1zZW1pYm9sZCBweC00IHB5LTIgcm91bmRlZC14bCB0cmFuc2l0aW9uLWNvbG9ycyBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgQ2xvc2VcbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L21vdGlvbi5kaXY+XG4gICAgICAgICAgPC9tb3Rpb24uZGl2PlxuICAgICAgICApfVxuICAgICAgPC9BbmltYXRlUHJlc2VuY2U+XG5cbiAgICAgIHsvKiBUb2FzdCBQb3B1cCBOb3RpZmljYXRpb24gKi99XG4gICAgICA8QW5pbWF0ZVByZXNlbmNlPlxuICAgICAgICB7dG9hc3QgJiYgKFxuICAgICAgICAgIDxtb3Rpb24uZGl2XG4gICAgICAgICAgICBpbml0aWFsPXt7IG9wYWNpdHk6IDAsIHk6IDI0LCBzY2FsZTogMC45NSB9fVxuICAgICAgICAgICAgYW5pbWF0ZT17eyBvcGFjaXR5OiAxLCB5OiAwLCBzY2FsZTogMSB9fVxuICAgICAgICAgICAgZXhpdD17eyBvcGFjaXR5OiAwLCB5OiAxNiwgc2NhbGU6IDAuOTYgfX1cbiAgICAgICAgICAgIHRyYW5zaXRpb249e3sgdHlwZTogJ3NwcmluZycsIGRhbXBpbmc6IDI1LCBzdGlmZm5lc3M6IDM1MCB9fVxuICAgICAgICAgICAgY2xhc3NOYW1lPVwiZml4ZWQgYm90dG9tLTYgbGVmdC0xLzIgLXRyYW5zbGF0ZS14LTEvMiBiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS03MDAgdGV4dC13aGl0ZSB0ZXh0LXhzIGZvbnQtbWVkaXVtIHB4LTQgcHktMi41IHJvdW5kZWQtMnhsIHNoYWRvdy0yeGwgYmFja2Ryb3AtYmx1ci1tZCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMi41IHotNTBcIlxuICAgICAgICAgID5cbiAgICAgICAgICAgIHt0b2FzdC50eXBlID09PSAnZXJyb3InID8gKFxuICAgICAgICAgICAgICA8QWxlcnRDaXJjbGUgY2xhc3NOYW1lPVwidy00IGgtNCB0ZXh0LXJvc2UtNDAwIHNocmluay0wXCIgLz5cbiAgICAgICAgICAgICkgOiB0b2FzdC50eXBlID09PSAnaW5mbycgPyAoXG4gICAgICAgICAgICAgIDxTcGFya2xlcyBjbGFzc05hbWU9XCJ3LTQgaC00IHRleHQtcHVycGxlLTQwMCBzaHJpbmstMFwiIC8+XG4gICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICA8Q2hlY2tDaXJjbGUyIGNsYXNzTmFtZT1cInctNCBoLTQgdGV4dC1lbWVyYWxkLTQwMCBzaHJpbmstMFwiIC8+XG4gICAgICAgICAgICApfVxuICAgICAgICAgICAgPHNwYW4+e3RvYXN0Lm1lc3NhZ2V9PC9zcGFuPlxuICAgICAgICAgIDwvbW90aW9uLmRpdj5cbiAgICAgICAgKX1cbiAgICAgIDwvQW5pbWF0ZVByZXNlbmNlPlxuXG4gICAgICB7LyogXCJGb2xsb3cgbWUgb24gc29jaWFsXCIgRW5nYWdlbWVudCBUb2FzdCAtIGFwcGVhcnMgNXMgYWZ0ZXIgcGFnZSBsb2FkICovfVxuICAgICAgPEFuaW1hdGVQcmVzZW5jZT5cbiAgICAgICAge3Nob3dTb2NpYWxUb2FzdCAmJiAoXG4gICAgICAgICAgPG1vdGlvbi5kaXZcbiAgICAgICAgICAgIGluaXRpYWw9e3sgb3BhY2l0eTogMCwgeTogNDQsIHNjYWxlOiAwLjk0IH19XG4gICAgICAgICAgICBhbmltYXRlPXt7IG9wYWNpdHk6IDEsIHk6IDAsIHNjYWxlOiAxIH19XG4gICAgICAgICAgICBleGl0PXt7IG9wYWNpdHk6IDAsIHk6IDI4LCBzY2FsZTogMC45NSB9fVxuICAgICAgICAgICAgdHJhbnNpdGlvbj17eyB0eXBlOiAnc3ByaW5nJywgZGFtcGluZzogMjYsIHN0aWZmbmVzczogMzIwLCBtYXNzOiAwLjggfX1cbiAgICAgICAgICAgIGNsYXNzTmFtZT17YGZpeGVkIGJvdHRvbS01IHNtOmJvdHRvbS02IHJpZ2h0LTMgc206cmlnaHQtNiBsZWZ0LTMgc206bGVmdC1hdXRvIHNtOnctOTYgei00MCBwLTQgcm91bmRlZC0yeGwgZ2xhc3MtY2FyZCBiYWNrZHJvcC1ibHVyLXhsIGJvcmRlciBzaGFkb3ctMnhsIHRyYW5zaXRpb24tYWxsICR7XG4gICAgICAgICAgICAgIGdsb3dFbmFibGVkXG4gICAgICAgICAgICAgICAgPyAnYm9yZGVyLXB1cnBsZS01MDAvMzAgcmluZy0xIHJpbmctcHVycGxlLTUwMC8yMCBzaGFkb3ctcHVycGxlLTk1MC81MCdcbiAgICAgICAgICAgICAgICA6ICdib3JkZXItc2xhdGUtODAwIGJnLXNsYXRlLTkwMC85NSBzaGFkb3ctYmxhY2svNjAnXG4gICAgICAgICAgICB9YH1cbiAgICAgICAgICA+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtc3RhcnQganVzdGlmeS1iZXR3ZWVuIGdhcC0zIG1iLTIuNVwiPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yLjVcIj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlXCI+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctOSBoLTkgcm91bmRlZC1mdWxsIGJnLWdyYWRpZW50LXRvLXRyIGZyb20tcHVycGxlLTYwMCB2aWEtcGluay02MDAgdG8tYmx1ZS01MDAgcC0wLjUgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXJcIj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGwgaC1mdWxsIHJvdW5kZWQtZnVsbCBiZy1zbGF0ZS05NTAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgb3ZlcmZsb3ctaGlkZGVuXCI+XG4gICAgICAgICAgICAgICAgICAgICAge2F2YXRhclVybCA/IChcbiAgICAgICAgICAgICAgICAgICAgICAgIDxpbWcgc3JjPXthdmF0YXJVcmx9IGFsdD1cIkFsYmVydFwiIGNsYXNzTmFtZT1cInctZnVsbCBoLWZ1bGwgb2JqZWN0LWNvdmVyXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gZm9udC1ibGFjayB0ZXh0LXRyYW5zcGFyZW50IGJnLWNsaXAtdGV4dCBiZy1ncmFkaWVudC10by1yIGZyb20tYmx1ZS00MDAgdG8tcHVycGxlLTQwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICBBUlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJhYnNvbHV0ZSAtdG9wLTAuNSAtcmlnaHQtMC41IHctMi41IGgtMi41IGJnLWVtZXJhbGQtNDAwIGJvcmRlci0yIGJvcmRlci1zbGF0ZS05NTAgcm91bmRlZC1mdWxsIGFuaW1hdGUtcHVsc2VcIiAvPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICA8aDQgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LWJvbGQgdGV4dC13aGl0ZSBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41XCI+XG4gICAgICAgICAgICAgICAgICAgIEZvbGxvdyBtZSBvbiBzb2NpYWwhXG4gICAgICAgICAgICAgICAgICAgIDxTcGFya2xlcyBjbGFzc05hbWU9XCJ3LTMgaC0zIHRleHQtcHVycGxlLTQwMFwiIC8+XG4gICAgICAgICAgICAgICAgICA8L2g0PlxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gdGV4dC1zbGF0ZS00MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgU3RheSB1cGRhdGVkIHdpdGggQWxiZXJ0IG9uIHNvY2lhbCBtZWRpYVxuICAgICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0U2hvd1NvY2lhbFRvYXN0KGZhbHNlKX1cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJwLTEgcm91bmRlZC1mdWxsIHRleHQtc2xhdGUtNDAwIGhvdmVyOnRleHQtd2hpdGUgaG92ZXI6Ymctc2xhdGUtODAwLzgwIHRyYW5zaXRpb24tY29sb3JzIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgICAgICBhcmlhLWxhYmVsPVwiRGlzbWlzcyBOb3RpZmljYXRpb25cIlxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgPFggY2xhc3NOYW1lPVwidy0zLjUgaC0zLjVcIiAvPlxuICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICB7LyogUXVpY2sgU29jaWFsIEJ1dHRvbnMgKi99XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHB0LTIgYm9yZGVyLXQgYm9yZGVyLXNsYXRlLTgwMC84MFwiPlxuICAgICAgICAgICAgICA8YVxuICAgICAgICAgICAgICAgIGhyZWY9XCJodHRwczovL3d3dy5mYWNlYm9vay5jb20vcHJvZmlsZS5waHA/aWQ9NjE1OTQyNTY1NDk5MjFcIlxuICAgICAgICAgICAgICAgIHRhcmdldD1cIl9ibGFua1wiXG4gICAgICAgICAgICAgICAgcmVsPVwibm9vcGVuZXIgbm9yZWZlcnJlclwiXG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0U2hvd1NvY2lhbFRvYXN0KGZhbHNlKX1cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4LTEgcHktMS41IHB4LTIgcm91bmRlZC14bCBiZy1bIzE4NzdGMl0vMTUgaG92ZXI6YmctWyMxODc3RjJdLzI1IHRleHQtWyMxODc3RjJdIGJvcmRlciBib3JkZXItWyMxODc3RjJdLzMwIHRleHQtWzExcHhdIGZvbnQtc2VtaWJvbGQgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZ2FwLTEuNSB0cmFuc2l0aW9uLWFsbFwiXG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICA8aSBjbGFzc05hbWU9XCJmYS1icmFuZHMgZmEtZmFjZWJvb2stZiB0ZXh0LXhzXCIgLz5cbiAgICAgICAgICAgICAgICA8c3Bhbj5GYWNlYm9vazwvc3Bhbj5cbiAgICAgICAgICAgICAgPC9hPlxuXG4gICAgICAgICAgICAgIDxhXG4gICAgICAgICAgICAgICAgaHJlZj1cImh0dHBzOi8vd3d3LnRpa3Rvay5jb20vQF9ra3drd2s/X3I9MSZfdD1aUy05QUpra0UwbTRXNVwiXG4gICAgICAgICAgICAgICAgdGFyZ2V0PVwiX2JsYW5rXCJcbiAgICAgICAgICAgICAgICByZWw9XCJub29wZW5lciBub3JlZmVycmVyXCJcbiAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRTaG93U29jaWFsVG9hc3QoZmFsc2UpfVxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXgtMSBweS0xLjUgcHgtMiByb3VuZGVkLXhsIGJnLXNsYXRlLTgwMCBob3ZlcjpiZy1zbGF0ZS03MDAgdGV4dC13aGl0ZSBib3JkZXIgYm9yZGVyLXNsYXRlLTcwMCB0ZXh0LVsxMXB4XSBmb250LXNlbWlib2xkIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGdhcC0xLjUgdHJhbnNpdGlvbi1hbGxcIlxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgPGkgY2xhc3NOYW1lPVwiZmEtYnJhbmRzIGZhLXRpa3RvayB0ZXh0LXhzXCIgLz5cbiAgICAgICAgICAgICAgICA8c3Bhbj5UaWtUb2s8L3NwYW4+XG4gICAgICAgICAgICAgIDwvYT5cblxuICAgICAgICAgICAgICA8YVxuICAgICAgICAgICAgICAgIGhyZWY9XCJodHRwczovL3d3dy5pbnN0YWdyYW0uY29tL19ibHV1dWVlMDA/c3Rrbj1jV015YzJvM2JUQm9lVEpoXCJcbiAgICAgICAgICAgICAgICB0YXJnZXQ9XCJfYmxhbmtcIlxuICAgICAgICAgICAgICAgIHJlbD1cIm5vb3BlbmVyIG5vcmVmZXJyZXJcIlxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFNob3dTb2NpYWxUb2FzdChmYWxzZSl9XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleC0xIHB5LTEuNSBweC0yIHJvdW5kZWQteGwgYmctcGluay01MDAvMTUgaG92ZXI6YmctcGluay01MDAvMjUgdGV4dC1waW5rLTQwMCBib3JkZXIgYm9yZGVyLXBpbmstNTAwLzMwIHRleHQtWzExcHhdIGZvbnQtc2VtaWJvbGQgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZ2FwLTEuNSB0cmFuc2l0aW9uLWFsbFwiXG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICA8aSBjbGFzc05hbWU9XCJmYS1icmFuZHMgZmEtaW5zdGFncmFtIHRleHQteHNcIiAvPlxuICAgICAgICAgICAgICAgIDxzcGFuPkluc3RhZ3JhbTwvc3Bhbj5cbiAgICAgICAgICAgICAgPC9hPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9tb3Rpb24uZGl2PlxuICAgICAgICApfVxuICAgICAgPC9BbmltYXRlUHJlc2VuY2U+XG5cbiAgICA8L2Rpdj5cbiAgKTtcbn1cbiJdfQ==