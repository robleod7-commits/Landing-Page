# Albert Robledo - Personal Profile Website

Official personal profile landing page featuring:
- Direct Contact (Call, SMS, Copy Number: 0966 024 8221)
- Social Links (Facebook, TikTok, Instagram)
- Custom Cover Banner & Preset Themes
- Custom Profile Picture upload, URL, and preset avatars
- Toggleable Glowing Color Effects (Vibrant / Stealth modes)
- Smooth Slide-up spring modal animations
- "Follow me on social" engagement toast

## Quick Start (Run Locally)

1. Extract this zip file.
2. Open your terminal in this directory.
3. Install dependencies:
   ```bash
   npm install
   ```
4. Start the development server:
   ```bash
   npm run dev
   ```
5. Open your browser at the URL shown (usually http://localhost:5173).

## Build for Production / Free Deployment (Vercel, Netlify, GitHub Pages)

```bash
npm run build
```
Upload the resulting `dist/` folder to any static hosting provider.
